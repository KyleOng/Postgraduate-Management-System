<?php
	include("dataconnect.php");
	include("updateDuration.php");
?>

<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    
	<title>Postgraduate Management System</title>
    
	<!-- Bootstrap Core CSS -->
	<link href="source/css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom CSS -->
    <link href="source/css/login.css" rel="stylesheet">

	<!-- Sweet Alert -->
	<script src="source/sweetalert/dist/sweetalert2.min.js"></script> 
	<link rel="stylesheet" type="text/css" href="source/sweetalert/dist/sweetalert2.css">

  </head>

  <body>

    <div class="container" style="max-width:330px;">
		
		<!-- Heading -->
		<div class="form-login-heading">
			<table style="width:100%">
				<tr>
					<td width="35%"><img src="source/picture/logo.png" alt="Logo" height="80"></td>
					<td width="65"><h2 class="form-signin-heading">Postgraduate Management System</h2></td>
				<tr>
			</table>
		</div>		
		
		<form class="form-login"  method="post"> 
			
			<!-- Id Insert -->
			<div class="input-group">
				<span class="input-group-addon"><i class="glyphicon glyphicon-user"></i></span>
				<input type="text" id="inputId" class="form-control" placeholder="User ID" name="userid" required autofocus>
			</div>
			
			<!-- Password Insert -->
			<div class="input-group">
				<span class="input-group-addon"><i class="glyphicon glyphicon-lock"></i></span>
				<input type="password" id="inputPassword" class="form-control" placeholder="Password" name="userpw" required>
			</div>
			
			<div style="margin-bottom: 15px; overflow: auto;"></div> 
			
			<!-- User Type Select -->
			<select class="form-control select" id="usertype" name="usertype">
				<option value="student">Postgraduate</option>
				<option value="supervisor">Supervisor</option>
				<option value="admin">Administrator</option>
			</select>

			<div class="checkbox">
			  <label>
				<input type="checkbox" value="remember-me"> Remember me</input>
			  </label>
			</div>
			
			<button class="btn btn-lg btn-primary btn-block" type="submit" name="btnlogin">Log in</button>
		</form>
		
		<a href="home/home.php">Return to Home</a>
    </div> <!-- /container -->
		
  </body>
</html>

<?php
if(isset($_POST['btnlogin']))
	{
		$userid=$_POST['userid'];
		$userpw=$_POST['userpw'];
		$usertype=$_POST['usertype'];
		
		if ($usertype == "student") 
		{
			$sql="select * from STUDENT where stud_code='$userid' and stud_password='".md5($userpw)."'";
			$url = "student/index.php";
		}
		else if($usertype == "supervisor")
		{
			$sql="select * from SUPERVISOR where sup_code='$userid' and sup_password='".md5($userpw)."'";
			$url = "supervisor/index.php";
		}
		else
		{
			$sql="select * from admin where admin_id='$userid' and admin_password='".md5($userpw)."'";
			$url = "admin/index.php";
		}
		
		$result=mysqli_query($con,$sql);
		
		if($row=mysqli_fetch_assoc($result))
		{
			if ($usertype == "student") 
			{
				$_SESSION["stud_id"]=$row['stud_id'];
				$_SESSION["stud_code"]=$row['stud_code'];
				$_SESSION["stud_type"]=$row['stud_type'];
			}
			else if($usertype == "supervisor")
			{
				$_SESSION["sup_id"]=$row['sup_id'];
				$_SESSION["sup_code"]=$row['sup_code'];
			}
			else
			{
				$_SESSION["admin_id"]=$row['admin_id'];
			}			
			
			$_SESSION["loggedins"]=1;
			
			?>
			<script>
				swal({
					title: "Successfull!",
					text: "Login Successful!",
					type: "success" 
				}).then(function() {
					window.location.href ="<?php echo $url; ?>";
				});
			</script>
		<?php
		}
		else
		{
			?>
			<script type="text/javascript">
				swal("Error occur", "Wrong ID or password", "error")
			</script>
			<?php
		}
	}
?>
