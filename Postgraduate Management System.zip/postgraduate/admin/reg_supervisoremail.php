
<?php

error_reporting(E_ALL);
require("PHPMailer_5.2.4/class.phpmailer.php");

	$mail = new PHPMailer();

	$mail->IsSMTP();     
	$mail->SMTPDebug = 2;
	$mail->From = "ztpowered1@gmail.com";
	$mail->Host       = "smtp.gmail.com"; 
	$mail->FromName = "Prototype";
	$mail->SMTPSecure = "ssl";
	$mail->Port       = 465;  
	$mail->SMTPAuth   = true;             
	                  
	$mail->Username   = "ztpowered1@gmail.com";     
	$mail->Password   = "12345qwer";           
	$mail->AddAddress($sup_email);
	$mail->AddReplyTo("ztpowered1@gmail.com"); 

	$mail->WordWrap = 50;

	
	$body= file_get_contents('reg_supervisoremailcontent.php');
	$body= str_replace('$sup_name',$sup_name,$body);
	$body= str_replace('$sup_original_password',$sup_original_password,$body);
	$body= str_replace('$sup_code',$sup_code,$body);
	//$body= str_replace('$uname',$uname,$body);
	//$body= str_replace('$uname',$uname,$body);
	
	$mail->MsgHTML($body);
	$mail->IsHTML(true);
	$mail->CharSet="utf-8";
	
	
	$mail->Subject= 'Thank you. Your registration is succesfull!';

	if($mail->Send())
	{echo "Message has been sent.";}
	else
	{echo "Send mail fail.";}

?>