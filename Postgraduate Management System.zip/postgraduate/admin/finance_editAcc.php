<?php
	include("../dataconnect.php");
	if($_SESSION["loggedins"]!=1)
	{
		echo"<script> window.location.href ='../login.php';</script>";
	}
	session_start();
	$admin_id = $_SESSION["admin_id"];
	$sql_admin = "select * from ADMIN where admin_id='$admin_id'";
	$row_admin = mysqli_fetch_assoc(mysqli_query($con,$sql_admin));

						
	
	

?>

<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>Admin</title>

    <!-- Bootstrap Core CSS -->
    <link href="../source/css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom CSS -->
    <link href="../source/css/sb-admin.css" rel="stylesheet">

	<!-- Awesome Fonts -->
    <link href="../source/font-awesome-4.7.0/css/font-awesome.min.css" rel="stylesheet" type="text/css">
	
	<!-- Sweet Alert -->
	<script src="../source/sweetalert/dist/sweetalert2.min.js"></script> 
	<link rel="stylesheet" type="text/css" href="../source/sweetalert/dist/sweetalert2.css">

</head>

<body>

    <div id="wrapper">

        <!-- Navigation -->
        <nav class="navbar navbar-inverse navbar-fixed-top" role="navigation">
            
			<!-- Left_Header(Display User Type) -->
			<div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-ex1-collapse">
                    <!-- Drop down bar in small screen -->
					<span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>				
				<a class="navbar-brand" href="index.php">Administrator</a>
            </div>		
            
			<!-- Middle_Header(Display User Name and ID) -->
			<div class="top-nav-right">
                <a class="navbar-brand" href="#"><i class="fa fa-user"></i>  <?php echo $row_admin['admin_name']; ?>  <?php echo $row_admin['admin_id']; ?></a>
            </div>	
			
			<!-- Logout -->
            <ul class="nav navbar-right top-nav">
				<li class="dropdown">												
					<a href="#" class="logout"><i class="fa fa-fw fa-power-off"></i> Log Out</a>
                </li>
            </ul>
            
			<!-- Sidebar Menu Items - These collapse to the responsive navigation menu on small screens -->
            <div class="collapse navbar-collapse navbar-ex1-collapse">
                <ul class="nav navbar-nav side-nav">
                    
					<!-- Dashboard -->
					<li>
                        <a href="index.php"><i class="glyphicon glyphicon-home"></i>  &nbsp; Dashboard</a>
                    </li>
                    
					<!-- Profile -->
                    <li>
                        <a href="javascript:;" data-toggle="collapse" data-target="#list0"><i class="fa fa-fw fa-user"></i>  &nbsp; Profile <i class="fa fa-fw fa-caret-down"></i></a>
                        <ul id="list0" class="collapse" >
							<li>
                                <a href="profile.php"> Display Profile</a>
                            </li>                            
							<li>
                                <a href="profile_edit.php"> Edit Profile</a>
                            </li>
							<li>
                                <a href="profile_reset.php"> Reset Password</a>
                            </li>							
                        </ul>						
                    </li>
					
					<!-- Postgraduate -->				
                    <li>
                        <a href="javascript:;" data-toggle="collapse" data-target="#list1"><i class="fa fa-user-circle-o"></i>  &nbsp; Postgraduate <i class="fa fa-fw fa-caret-down"></i></a>
                        <ul id="list1" class="collapse" >
							<li>
                                <a href="profile_viewstudent.php"> Postgraduate Info</a>
                            </li>							
							<li>
                                <a href="reg_approvalregistration.php"> Postgraduate Registration</a>
                            </li>                            
							<li>
                                <a href="profile_editstudent.php"> Edit Postgraduate Status</a>
                            </li>							
                        </ul>						
                    </li>
					
					<!-- Supervisor -->
					<li>						
						<a href="javascript:;" data-toggle="collapse" data-target="#list2"><i class="fa fa-users"></i>  &nbsp; Supervisor<i class="fa fa-fw fa-caret-down"></i></a>
                        <ul id="list2" class="collapse">
                            <li>
                                <a href="profile_viewsupervisor.php">Supervisor Info </a>
                            </li>
                            <li>
                                <a href="reg_addsupervisor.php">Supervisor Registration</a>
                            </li>
							<li>
                                <a href="profile_editsupervisor.php"> Edit Supervisor Status</a>
                            </li>	
                            <li>
                                <a href="reg_position.php">Position Info</a>
                            </li>
							<li>
                                <a href="reg_addposition.php">Position Registration</a>
                            </li>
                        </ul>
                    </li>
					
					<!-- Programme -->
                    <li>
                        <a href="javascript:;" data-toggle="collapse" data-target="#list3"><i class="fa fa-university"></i>  &nbsp; Programme <i class="fa fa-fw fa-caret-down"></i></a>
                        <ul id="list3" class="collapse">
                            <li>
                                <a href="p_reg_programme.php">Programme Info </a>
                            </li>
                            <li>
                                <a href="p_reg_addprogramme.php">Programme Registration</a>
                            </li>
						</ul>
                    </li>

					<!-- Coursework -->
                    <li>
                        <a href="javascript:;" data-toggle="collapse" data-target="#list4"><i class="glyphicon glyphicon-book"></i>  &nbsp; Coursework <i class="fa fa-fw fa-caret-down"></i></a>
                        <ul id="list4" class="collapse">
                            <li>
                                <a href="p_reg_coursework.php">Coursework Info </a>
                            </li>
                            <li>
                                <a href="p_reg_addcoursework.php">Coursework Registration</a>
                            </li>
                            <li>
                                <a href="p_reg_subject.php">Subject Info </a>
                            </li>
                            <li>
                                <a href="p_reg_addsubject.php">Subject Registration</a>
                            </li>
						</ul>
                    </li>

					<!-- Research -->
                    <li>
                        <a href="javascript:;" data-toggle="collapse" data-target="#list5"><i class="glyphicon glyphicon-education"></i>  &nbsp; Research <i class="fa fa-fw fa-caret-down"></i></a>
                        <ul id="list5" class="collapse">
                            <li>
                                <a href="p_reg_research.php">Research Info </a>
                            </li>
                            <li>
                                <a href="p_reg_addresearch.php">Research Registration</a>
                            </li>
                            <li>
                                <a href="p_reg_field.php">Field Info </a>
                            </li>
                            <li>
                                <a href="p_reg_addfield.php">Field Registration</a>
                            </li>
						</ul>
                    </li>

					
					<!-- Finance -->
                    <li class="active">
                        <a href="javascript:;" data-toggle="collapse" data-target="#list4"><i class="glyphicon glyphicon-usd"></i>  &nbsp; Finance <i class="fa fa-fw fa-caret-down"></i></a>
                        <ul id="list4" class="collapse in">
                            <li>
                                <a href="finance_editAcc.php" style="color:white;background-color:black;"> Student Finance List</a>
                            </li>
                            <li>
                                <a href="finance_setpayment.php"> Add transaction</a>
                            </li>
                            <li>
                                <a href="finance_addgrant.php" > Add grant</a>
                            </li>
                        </ul>
                    </li>
					
					<!-- User Guideline -->
                    <li>
                        <a href="userguide.php"><i class="glyphicon glyphicon-question-sign"></i>  &nbsp; User Guideline</a>
                    </li>
                </ul>
            </div>
            <!-- /.navbar-collapse -->
        </nav>

        <!-- content inside dashboard -->
		<div id="page-wrapper" style="min-height:400px;">
            <div class="container-fluid">
			
			<!-- student finance status table -->
			  <div class="panel-body">
               <h2>Student Finance List</h2><br/>
                <div class=" col-md-12 col-lg-12 table-responsive"> 
					<table class="table display table-bordered " id="table2">
                        <thead>
                          <tr>
                            <th>No</th>
                            <th>Student ID</th>
                            <th>Student Name</th>
                            <th>Intake Date</th>
                            <th>Duration</th>
                            <th>Status</th>
                            <th>Type</th>
                            <th>Finance</th>
                            <th>Total Payment</th>
                            <th>Balance</th>
                            <th>Update</th>
                            <th>Email</th>
                          </tr>
						 </thead>

								<tbody>
									<?php
									$check="select * from payment";
						  
									if (mysqli_num_rows(mysqli_query($con,$check))>0)
									{
										$sql1="SELECT *,(student.stud_finance-student.stud_total_pay) as balance FROM student,registration WHERE student.reg_id = registration.reg_id and student.stud_status != 'graduate'";
									}
									
									else
									{
										$sql1="SELECT *,(student.stud_finance) as balance FROM student,registration WHERE student.reg_id = registration.reg_id and student.stud_status != 'graduate'";
									}
									
										
										
						//---------------------------------------------------------------------------------------------------------------------
										$result1=mysqli_query($con,$sql1);

										$i=1;
										if(mysqli_num_rows($result1)!=0)
										{
											while($row1=mysqli_fetch_assoc($result1))
											{
												$s1="SELECT FLOOR(DATEDIFF(CURRENT_DATE,(select intake_date from student where stud_id=$i))/365) as datediff";
												$resul=mysqli_query($con,$s1);
												$datediff=mysqli_fetch_assoc($resul);
												
												echo "<tr>";
												echo "<td></td>";
												$id=$row1['stud_id'];
												echo "<td>".$row1['stud_code']."</td>";
												echo "<td>".$row1['stud_name']."</td>";
												echo "<td>".$row1['intake_date']."</td>";
												echo "<td>".$datediff['datediff']."</td>";
												echo "<td>".$row1['stud_status']."</td>";
												echo "<td>".$row1['stud_type']."</td>";
												echo "<td>".$row1['stud_finance']."</td>";
												echo "<td>".$row1['stud_total_pay']."</td>";
												echo "<td>".$row1['balance']."</td>";
												
												
												echo "<form  method='POST'>";
												echo "<input type='hidden' name='btn[".$i."]' value=".$id.">";
												if ($row1['stud_finance']>$row1['stud_total_pay']){
													echo "<td><button type='submit' onclick='replyclick(\"".$id."\")' name='btnSubmit' class='btn btn-block'><i class='glyphicon glyphicon-edit'></i> Update</button></td>";
												}
												else{
													echo "<td><button type='submit' onclick='replyclick(\"".$id."\")' name='btnSubmit' class='btn btn-block' disabled><i class='glyphicon glyphicon-edit'></i> Update</button></td>";
												}
												//for email purpose
												echo "<td><button type='submit' onclick='replyclick2(\"".$id."\")' name='btnEmail' class='btn btn-block' id='btnEmail' value='".$id."'><i class='glyphicon glyphicon-envelope'></i> email</button></td>";
												
												echo "</form>";			
												echo "</tr>";
												$duration=$datediff['datediff'];
												mysqli_query($con,"UPDATE Student SET duration ='$duration' WHERE student.stud_id = '$i' ");
												$i++;
			
											}
																					
										}
                                
							
									?>
								</tbody>
					</table>
				</div>
				
				
				
				<!-- overal student finance status table -->
				<div class=" col-md-12 col-lg-12 "> 
                    <table  class="table table-responsive" style="width: 50%;">
                        <tbody>
                          <tr>
							<th>Total Student</th>
                            <th>Total Finance</th>
							<th>Total Remaining </th>
                          </tr>
                          <?php
								$i--;
								$sql2="SELECT SUM(student.stud_finance) as total_finance, (SUM(student.stud_finance)-SUM(student.stud_total_pay)) as total_remain from student where student.stud_status != 'graduate'";
                                
                                $result2=mysqli_query($con,$sql2);

                                if(mysqli_num_rows($result2)!=0)
                                {
                                    while($row1=mysqli_fetch_assoc($result2))
                                    {
                                ?>
									<td><?php echo $i ;?></td>
									<td><?php echo $row1['total_finance'];?></td>
                                    <td><?php echo $row1['total_remain'];?></td>
                                    
        
                                </tr>
                                <?php
                                    }
                                }
                                 else
								{
								?>
								<tr>
								  <td colspan='7' style="text-align:center; font-size:1.4em;">No record found!</td>
								</tr>
								<?php
								}
								?>
                        </tbody>
					</table>
				</div>
				
		</div>

            </div>
            <!-- /.container-fluid -->

        </div>
        <!-- /#page-wrapper -->

    </div>
    <!-- /#wrapper -->

    <!-- jQuery -->
    <script src="../source/js/jquery.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="../source/js/bootstrap.min.js"></script>

	<!-- datatable -->
	<link rel="stylesheet" type="text/css" href="//cdn.datatables.net/1.10.16/css/jquery.dataTables.css">
  
<script type="text/javascript" charset="utf8" src="//cdn.datatables.net/1.10.16/js/jquery.dataTables.js"></script>
	
	
    <script>
	
	//logout confirmation
	$(document).ready(function() {	
		$(".logout").click(function(){		
			swal({
				title: 'Logout',
				text: "Logout from Postgraduate Management System",
				type: 'warning',
				showCancelButton: true,
				confirmButtonColor: '#3085d6',
				cancelButtonColor: '#d33',
				confirmButtonText: 'Yes'
			}).then(function () {
					window.location.href ="../logout.php";
			})			
		});		
	});

	$(document).ready(function(){

	//set table sortable
	var myTable  = $('#table2').DataTable( {
		"paging": false,			//disable paging
		"lengthChange": false,		//disable length of row
		"columnDefs": [ {			//1st column
            "searchable": false,
            "orderable": false,
            "targets": 0
        } ],
        "order": [[ 1, 'asc' ]],
		
	} );
	myTable.on( 'order.dt search.dt', function () {
        myTable.column(0, {search:'applied', order:'applied'}).nodes().each( function (cell, i) {
            cell.innerHTML = i+1;
        } );
    } ).draw();
	});


	
	function replyclick2(id)
{
	
	$.ajax({
					url:'finance_preemail.php',
					method:'POST',
					data:{id:id},
					success:function(){
						swal('Success...', 'email sended!','success').then(function () {
													window.location.href ='finance_editAcc.php';
												});
					}
				});
		
};
	</script>



	
	
<?php
if(isset($_POST['btnSubmit']))
{
		$ids=$_POST['btn'];
		//echo "<script> console.log('".$ids."')</script>";


		foreach($ids as $id)
	{
		//echo "<script> console.log('".$id."');</script>";
		if($id!='')
		{
			echo "<script> console.log('".$id."');</script>";
			$_SESSION["upd_id"]=$id;
			echo "<script>window.location.href='finance_setpayment.php'</script>";
		}
	}
}
?>	

</body>

</html>
