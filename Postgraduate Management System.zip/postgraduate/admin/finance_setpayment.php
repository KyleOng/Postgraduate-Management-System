<?php
	include("../dataconnect.php");
	if($_SESSION["loggedins"]!=1)
	{
		echo"<script> window.location.href ='../login.php';</script>";
	}
	session_start();
	$admin_id = $_SESSION["admin_id"];
	$sql_admin = "select * from ADMIN where admin_id='$admin_id'";
	$row_admin = mysqli_fetch_assoc(mysqli_query($con,$sql_admin));

	
	$id=$_SESSION["upd_id"];
	$sql1="SELECT * FROM payment,student,registration WHERE payment.stud_id ='$id' and payment.stud_id = student.stud_id and registration.reg_id = student.reg_id";         
	$result1=mysqli_query($con,$sql1);
?>

<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>Admin</title>

    <!-- Bootstrap Core CSS -->
    <link href="../source/css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom CSS -->
    <link href="../source/css/sb-admin.css" rel="stylesheet">

	<!-- Awesome Fonts -->
    <link href="../source/font-awesome-4.7.0/css/font-awesome.min.css" rel="stylesheet" type="text/css">
	
	<!-- Sweet Alert -->
	<script src="../source/sweetalert/dist/sweetalert2.min.js"></script> 
	<link rel="stylesheet" type="text/css" href="../source/sweetalert/dist/sweetalert2.css">

</head>

<body>

    <div id="wrapper">

        <!-- Navigation -->
        <nav class="navbar navbar-inverse navbar-fixed-top" role="navigation">
            
			<!-- Left_Header(Display User Type) -->
			<div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-ex1-collapse">
                    <!-- Drop down bar in small screen -->
					<span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>				
				<a class="navbar-brand" href="index.php">Administrator</a>
            </div>		
            
			<!-- Middle_Header(Display User Name and ID) -->
			<div class="top-nav-right">
                <a class="navbar-brand" href="#"><i class="fa fa-user"></i>  <?php echo $row_admin['admin_name']; ?>  <?php echo $row_admin['admin_id']; ?></a>
            </div>	
			
			<!-- Logout -->
            <ul class="nav navbar-right top-nav">
				<li class="dropdown">												
					<a href="#" class="logout"><i class="fa fa-fw fa-power-off"></i> Log Out</a>
                </li>
            </ul>
            
			<!-- Sidebar Menu Items - These collapse to the responsive navigation menu on small screens -->
            <div class="collapse navbar-collapse navbar-ex1-collapse">
                <ul class="nav navbar-nav side-nav">
                    
					<!-- Dashboard -->
					<li>
                        <a href="index.php"><i class="glyphicon glyphicon-home"></i>  &nbsp; Dashboard</a>
                    </li>
                    
					<!-- Profile -->
                    <li>
                        <a href="javascript:;" data-toggle="collapse" data-target="#list0"><i class="fa fa-fw fa-user"></i>  &nbsp; Profile <i class="fa fa-fw fa-caret-down"></i></a>
                        <ul id="list0" class="collapse" >
							<li>
                                <a href="profile.php"> Display Profile</a>
                            </li>                            
							<li>
                                <a href="profile_edit.php"> Edit Profile</a>
                            </li>
							<li>
                                <a href="profile_reset.php"> Reset Password</a>
                            </li>							
                        </ul>						
                    </li>
					
					<!-- Postgraduate -->				
                    <li>
                        <a href="javascript:;" data-toggle="collapse" data-target="#list1"><i class="fa fa-user-circle-o"></i>  &nbsp; Postgraduate <i class="fa fa-fw fa-caret-down"></i></a>
                        <ul id="list1" class="collapse" >
							<li>
                                <a href="profile_viewstudent.php"> Postgraduate Info</a>
                            </li>							
							<li>
                                <a href="reg_approvalregistration.php"> Postgraduate Registration</a>
                            </li>                            
							<li>
                                <a href="profile_editstudent.php"> Edit Postgraduate Status</a>
                            </li>							
                        </ul>						
                    </li>
					
					<!-- Supervisor -->
					<li>						
						<a href="javascript:;" data-toggle="collapse" data-target="#list2"><i class="fa fa-users"></i>  &nbsp; Supervisor<i class="fa fa-fw fa-caret-down"></i></a>
                        <ul id="list2" class="collapse">
                            <li>
                                <a href="profile_viewsupervisor.php">Supervisor Info </a>
                            </li>
                            <li>
                                <a href="reg_addsupervisor.php">Supervisor Registration</a>
                            </li>
							<li>
                                <a href="profile_editsupervisor.php"> Edit Supervisor Status</a>
                            </li>	
                            <li>
                                <a href="reg_position.php">Position Info</a>
                            </li>
							<li>
                                <a href="reg_addposition.php">Position Registration</a>
                            </li>
                        </ul>
                    </li>
					
					<!-- Programme -->
                    <li>
                        <a href="javascript:;" data-toggle="collapse" data-target="#list3"><i class="fa fa-university"></i>  &nbsp; Programme <i class="fa fa-fw fa-caret-down"></i></a>
                        <ul id="list3" class="collapse">
                            <li>
                                <a href="p_reg_programme.php">Programme Info </a>
                            </li>
                            <li>
                                <a href="p_reg_addprogramme.php">Programme Registration</a>
                            </li>
						</ul>
                    </li>

					<!-- Coursework -->
                    <li>
                        <a href="javascript:;" data-toggle="collapse" data-target="#list4"><i class="glyphicon glyphicon-book"></i>  &nbsp; Coursework <i class="fa fa-fw fa-caret-down"></i></a>
                        <ul id="list4" class="collapse">
                            <li>
                                <a href="p_reg_coursework.php">Coursework Info </a>
                            </li>
                            <li>
                                <a href="p_reg_addcoursework.php">Coursework Registration</a>
                            </li>
                            <li>
                                <a href="p_reg_subject.php">Subject Info </a>
                            </li>
                            <li>
                                <a href="p_reg_addsubject.php">Subject Registration</a>
                            </li>
						</ul>
                    </li>

					<!-- Research -->
                    <li>
                        <a href="javascript:;" data-toggle="collapse" data-target="#list5"><i class="glyphicon glyphicon-education"></i>  &nbsp; Research <i class="fa fa-fw fa-caret-down"></i></a>
                        <ul id="list5" class="collapse">
                            <li>
                                <a href="p_reg_research.php">Research Info </a>
                            </li>
                            <li>
                                <a href="p_reg_addresearch.php">Research Registration</a>
                            </li>
                            <li>
                                <a href="p_reg_field.php">Field Info </a>
                            </li>
                            <li>
                                <a href="p_reg_addfield.php">Field Registration</a>
                            </li>
						</ul>
                    </li>
					
					<!-- Finance -->
                     <li class="active">
                        <a href="javascript:;" data-toggle="collapse" data-target="#list4"><i class="glyphicon glyphicon-usd"></i>  &nbsp; Finance <i class="fa fa-fw fa-caret-down"></i></a>
                        <ul id="list4" class="collapse in">
                            <li>
                                <a href="finance_editAcc.php" > Student Finance List</a>
                            </li>
                            <li>
                                <a href="finance_setpayment.php" style="color:white;background-color:black;"> Add transaction</a>
                            </li>
                            <li>
                                <a href="finance_addgrant.php" > Add grant</a>
                            </li>
                        </ul>
                    </li>
					
					<!-- User Guideline -->
                    <li>
                        <a href="userguide.php"><i class="glyphicon glyphicon-question-sign"></i>  &nbsp; User Guideline</a>
                    </li>
                </ul>
            </div>
            <!-- /.navbar-collapse -->
        </nav>

        <!-- content inside dashboard -->
		<div id="page-wrapper" style="min-height:660px;">
            <div class="container-fluid">
			
			 <!-- Panel Border-->
				<div class="panel panel-border">						
					
					<!-- Panel title-->
					<div class="panel-heading"><h2>Update Transaction</h2></div>
					
					
				</div>
			
            </div>
            <!-- /.container-fluid -->
			
			<!-- table for payment of selected student -->
			<div class=" col-md-12 col-lg-12 table-responsive"> 
				<table class="table display table-bordered " id="table2">
                    <thead>
                        <tr>
                            <th>No</th>
                            <th>student ID</th>
							<th>student Name</th>
							<th>Payment ID</th>
                            <th>Payment Date</th>
                            <th>Payment Amount</th>
                        </tr>
					</thead>

					<tbody>
						<?php
							

							$i=1;
							if(mysqli_num_rows($result1)!=0)
							{
								while($row1=mysqli_fetch_assoc($result1))
								{
									
									echo "<tr>";
									echo "<td>".$i."</td>";
									echo "<td>".$row1['stud_code']."</td>";
									echo "<td>".$row1['stud_name']."</td>";
									echo "<td>".$row1['pay_code']."</td>";
									echo "<td>".$row1['pay_date']."</td>";
									echo "<td>".$row1['pay_amount']."</td>";
									$i++;
								}
							}
							else
							{
								echo "<tr>";
								echo "<td colspan='7' style='text-align:center; font-size:1.4em;'>No record found!</td>";
								echo "</tr>";
							}

						?>
					</tbody>
				</table>
				</br>
			</div>								
			
			<!-- overal student finance status table -->
			<div class=" col-md-12 col-lg-12 "> 
                <table  class="table table-responsive" style="width: 100%;">
                    <tbody>
						<tr>
							<th>Total Finance</th>
							<th>Total payment</th>
							<th>Total Remaining </th>
						</tr>
						
						<?php
							$sql2="SELECT *,(stud_finance-stud_total_pay)as remain from student where student.stud_status != 'graduate' and stud_id='$id'";
							
							$result2=mysqli_query($con,$sql2);

							if(mysqli_num_rows($result2)!=0)
							{
								while($row1=mysqli_fetch_assoc($result2))
								{
							?>
								<td><?php echo $row1['stud_finance'];?></td>
								<td><?php echo $row1['stud_total_pay'];?></td>
								<td><?php echo $row1['remain'];?></td>
								
	
							</tr>
							<?php
								}
							}
							 else
							{
							?>
							<tr>
							  <td colspan='7' style="text-align:center; font-size:1.4em;">No record found!</td>
							</tr>
							<?php
							}
							?>
                    </tbody>
				</table>
				</br>
			</div>
				
			<!-- button to insert new payment -->
			<div class=" col-md-12 col-lg-12 ">
				<form action="finance_setpayment.php "method="POST">
					<table class="table"  >
					<tbody>
					<tr>
						<td>Payment Amount </td>
						<td><input type="text" class="form-control" value="" name="pay_amount" step="0.01" required></td>
						<td><button type="submit" class="btn btn-block" id="btnSubmit" name="btnSubmit"><i class="glyphicon glyphicon-send"></i> Submit</button></td>
					</tr>
					</tbody>
					</table>				
				</form>
				</br>
			</div>
				
			
			<!-- back to student list -->
			<div class=" col-md-12 col-lg-12 "> 
				<button onclick="window.location.href='finance_editAcc.php'" class='btn btn-block'><span class="glyphicon glyphicon-share"></span> Back to student list</button>
			</div> 
        
		
		</div>
        <!-- /#page-wrapper -->

    </div>
    <!-- /#wrapper -->

    <!-- jQuery -->
    <script src="../source/js/jquery.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="../source/js/bootstrap.min.js"></script>

    <script>
	
	//logout confirmation
	$(document).ready(function() {	
		$(".logout").click(function(){		
			swal({
				title: 'Logout',
				text: "Logout from Postgraduate Management System",
				type: 'warning',
				showCancelButton: true,
				confirmButtonColor: '#3085d6',
				cancelButtonColor: '#d33',
				confirmButtonText: 'Yes'
			}).then(function () {
					window.location.href ="../logout.php";
			})			
		});		
	});
	

	
	</script>

</body>
<?php
	$sqlq="SELECT * from student WHERE stud_id = '$id'";
		$validate=mysqli_query($con,$sqlq);
		if(mysqli_num_rows($validate)!=0)
		{
			while($row1=mysqli_fetch_assoc($validate))
			{
	
				$finance=$row1['stud_total_pay'];
				$remaining=$row1['stud_finance']-$row1['stud_total_pay'];
				//echo $remaining;
				
			}
		}
	if(isset($_POST['btnSubmit']))
	{
		
		
		$new_amount=$_POST['pay_amount'];
		if ($new_amount>$remaining)
		{
			//echo 123;
		}
		else{
			$sql2 = "INSERT INTO PAYMENT (pay_id, stud_id, pay_amount) VALUES ('',$id,$new_amount)";
		}

		
		if (mysqli_query($con, $sql2)) {
			?>
			
			<script type="text/javascript">
				swal('Success...', 'Payment Updated!','success').then(function () {
							window.location.href ='finance_setpayment.php';
						})	
			</script>
		<?php
		}
		
		else{
			?>
			<script type="text/javascript">
				swal('failed...', 'Invalid payment amount input!','error').then(function () {
							window.location.href ='finance_setpayment.php';
						})
			</script>
		<?php		
		}
		
	}
?>
<?php
	

	mysqli_query($con,"UPDATE payment set pay_code=concat('s',pay_id);");
	
	$total="SELECT SUM(payment.pay_amount) from payment where stud_id = $id";
	mysqli_query($con,"UPDATE Student SET stud_total_pay =(SELECT SUM(payment.pay_amount) from payment where stud_id = $id) WHERE stud_id=$id");

?>
</html>
