<?php
	include("../dataconnect.php");
	if(isset($_POST["id"])){
		$id=$_POST["id"];
			
			
		$result=mysqli_query($con,"SELECT * FROM student,registration where student.stud_id='".$id. "' and student.reg_id=registration.reg_id");
			$row=mysqli_fetch_array($result);
			$stud_name=$row["stud_name"];
			$stud_finance=$row["stud_finance"];
			$duration=$row["duration"];
			$stud_email=$row["stud_email"];
			$stud_code=$row["stud_code"];
			$stud_remain=$row["stud_finance"]-$row["stud_total_pay"];
			include("finance_email.php");
			
		
	}
?>