<?php
	include("../dataconnect.php");
	if($_SESSION["loggedins"]!=1)
	{
		echo"<script> window.location.href ='../login.php';</script>";
	}
	session_start();
	$admin_id = $_SESSION["admin_id"];
	$sql_admin = "select * from ADMIN where admin_id='$admin_id'";
	$row_admin = mysqli_fetch_assoc(mysqli_query($con,$sql_admin));
?>

<!DOCTYPE html>
<html lang="en">
<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Admin</title>
    <!-- Bootstrap Core CSS -->
    <link href="../source/css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom CSS -->
    <link href="../source/css/sb-admin.css" rel="stylesheet">

	<!-- Awesome Fonts -->
    <link href="../source/font-awesome-4.7.0/css/font-awesome.min.css" rel="stylesheet" type="text/css">

	<!-- Sweet Alert -->
	<script src="../source/sweetalert/dist/sweetalert2.min.js"></script> 
	<link rel="stylesheet" type="text/css" href="../source/sweetalert/dist/sweetalert2.css">
	
	<!-- jQuery -->
    <script src="../source/js/jquery.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="../source/js/bootstrap.min.js"></script>

	<script>
	function addProgramme(){
		document.getElementById("prog_id").options.length = 1;
		var selected_Structure= document.forms[0].prog_id.value;
		<?php
		$programmeList=mysqli_query($con,"SELECT * FROM programme where (prog_type='Research' or prog_type='Both') and prog_id not in(SELECT prog_id FROM research);");
		while($row = mysqli_fetch_array($programmeList,MYSQLI_ASSOC)) {
			?>
			var newOption=document.createElement("option");
			newOption.value="<?php echo $row['prog_id']?>";
			newOption.text="<?php echo $row['prog_name']?>";
			document.getElementById("prog_id").add(newOption);
			<?php
		}
		
		?>
	}
	
	function showBlankError(id,error_id,br_id,error_message){
		document.getElementById(id).style.backgroundColor = "#ffcccc";
		document.getElementById(error_id).innerHTML=error_message.replace(error_message,"You can't leave this blank");
		document.getElementById(error_id).hidden=false;
		document.getElementById(br_id).hidden=true;
	}
	
	function showInvalidError(id,error_id,br_id,error_message){
		document.getElementById(id).style.backgroundColor = "#ffcccc";
		document.getElementById(error_id).innerHTML=error_message.replace(error_message,"Invalid format");
		document.getElementById(error_id).hidden=false;
		document.getElementById(br_id).hidden=true;
	}
	
	function showNoError(id,error_id,br_id){
		document.getElementById(id).style.backgroundColor = "white";
		document.getElementById(error_id).hidden=true;
		document.getElementById(br_id).hidden=false;
	}
	
	function showDuplicateError(id,error_id,br_id,error_message){
		document.getElementById(id).style.backgroundColor = "#ffcccc";
		document.getElementById(error_id).innerHTML=error_message.replace(error_message,"This has been used");
		document.getElementById(error_id).hidden=false;
		document.getElementById(br_id).hidden=true;
	}
	
	function duplicateCheck(id){
		var error_id="error_"+id;
		var br_id="br_"+id;
		var error_message=document.getElementById(error_id).innerHTML; 	
		$.post('p_reg_duplicateCheckResearch.php',{check_attribute: document.getElementById(id).value, type:id},
		function(result){
			if (result=="exist"){
				showDuplicateError(id,error_id,br_id,error_message);
			}
			else{
				showNoError(id,error_id,br_id);
			}
		});
	}
	
	function InputValidation(id,reg,duplicateChecking){
		var error_id="error_"+id;
		var br_id="br_"+id;
		var error_message=document.getElementById(error_id).innerHTML; 
		if(reg.test(document.getElementById(id).value) == false){
			if ((document.getElementById(id).value) == ""){
				showBlankError(id,error_id,br_id,error_message);
			}
			else{
				showInvalidError(id,error_id,br_id,error_message);
			}
		}
		else{
			showNoError(id,error_id,br_id);
			if(duplicateChecking==true) duplicateCheck(id);
		}
	}
	
	function submitFunc(){
		var errorCount=0;
		var id=["prog_id","res_reg_fee","res_annual_resource_fee","res_tuition_fee","res_examination_fee"];
		
		for(i=0;i<id.length;i++){
			var error_id="error_"+id[i];
			var br_id="br_"+id[i];
			var error_message=document.getElementById(error_id).innerHTML;
			if(document.getElementById(id[i]).value=="" || document.getElementById(error_id).hidden==false){
				if(document.getElementById(id[i]).value==""){
					showBlankError(id[i],error_id,br_id,error_message);
					errorCount++;
				}
				if(document.getElementById(error_id).hidden==false){
					errorCount++;
				}
			}	
		}
		if (errorCount>0){
			swal(
			  'Error',
			  'Please make sure all the inputs are inserted and in correct format',
			  'error'
			);
			return false;
		}
		else{
			return true;
		}
	}
	
	</script>
</head>
<style>
    label
    {
        margin-top: 10px;
    }

    a:hover
    {
        text-decoration: none;
    }

</style>

<body>

    <div id="wrapper">

        <!-- Navigation -->
        <nav class="navbar navbar-inverse navbar-fixed-top" role="navigation">
            
			<!-- Left_Header(Display User Type) -->
			<div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-ex1-collapse">
                    <!-- Drop down bar in small screen -->
					<span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>				
				<a class="navbar-brand" href="index.php">Administrator</a>
            </div>		
            
			<!-- Middle_Header(Display User Name and ID) -->
			<div class="top-nav-right">
                <a class="navbar-brand" href="#"><i class="fa fa-user"></i>  <?php echo $row_admin['admin_name']; ?>  <?php echo $row_admin['admin_id']; ?></a>
            </div>	
			
			<!-- Logout -->
            <ul class="nav navbar-right top-nav">
				<li class="dropdown">												
					<a href="#" class="logout"><i class="fa fa-fw fa-power-off"></i> Log Out</a>
                </li>
            </ul>
            
			<!-- Sidebar Menu Items - These collapse to the responsive navigation menu on small screens -->
            <div class="collapse navbar-collapse navbar-ex1-collapse">
                <ul class="nav navbar-nav side-nav">
                    
					<!-- Dashboard -->
					<li>
                        <a href="index.php"><i class="glyphicon glyphicon-home"></i>  &nbsp; Dashboard</a>
                    </li>
                    
					<!-- Profile -->
                    <li>
                        <a href="javascript:;" data-toggle="collapse" data-target="#list0"><i class="fa fa-fw fa-user"></i>  &nbsp; Profile <i class="fa fa-fw fa-caret-down"></i></a>
                        <ul id="list0" class="collapse" >
							<li>
                                <a href="profile.php"> Display Profile</a>
                            </li>                            
							<li>
                                <a href="profile_edit.php"> Edit Profile</a>
                            </li>
							<li>
                                <a href="profile_reset.php"> Reset Password</a>
                            </li>							
                        </ul>						
                    </li>
					
					<!-- Postgraduate -->				
                    <li>
                        <a href="javascript:;" data-toggle="collapse" data-target="#list1"><i class="fa fa-user-circle-o"></i>  &nbsp; Postgraduate <i class="fa fa-fw fa-caret-down"></i></a>
                        <ul id="list1" class="collapse" >
							<li>
                                <a href="profile_viewstudent.php"> Postgraduate Info</a>
                            </li>							
							<li>
                                <a href="reg_approvalregistration.php"> Postgraduate Registration</a>
                            </li>                            
							<li>
                                <a href="profile_editstudent.php"> Edit Postgraduate Status</a>
                            </li>							
                        </ul>						
                    </li>
					
					<!-- Supervisor -->
					<li>						
						<a href="javascript:;" data-toggle="collapse" data-target="#list2"><i class="fa fa-users"></i>  &nbsp; Supervisor<i class="fa fa-fw fa-caret-down"></i></a>
                        <ul id="list2" class="collapse">
                            <li>
                                <a href="profile_viewsupervisor.php">Supervisor Info </a>
                            </li>
                            <li>
                                <a href="reg_addsupervisor.php">Supervisor Registration</a>
                            </li>
							<li>
                                <a href="profile_editsupervisor.php"> Edit Supervisor Status</a>
                            </li>	
                            <li>
                                <a href="reg_position.php">Position Info</a>
                            </li>
							<li>
                                <a href="reg_addposition.php">Position Registration</a>
                            </li>
                        </ul>
                    </li>
					
					<!-- Programme -->
                    <li>
                        <a href="javascript:;" data-toggle="collapse" data-target="#list3"><i class="fa fa-university"></i>  &nbsp; Programme <i class="fa fa-fw fa-caret-down"></i></a>
                        <ul id="list3" class="collapse">
                            <li>
                                <a href="p_reg_programme.php">Programme Info </a>
                            </li>
                            <li>
                                <a href="p_reg_addprogramme.php">Programme Registration</a>
                            </li>
						</ul>
                    </li>

					<!-- Coursework -->
                    <li>
                        <a href="javascript:;" data-toggle="collapse" data-target="#list4"><i class="glyphicon glyphicon-book"></i>  &nbsp; Coursework <i class="fa fa-fw fa-caret-down"></i></a>
                        <ul id="list4" class="collapse">
                            <li>
                                <a href="p_reg_coursework.php">Coursework Info </a>
                            </li>
                            <li>
                                <a href="p_reg_addcoursework.php">Coursework Registration</a>
                            </li>
                            <li>
                                <a href="p_reg_subject.php">Subject Info </a>
                            </li>
                            <li>
                                <a href="p_reg_addsubject.php">Subject Registration</a>
                            </li>
						</ul>
                    </li>

					<!-- Research -->
                    <li class="active">
                        <a href="javascript:;" data-toggle="collapse" data-target="#list5"><i class="glyphicon glyphicon-education"></i>  &nbsp; Research <i class="fa fa-fw fa-caret-down"></i></a>
                        <ul id="list5" class="collapse in">
                            <li>
                                <a href="p_reg_research.php">Research Info </a>
                            </li>
                            <li>
                                <a href="p_reg_addresearch.php" style="color:white;background-color:black;">Research Registration</a>
                            </li>
                            <li>
                                <a href="p_reg_field.php">Field Info </a>
                            </li>
                            <li>
                                <a href="p_reg_addfield.php">Field Registration</a>
                            </li>
						</ul>
                    </li>
					
					<!-- Finance -->
                    <li>
                        <a href="javascript:;" data-toggle="collapse" data-target="#list6"><i class="glyphicon glyphicon-usd"></i>  &nbsp; Finance <i class="fa fa-fw fa-caret-down"></i></a>
                        <ul id="list6" class="collapse ">
                            <li>
                                <a href="finance_editAcc.php" > Student Finance List</a>
                            </li>
                            <li>
                                <a href="finance_setpayment.php"> Add transaction</a>
                            </li>
                            <li>
                                <a href="finance_addgrant.php"> Add grant</a>
                            </li>
                        </ul>
                    </li>
										
					<!-- User Guideline -->
                    <li>
                        <a href="userguide.php"><i class="glyphicon glyphicon-question-sign"></i>  &nbsp; User Guideline</a>
                    </li>
					
                </ul>
            </div>
            <!-- /.navbar-collapse -->
        </nav>

        <!-- form started -->
        <form method="post" action="p_reg_addresearch.php" onsubmit="return submitFunc()">
        <div id="page-wrapper" style="min-height:660px;">
			<h2>Add Research</h2><br/>
            <div class="container-fluid">

    			<div class=" col-md-12 col-lg-12 "> 
                        <div class="row">
                            <div class="col-md-8">
                                <label for="name">Programme</label>
                                    <select class="form-control" id="prog_id" name="prog_id"  onfocus="addProgramme()" onblur="InputValidation('prog_id',/^(.{1,1000})$/,true)">
                                    <option value="" selected disabled>----------Programme---------</option>
                                </select>
								<p style="color:red;" id="error_prog_id" hidden>You can't leave this blank</p>
								<br id="br_prog_id">								
                          </div>
                        </div>
                        
                        <div class="row">
                          <div class="col-md-8">
                                <label for="name">Research Registration Fee</label>
                                    <input type="text" class="form-control" id="res_reg_fee" name="res_reg_fee" onblur="InputValidation('res_reg_fee',/^((([0-9]{1,10})+\.([0-9]{2,2}))|([0-9]{1,10}))$/,false)">
									<p style="color:red;" id="error_res_reg_fee" hidden>You can't leave this blank</p>
									<br id="br_res_reg_fee">										
                          </div>
                        </div>
						
						<div class="row">
                          <div class="col-md-8">
                                <label for="name">Research Annual Resource Fee</label>
                                    <input type="text" class="form-control" id="res_annual_resource_fee" name="res_annual_resource_fee" onblur="InputValidation('res_annual_resource_fee',/^((([0-9]{1,10})+\.([0-9]{2,2}))|([0-9]{1,10}))$/,false)">
									<p style="color:red;" id="error_res_annual_resource_fee" hidden>You can't leave this blank</p>
									<br id="br_res_annual_resource_fee">        
                          </div>
                        </div>
						
						<div class="row">
                          <div class="col-md-8">
                                <label for="name">Research Tuition Fee</label>
                                    <input type="text" class="form-control" id="res_tuition_fee" name="res_tuition_fee" onblur="InputValidation('res_tuition_fee',/^((([0-9]{1,10})+\.([0-9]{2,2}))|([0-9]{1,10}))$/,false)">
									<p style="color:red;" id="error_res_tuition_fee" hidden>You can't leave this blank</p>
									<br id="br_res_tuition_fee">      
                          </div>
                        </div>
						
						<div class="row">
                          <div class="col-md-8">
                                <label for="name">Research Total Examination Fee</label>
                                    <input type="text" class="form-control" id="res_examination_fee" name="res_examination_fee" onblur="InputValidation('res_examination_fee',/^((([0-9]{1,10})+\.([0-9]{2,2}))|([0-9]{1,10}))$/,false)">
									<p style="color:red;" id="error_res_examination_fee" hidden>You can't leave this blank</p>
									<br id="br_res_examination_fee">        
                          </div>
                        </div>
						
                        <br/>
                         <button type="submit" class="btn btn-default btn-block addcbtn" style="background-color: #e4e4e4; " id="submit_button" name="submit_button"><i class="glyphicon glyphicon-send"></i> Submit</button>
                        <a href="p_reg_research.php"><button type="button" class="btn btn-default btn-block addcbtn" style="background-color: #e4e4e4; margin-top:10px; "><i class="glyphicon glyphicon-remove"></i> Cancel</button></a>
                </div>
			</div>
            </div>
            </form>
            <!-- /.container-fluid -->
            <!-- form end -->

        </div>
        <!-- /#page-wrapper -->

    </div>
    <!-- /#wrapper -->

    <script>
	
	//logout confirmation
	$(document).ready(function() {	
		$(".logout").click(function(){		
			swal({
				title: 'Logout',
				text: "Logout from Postgraduate Management System",
				type: 'warning',
				showCancelButton: true,
				confirmButtonColor: '#3085d6',
				cancelButtonColor: '#d33',
				confirmButtonText: 'Yes'
			}).then(function () {
					window.location.href ="../logout.php";
			})			
		});		
	});
	</script>
</body>

</html>
    

<?php
	if(isset($_POST["submit_button"]))
	{
		$prog_id=$_POST["prog_id"];
		$res_reg_fee=$_POST["res_reg_fee"];
		$res_annual_resource_fee=$_POST["res_annual_resource_fee"];
		$res_tuition_fee=$_POST["res_tuition_fee"];
		$res_examination_fee=$_POST["res_examination_fee"];


		$test=mysqli_query($con,"INSERT INTO research(prog_id, res_reg_fee, res_annual_resource_fee, res_annual_tuition_fee, res_examination_fee) 
		values ('$prog_id','$res_reg_fee','$res_annual_resource_fee','$res_tuition_fee','$res_examination_fee')");
		?>
		<script>
		//alert("<?php echo $prog_id.$cs_reg_fee.$cs_annual_resource_fee.$cs_tuition_fee.$cs_total_subject_fee.$cs_total_credit_hr; ?>");
		swal('Registered!','Raesearch has successfully registered','success');

		</script><?php
		
		
	}
	
?>