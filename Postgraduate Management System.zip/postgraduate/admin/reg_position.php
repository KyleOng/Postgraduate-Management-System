<?php
	include("../dataconnect.php");
	if($_SESSION["loggedins"]!=1)
	{
		echo"<script> window.location.href ='../login.php';</script>";
	}
	session_start();
	$admin_id = $_SESSION["admin_id"];
	$sql_admin = "select * from ADMIN where admin_id='$admin_id'";
	$row_admin = mysqli_fetch_assoc(mysqli_query($con,$sql_admin));  
?>

<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Admin</title>

    <!-- Bootstrap Core CSS -->
    <link href="../source/css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom CSS -->
    <link href="../source/css/sb-admin.css" rel="stylesheet">

	<!-- Awesome Fonts -->
    <link href="../source/font-awesome-4.7.0/css/font-awesome.min.css" rel="stylesheet" type="text/css">

	<!-- Sweet Alert -->
	<script src="../source/sweetalert/dist/sweetalert2.min.js"></script> 
	<link rel="stylesheet" type="text/css" href="../source/sweetalert/dist/sweetalert2.css">
	
	<!-- jQuery -->
    <script src="../source/js/jquery.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="../source/js/bootstrap.min.js"></script>


    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->

</head>

<body>

    <div id="wrapper">

        <!-- Navigation -->
        <nav class="navbar navbar-inverse navbar-fixed-top" role="navigation">
            
			<!-- Left_Header(Display User Type) -->
			<div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-ex1-collapse">
                    <!-- Drop down bar in small screen -->
					<span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>				
				<a class="navbar-brand" href="index.php">Administrator</a>
            </div>		
            
			<!-- Middle_Header(Display User Name and ID) -->
			<div class="top-nav-right">
                <a class="navbar-brand" href="#"><i class="fa fa-user"></i>  <?php echo $row_admin['admin_name']; ?>  <?php echo $row_admin['admin_id']; ?></a>
            </div>	
			
			<!-- Logout -->
            <ul class="nav navbar-right top-nav">
				<li class="dropdown">												
					<a href="#" class="logout"><i class="fa fa-fw fa-power-off"></i> Log Out</a>
                </li>
            </ul>
            
			<!-- Sidebar Menu Items - These collapse to the responsive navigation menu on small screens -->
            <div class="collapse navbar-collapse navbar-ex1-collapse">
                <ul class="nav navbar-nav side-nav">
                    
					<!-- Dashboard -->
					<li>
                        <a href="index.php"><i class="glyphicon glyphicon-home"></i>  &nbsp; Dashboard</a>
                    </li>
                    
					<!-- Profile -->
                    <li>
                        <a href="javascript:;" data-toggle="collapse" data-target="#list0"><i class="fa fa-fw fa-user"></i>  &nbsp; Profile <i class="fa fa-fw fa-caret-down"></i></a>
                        <ul id="list0" class="collapse" >
							<li>
                                <a href="profile.php"> Display Profile</a>
                            </li>                            
							<li>
                                <a href="profile_edit.php"> Edit Profile</a>
                            </li>
							<li>
                                <a href="profile_reset.php"> Reset Password</a>
                            </li>							
                        </ul>						
                    </li>
					
					<!-- Postgraduate -->				
                    <li>
                        <a href="javascript:;" data-toggle="collapse" data-target="#list1"><i class="fa fa-user-circle-o"></i>  &nbsp; Postgraduate <i class="fa fa-fw fa-caret-down"></i></a>
                        <ul id="list1" class="collapse" >
							<li>
                                <a href="profile_viewstudent.php"> Postgraduate Info</a>
                            </li>							
							<li>
                                <a href="reg_approvalregistration.php"> Postgraduate Registration</a>
                            </li>                            
							<li>
                                <a href="profile_editstudent.php"> Edit Postgraduate Status</a>
                            </li>							
                        </ul>						
                    </li>
					
					<!-- Supervisor -->
					<li class="active">						
						<a href="javascript:;" data-toggle="collapse" data-target="#list2"><i class="fa fa-users"></i>  &nbsp; Supervisor<i class="fa fa-fw fa-caret-down"></i></a>
                        <ul id="list2" class="collapse in">
                            <li>
                                <a href="profile_viewsupervisor.php">Supervisor Info </a>
                            </li>
                            <li>
                                <a href="reg_addsupervisor.php">Supervisor Registration</a>
                            </li>
							<li>
                                <a href="profile_editsupervisor.php"> Edit Supervisor Status</a>
                            </li>	
                            <li>
                                <a href="reg_position.php" style="color:white;background-color:black;">Position Info</a>
                            </li>
							<li>
                                <a href="reg_addposition.php">Position Registration</a>
                            </li>
                        </ul>
                    </li>
					
					<!-- Programme -->
                    <li>
                        <a href="javascript:;" data-toggle="collapse" data-target="#list3"><i class="fa fa-university"></i>  &nbsp; Programme <i class="fa fa-fw fa-caret-down"></i></a>
                        <ul id="list3" class="collapse">
                            <li>
                                <a href="p_reg_programme.php">Programme Info </a>
                            </li>
                            <li>
                                <a href="p_reg_addprogramme.php">Programme Registration</a>
                            </li>
						</ul>
                    </li>

					<!-- Coursework -->
                    <li>
                        <a href="javascript:;" data-toggle="collapse" data-target="#list4"><i class="glyphicon glyphicon-book"></i>  &nbsp; Coursework <i class="fa fa-fw fa-caret-down"></i></a>
                        <ul id="list4" class="collapse">
                            <li>
                                <a href="p_reg_coursework.php">Coursework Info </a>
                            </li>
                            <li>
                                <a href="p_reg_addcoursework.php">Coursework Registration</a>
                            </li>
                            <li>
                                <a href="p_reg_subject.php">Subject Info </a>
                            </li>
                            <li>
                                <a href="p_reg_addsubject.php">Subject Registration</a>
                            </li>
						</ul>
                    </li>

					<!-- Research -->
                    <li>
                        <a href="javascript:;" data-toggle="collapse" data-target="#list5"><i class="glyphicon glyphicon-education"></i>  &nbsp; Research <i class="fa fa-fw fa-caret-down"></i></a>
                        <ul id="list5" class="collapse">
                            <li>
                                <a href="p_reg_research.php">Research Info </a>
                            </li>
                            <li>
                                <a href="p_reg_addresearch.php">Research Registration</a>
                            </li>
                            <li>
                                <a href="p_reg_field.php">Field Info </a>
                            </li>
                            <li>
                                <a href="p_reg_addfield.php">Field Registration</a>
                            </li>
						</ul>
                    </li>
					
					<!-- Finance -->
                    <li>
                        <a href="javascript:;" data-toggle="collapse" data-target="#list6"><i class="glyphicon glyphicon-usd"></i>  &nbsp; Finance <i class="fa fa-fw fa-caret-down"></i></a>
                        <ul id="list6" class="collapse ">
                            <li>
                                <a href="finance_editAcc.php" > Student Finance List</a>
                            </li>
                            <li>
                                <a href="finance_setpayment.php"> Add transaction</a>
                            </li>
                            <li>
                                <a href="finance_addgrant.php"> Add grant</a>
                            </li>
                        </ul>
                    </li>
										
					<!-- User Guideline -->
                    <li>
                        <a href="userguide.php"><i class="glyphicon glyphicon-question-sign"></i>  &nbsp; User Guideline</a>
                    </li>
					
                </ul>
            </div>
            <!-- /.navbar-collapse -->
        </nav>

        <div id="page-wrapper" style="min-height:660px;">
            <div class="container-fluid">
            <h2>Position</h2><br/>

                <div class=" col-md-12 col-lg-12 "> 
					<?php
					$result = mysqli_query($con, "SELECT * FROM position");
					if(mysqli_num_rows($result)>0){
					?>
                        <table class="table table-responsive" style="width: 100%;">
                            <tbody>
                              <tr>
                                <th>Position ID</th>
                                <th>Position Name</th>
                                <th>Student limit</th>
                                
                              </tr>
							<?php
								while($row=mysqli_fetch_array($result)){
							?>
                              <tr>
                                <td><?php echo $row["pos_id"];?></td>
								<td><?php echo $row["pos_name"];?></td>
								<td><?php echo $row["stud_limit"];?></td>
                                
                              </tr>
							<?php
								}
							?>
                            </tbody>
                        </table>
					<?php
					}
					?>
					<a href="reg_addposition.php"><button type="button" class="btn btn-default btn-block addcbtn" style="background-color: #e4e4e4; "><i class="glyphicon glyphicon-plus"></i> Add Position</button></a>

				</div>

            </div>
            <!-- /.container-fluid -->

        </div>
        <!-- /#page-wrapper -->

    </div>
    <!-- /#wrapper -->

    <script>
	
	//logout confirmation
	$(document).ready(function() {	
		$(".logout").click(function(){		
			swal({
				title: 'Logout',
				text: "Logout from Postgraduate Management System",
				type: 'warning',
				showCancelButton: true,
				confirmButtonColor: '#3085d6',
				cancelButtonColor: '#d33',
				confirmButtonText: 'Yes'
			}).then(function () {
					window.location.href ="../logout.php";
			})			
		});		
	});
	</script>

</body>

</html>
