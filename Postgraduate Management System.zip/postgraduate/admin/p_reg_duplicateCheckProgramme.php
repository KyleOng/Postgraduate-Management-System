<?php
	include("../dataconnect.php");

	$check_attribute=$_POST['check_attribute'];
	$check_attribute2=$_POST['check_attribute2'];
	$database_attribute=$_POST['type'];
	$sql="select * from programme where $database_attribute='$check_attribute' and (prog_type='$check_attribute2' or prog_type='Both')";
	$result=mysqli_query($con,$sql);
	
	if(mysqli_num_rows($result)!=0)
	{
		echo "exist";
	}
	else
	{
		echo "does not exist";
	}
?>