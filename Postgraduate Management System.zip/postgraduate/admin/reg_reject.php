<?php
	include("../dataconnect.php");
	if(isset($_POST["id"])){
		$id=$_POST["id"];
		$sql="UPDATE registration set reg_status='Rejected' where reg_id='".$id. "'";
		mysqli_query($con,$sql);
		
	}
?>