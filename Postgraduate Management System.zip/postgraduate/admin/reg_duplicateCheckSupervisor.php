<?php
	include("../dataconnect.php");

	$check_attribute=$_POST['check_attribute'];
	$database_attribute=$_POST['type'];
	$sql="select * from supervisor where $database_attribute ='$check_attribute' ";
	$result=mysqli_query($con,$sql);
	
	if(mysqli_num_rows($result)!=0)
	{
		echo "exist";
	}
	else
	{
		echo "does not exist";
	}
?>