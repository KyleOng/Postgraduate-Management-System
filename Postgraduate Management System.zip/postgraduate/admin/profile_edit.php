<?php
	include("../dataconnect.php");
	if($_SESSION["loggedins"]!=1)
	{
		echo"<script> window.location.href ='../login.php';</script>";
	}
	session_start();
	$admin_id = $_SESSION["admin_id"];
	$sql_admin = "select * from ADMIN where admin_id='$admin_id'";
	$row_admin = mysqli_fetch_assoc(mysqli_query($con,$sql_admin));
?>

<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>Admin Profile</title>


    <!-- Bootstrap Core CSS -->
    <link href="../source/css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom CSS -->
    <link href="../source/css/sb-admin.css" rel="stylesheet">

	<!-- Awesome Fonts -->
    <link href="../source/font-awesome-4.7.0/css/font-awesome.min.css" rel="stylesheet" type="text/css">	
	
	<!-- Sweet Alert -->
	<script src="../source/sweetalert/dist/sweetalert2.min.js"></script> 
	<link rel="stylesheet" type="text/css" href="../source/sweetalert/dist/sweetalert2.css">
	
    <!-- jQuery -->
    <script src="../source/js/jquery.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="../source/js/bootstrap.min.js"></script>

</head>

<style>
@media (min-width: 768px) {
	.equal {
		display: flex;
		flex-wrap: wrap;
	}
	  
	.pic {
		padding-top: 18px;
	}
}

.table-user-information > tbody > tr {
    border-top: 1px solid rgb(221, 221, 221);
}

.table-user-information > tbody > tr:first-child {
    border-top: 0;
}

.table-user-information > tbody > tr > td {
    border-top: 0;
}

.panel-border {
    border-color: #000000;
}

.panel-footer {
    padding: 30px 15px;
    background-color: #f5f5f5;
    border-top: 1px solid #ddd;
    border-bottom-right-radius: 3px;
    border-bottom-left-radius: 3px;
}

</style>

<body>

    <div id="wrapper">

        <!-- Navigation -->
        <nav class="navbar navbar-inverse navbar-fixed-top" role="navigation">
            
			<!-- Left_Header(Display User Type) -->
			<div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-ex1-collapse">
                    <!-- Drop down bar in small screen -->
					<span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>				
				<a class="navbar-brand" href="index.php">Administrator</a>
            </div>		
            
			<!-- Middle_Header(Display User Name and ID) -->
			<div class="top-nav-right">
                <a class="navbar-brand" href="#"><i class="fa fa-user"></i>  <?php echo $row_admin['admin_name']; ?>  <?php echo $row_admin['admin_id']; ?></a>
            </div>	
			
			<!-- Logout -->
            <ul class="nav navbar-right top-nav">
				<li class="dropdown">												
					<a href="#" class="logout"><i class="fa fa-fw fa-power-off"></i> Log Out</a>
                </li>
            </ul>
            
			<!-- Sidebar Menu Items - These collapse to the responsive navigation menu on small screens -->
            <div class="collapse navbar-collapse navbar-ex1-collapse">
                <ul class="nav navbar-nav side-nav">
                    
					<!-- Dashboard -->
					<li>
                        <a href="index.php"><i class="glyphicon glyphicon-home"></i>  &nbsp; Dashboard</a>
                    </li>
                    
					<!-- Profile -->
                    <li class="active">
                        <a href="javascript:;" data-toggle="collapse" data-target="#list0"><i class="fa fa-fw fa-user"></i>  &nbsp; Profile <i class="fa fa-fw fa-caret-down"></i></a>
                        <ul id="list0" class="collapse in" >
							<li>
                                <a href="profile.php"> Display Profile</a>
                            </li>                            
							<li>
                                <a href="profile_edit.php"  style="color:white;background-color:black;"> Edit Profile</a>
                            </li>
							<li>
                                <a href="profile_reset.php"> Reset Password</a>
                            </li>							
                        </ul>						
                    </li>
					
					<!-- Postgraduate -->				
                    <li>
                        <a href="javascript:;" data-toggle="collapse" data-target="#list1"><i class="fa fa-user-circle-o"></i>  &nbsp; Postgraduate <i class="fa fa-fw fa-caret-down"></i></a>
                        <ul id="list1" class="collapse" >
							<li>
                                <a href="profile_viewstudent.php"> Postgraduate Info</a>
                            </li>							
							<li>
                                <a href="reg_approvalregistration.php"> Postgraduate Registration</a>
                            </li>                            
							<li>
                                <a href="profile_editstudent.php"> Edit Postgraduate Status</a>
                            </li>							
                        </ul>						
                    </li>
					
					<!-- Supervisor -->
					<li>						
						<a href="javascript:;" data-toggle="collapse" data-target="#list2"><i class="fa fa-users"></i>  &nbsp; Supervisor<i class="fa fa-fw fa-caret-down"></i></a>
                        <ul id="list2" class="collapse">
                            <li>
                                <a href="profile_viewsupervisor.php">Supervisor Info </a>
                            </li>
                            <li>
                                <a href="reg_addsupervisor.php">Supervisor Registration</a>
                            </li>
							<li>
                                <a href="profile_editsupervisor.php"> Edit Supervisor Status</a>
                            </li>	
                            <li>
                                <a href="reg_position.php">Position Info</a>
                            </li>
							<li>
                                <a href="reg_addposition.php">Position Registration</a>
                            </li>
                        </ul>
                    </li>
					
					<!-- Programme -->
                    <li>
                        <a href="javascript:;" data-toggle="collapse" data-target="#list3"><i class="fa fa-university"></i>  &nbsp; Programme <i class="fa fa-fw fa-caret-down"></i></a>
                        <ul id="list3" class="collapse">
                            <li>
                                <a href="p_reg_programme.php">Programme Info </a>
                            </li>
                            <li>
                                <a href="p_reg_addprogramme.php">Programme Registration</a>
                            </li>
						</ul>
                    </li>

					<!-- Coursework -->
                    <li>
                        <a href="javascript:;" data-toggle="collapse" data-target="#list4"><i class="glyphicon glyphicon-book"></i>  &nbsp; Coursework <i class="fa fa-fw fa-caret-down"></i></a>
                        <ul id="list4" class="collapse">
                            <li>
                                <a href="p_reg_coursework.php">Coursework Info </a>
                            </li>
                            <li>
                                <a href="p_reg_addcoursework.php">Coursework Registration</a>
                            </li>
                            <li>
                                <a href="p_reg_subject.php">Subject Info </a>
                            </li>
                            <li>
                                <a href="p_reg_addsubject.php">Subject Registration</a>
                            </li>
						</ul>
                    </li>

					<!-- Research -->
                    <li>
                        <a href="javascript:;" data-toggle="collapse" data-target="#list5"><i class="glyphicon glyphicon-education"></i>  &nbsp; Research <i class="fa fa-fw fa-caret-down"></i></a>
                        <ul id="list5" class="collapse">
                            <li>
                                <a href="p_reg_research.php">Research Info </a>
                            </li>
                            <li>
                                <a href="p_reg_addresearch.php">Research Registration</a>
                            </li>
                            <li>
                                <a href="p_reg_field.php">Field Info </a>
                            </li>
                            <li>
                                <a href="p_reg_addfield.php">Field Registration</a>
                            </li>
						</ul>
                    </li>
					
					<!-- Finance -->
                    <li>
                        <a href="javascript:;" data-toggle="collapse" data-target="#list6"><i class="glyphicon glyphicon-usd"></i>  &nbsp; Finance <i class="fa fa-fw fa-caret-down"></i></a>
                        <ul id="list6" class="collapse ">
                            <li>
                                <a href="finance_editAcc.php" > Student Finance List</a>
                            </li>
                            <li>
                                <a href="finance_setpayment.php"> Add transaction</a>
                            </li>
                            <li>
                                <a href="finance_addgrant.php"> Add grant</a>
                            </li>
                        </ul>
                    </li>
										
					<!-- User Guideline -->
                    <li>
                        <a href="userguide.php"><i class="glyphicon glyphicon-question-sign"></i>  &nbsp; User Guideline</a>
                    </li>
					
                </ul>
            </div>
            <!-- /.navbar-collapse -->
        </nav>

        <!-- content -->
		<div id="page-wrapper" style="min-height:400px;">
            <div class="container-fluid">
				
				<!-- Heading -->
				<h2>Profile Edit</h2>
				
				<div class="panel panel-default">
					<div class="panel-body">

				<div class="col-md-3 col-lg-3" align="center">
					<div class="panel panel-default">
						<div class="panel-body">						
								
							<!-- user profile pic -->
							<form class="form-horizontal" id="form111" role="form" method ="post" action="" enctype="multipart/form-data">
								<?php 											
									if($row_admin['Profile_Picture']=="" || $row_admin['Profile_Ext']==".")
									{
									?>
										<img alt="User Pic" src="../source/picture/user/defaultuser.jpg" class="img-rounded img-responsive pic">
										<input class='form-control' type='file' name='image' required>						
									<?php
									}
									else
									{
										echo "<img alt='User Pic' src='../source/picture/user/".$row_admin['Profile_Picture'].$row_admin['Profile_Ext']."' class='img-rounded img-responsive pic' >
											  <input class='form-control' type='file' name='image' required>";
									}
								?> 
								</br>
								<button type="submit" class="btn btn-default btn-block" style="background-color: #e4e4e4;" name='Submit'><i class="fa fa-upload"> Upload Image</i></button>
							</form>																		
						</div>
					</div>
				</div>

				<div class="col-md-9 col-lg-9">
					<div class="panel panel-default">
						<div class="panel-body">					
							
							<form method="post">
								<!-- user information -->
								<table class="table table-user-information">
									<tbody>
									<tr>
										<td>Admin ID	:</td>
										<td><input type="text" class="form-control" value="<?php echo $_SESSION['admin_id'];?>" disabled></td>
									</tr>
									<tr>
										<td>Admin Name	:</td>
										<td><input type="text" class="form-control" value="<?php echo $row_admin['admin_name'];?>" disabled></td>
									</tr>
									<tr>
										<td>Admin Email :</td>
										<td><input type="email" class="form-control" name= "admin_mail" value="<?php echo $row_admin['admin_mail'];?>"></td>
									</tr>
									</tbody>
								</table>
								<button type="submit" class="btn btn-block" id="btnSubmit" name="btnSubmit"><i class="glyphicon glyphicon-edit"></i> Submit</button>								
							</form>
						</div>
					</div>
				</div>
			</div>
            <!-- /.container-fluid -->

        </div>
        <!-- /#page-wrapper -->

    </div>
    <!-- /#wrapper -->

</body>

</html>
	
<script>
$(document).ready(function() {
	
	//logout confirmation
	$(".logout").click(function(){		
		swal({
			title: 'Logout',
			text: "Logout from Postgraduate Management System",
			type: 'warning',
			showCancelButton: true,
			confirmButtonColor: '#3085d6',
			cancelButtonColor: '#d33',
			confirmButtonText: 'Yes'
		}).then(function () {
				window.location.href ="../logout.php";
		})	
	});		
});
</script>

<!-- profile picture code -->
<?php
	//define a maxim size for the uploaded images in Kb
	define ("MAX_SIZE","8000"); 
	//This function reads the extension of the file. It is used to determine if the
	// file  is an image by checking the extension.
	 function getExtension($str) {
			 $i = strrpos($str,".");
			 if (!$i) { return ""; }
			 $l = strlen($str) - $i;
			 $ext = substr($str,$i+1,$l);
			 return $ext;
	 }

	//This variable is used as a flag. The value is initialized with 0 (meaning no 
	// error  found)  
	//and it will be changed to 1 if an errro occures.  
	//If the error occures the file will not be uploaded.
	$errors=0;

	//checks if the form has been submitted
	if(isset($_POST['Submit'])) 
	{
		//reads the name of the file the user submitted for uploading
		$image=$_FILES['image']['name'];
		//if it is not empty
		if ($image) 
		{
		//get the original name of the file from the clients machine
			$filename = stripslashes($_FILES['image']['name']);
		//get the extension of the file in a lower case format
			$extension = getExtension($filename);
			$extension = strtolower($extension);
		//if it is not a known extension, we will suppose it is an error and 
		// will not  upload the file,  
		//otherwise we will do more tests
			if (($extension != "jpg") && ($extension != "jpeg") && ($extension !="png") && ($extension != "gif")) 
			{
			//print error message
				echo "<script>console.log('Unknown extension!')</script>";
				$errors=1;
			}
			else
			{
				//get the size of the image in bytes
				 //$_FILES['image']['tmp_name'] is the temporary filename of the file
				 //in which the uploaded file was stored on the server
				 $size=filesize($_FILES['image']['tmp_name']);

				//compare the size with the maxim size we defined and print error if bigger
				if ($size > MAX_SIZE*1024)
				{
					echo "<script>console.log('You have exceeded the size limit!')</script>";
					$errors=1;
				}

				//we will give an unique name, for example the time in unix time format
				$image_name=$row_admin['admin_id'].'.'.$extension;
				//the new name will be containing the full path where will be stored (images folder)
				$newname="../source/picture/user/".$image_name;
				//we verify if the image has been uploaded, and print error instead
				$copied = copy($_FILES['image']['tmp_name'], $newname);
				if (!$copied) 
				{
					echo "<script>console.log('Copy unsuccessfull!')</script>";
					$errors=1;
				}
			}
		}
	}
	
	//If no errors registred, print the success message
	 if(isset($_POST['Submit']) && !$errors) 
	 {
		echo "<script>console.log('File Uploaded Successfully!')</script>";
		
		$sql2="update admin set Profile_Picture='".$row_admin['admin_id']."',Profile_Ext='.$extension' where admin_id='$admin_id'";
		if(mysqli_query($con,$sql2))
		{
			echo "<script>console.log('sql Successfully!')</script>";
			
		}
		header("Location: profile_edit.php");
		mysqli_close($con);
	 }
?>

<!-- form edit -->
<?php
if(isset($_POST['btnSubmit']))
{
	
	$admin_mail=$_POST['admin_mail'];
	
	$sql1 = "UPDATE ADMIN SET 
			admin_mail = '$admin_mail'
			where admin_id = '".$row_admin['admin_id']."'";
	
	if (mysqli_query($con, $sql1)) {
		?>
		<script>
				swal({
					title: "Successfull!",
					text: "Profile Edit Successful!",
					type: "success" 
				}).then(function() {
					window.location.href ="profile_edit.php";
				});
		</script>
	<?php
	}
	else{
		?>
		<script type="text/javascript">
			alert("failed");
		</script>
	<?php		
	}
}
?>