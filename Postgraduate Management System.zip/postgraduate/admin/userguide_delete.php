<?php
	include("../dataconnect.php");
	if(isset($_POST["file"])){
		$file=$_POST["file"];
		unlink("../source/document/user guideline/".$file);
	}
?>