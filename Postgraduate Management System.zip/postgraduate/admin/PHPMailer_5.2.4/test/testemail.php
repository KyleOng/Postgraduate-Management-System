<?php

require_once("PHPMailer_5.2.4/class.phpmailer.php");

	$mail = new PHPMailer(); //New instance, with exceptions enabled

	$mail->IsSMTP();        	// tell the class to use SMTP
	$mail->SMTPDebug = 1;
	$mail->SMTPAuth   = true;	// enable SMTP authentication
	$mail->SMTPSecure = 'ss1';
	$mail->Port       = 465;                    // set the SMTP server port
	$mail->IsHTML(true); // send as HTML
	$mail->Host       = "smtp.gmail.com"; // SMTP server
	$mail->Username   = "venus9528@gmail.com";     // SMTP server username
	$mail->Password   = "Wai_kuen28";            // SMTP server password

	$mail->SetFrom ("venus9528@gmail.com");

	

	$mail->Subject  = "First PHPMailer Message";

	$mail->Body    = "To view the message, please use an HTML compatible email viewer!"; // optional, comment out and test
	

	$mail->AddAddress("1131121177@student.mmu.edu.my");


	if($mail->Send())
	{
	echo "Message has been sent.";
	}
	else
	{
	echo "Mailer Error.";
	}
?>