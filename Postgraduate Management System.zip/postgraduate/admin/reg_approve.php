<?php
	include("../dataconnect.php");
	if(isset($_POST["id"])){
		$id=$_POST["id"];
		$sql="UPDATE registration set reg_status='Approved' where reg_id='".$id. "'";
		mysqli_query($con,$sql);
		
		$loop=mysqli_query($con,"SELECT * FROM student");
		$entry=1;
		while(mysqli_fetch_array($loop)){
			$entry++;
		}
		
		$result=mysqli_query($con,"SELECT * FROM registration where reg_id='".$id. "'");
		$row=mysqli_fetch_array($result);
		$stud_name=$row["stud_name"];
		$stud_type=$row["stud_type"];
		$stud_email=$row["stud_email"];
		$stud_original_password=rand(1000000,9999999);
		$stud_password=md5($stud_original_password);
		
		$time=time();
		$year=substr(date('Y',$time),2);
		$month=date('md',$time);
		$intake_date=date('Y-m-d',$time);
		$stud_code=$year.$month.str_pad( $entry, 3, "0", STR_PAD_LEFT );
		
		include("reg_studentemail.php");
		mysqli_query($con,"INSERT into student(stud_status,reg_id,stud_password,stud_type,stud_code,intake_date)value('Active','".$id."','$stud_password', '$stud_type','$stud_code','$intake_date')");
		
		if($stud_type=="Research") mysqli_query($con,"INSERT into researchstd(stud_id,res_status)value((SELECT stud_id FROM student where reg_id=".$id."),'Topic submission')");
		if($stud_type=="Coursework") mysqli_query($con,"INSERT into courseworkstd(stud_id,cw_cgpa,cw_credit_hr)value((SELECT stud_id FROM student where reg_id=".$id."),'0','0')");
			
		
	}
?>