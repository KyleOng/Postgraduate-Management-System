<?php
	include("../dataconnect.php");
	if($_SESSION["loggedins"]!=1)
	{
		echo"<script> window.location.href ='../login.php';</script>";
	}
	session_start();
	$admin_id = $_SESSION["admin_id"];
	$sql_admin = "select * from ADMIN where admin_id='$admin_id'";
	$row_admin = mysqli_fetch_assoc(mysqli_query($con,$sql_admin));
?>

<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>Admin</title>

    <!-- Bootstrap Core CSS -->
    <link href="../source/css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom CSS -->
    <link href="../source/css/sb-admin.css" rel="stylesheet">

    <!-- Morris Charts CSS -->
    <link href="../source/css/plugins/morris.css" rel="stylesheet">

	<!-- Awesome Fonts -->
    <link href="../source/font-awesome-4.7.0/css/font-awesome.min.css" rel="stylesheet" type="text/css">	
	
	<!-- Sweet Alert -->
	<script src="../source/sweetalert/dist/sweetalert2.min.js"></script> 
	<link rel="stylesheet" type="text/css" href="../source/sweetalert/dist/sweetalert2.css">
   
   <!-- jQuery -->
    <script src="../source/js/jquery.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="../source/js/bootstrap.min.js"></script>
</head>

<body>

    <div id="wrapper">

        <!-- Navigation -->
        <nav class="navbar navbar-inverse navbar-fixed-top" role="navigation">
            
			<!-- Left_Header(Display User Type) -->
			<div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-ex1-collapse">
                    <!-- Drop down bar in small screen -->
					<span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>				
				<a class="navbar-brand" href="index.php">Administrator</a>
            </div>		
            
			<!-- Middle_Header(Display User Name and ID) -->
			<div class="top-nav-right">
                <a class="navbar-brand" href="#"><i class="fa fa-user"></i>  <?php echo $row_admin['admin_name']; ?>  <?php echo $row_admin['admin_id']; ?></a>
            </div>	
			
			<!-- Logout -->
            <ul class="nav navbar-right top-nav">
				<li class="dropdown">												
					<a href="#" class="logout"><i class="fa fa-fw fa-power-off"></i> Log Out</a>
                </li>
            </ul>
            
			<!-- Sidebar Menu Items - These collapse to the responsive navigation menu on small screens -->
            <div class="collapse navbar-collapse navbar-ex1-collapse">
                <ul class="nav navbar-nav side-nav">
                    
					<!-- Dashboard -->
					<li class="active">
                        <a href="index.php"><i class="glyphicon glyphicon-home"></i>  &nbsp; Dashboard</a>
                    </li>
                    
					<!-- Profile -->
                    <li>
                        <a href="javascript:;" data-toggle="collapse" data-target="#list0"><i class="fa fa-fw fa-user"></i>  &nbsp; Profile <i class="fa fa-fw fa-caret-down"></i></a>
                        <ul id="list0" class="collapse" >
							<li>
                                <a href="profile.php"> Display Profile</a>
                            </li>                            
							<li>
                                <a href="profile_edit.php"> Edit Profile</a>
                            </li>
							<li>
                                <a href="profile_reset.php"> Reset Password</a>
                            </li>							
                        </ul>						
                    </li>
					
					<!-- Postgraduate -->				
                    <li>
                        <a href="javascript:;" data-toggle="collapse" data-target="#list1"><i class="fa fa-user-circle-o"></i>  &nbsp; Postgraduate <i class="fa fa-fw fa-caret-down"></i></a>
                        <ul id="list1" class="collapse" >
							<li>
                                <a href="profile_viewstudent.php"> Postgraduate Info</a>
                            </li>							
							<li>
                                <a href="reg_approvalregistration.php"> Postgraduate Registration</a>
                            </li>                            
							<li>
                                <a href="profile_editstudent.php"> Edit Postgraduate Status</a>
                            </li>							
                        </ul>						
                    </li>
					
					<!-- Supervisor -->
					<li>						
						<a href="javascript:;" data-toggle="collapse" data-target="#list2"><i class="fa fa-users"></i>  &nbsp; Supervisor<i class="fa fa-fw fa-caret-down"></i></a>
                        <ul id="list2" class="collapse">
                            <li>
                                <a href="profile_viewsupervisor.php">Supervisor Info </a>
                            </li>
                            <li>
                                <a href="reg_addsupervisor.php">Supervisor Registration</a>
                            </li>
							<li>
                                <a href="profile_editsupervisor.php"> Edit Supervisor Status</a>
                            </li>	
                            <li>
                                <a href="reg_position.php">Position Info</a>
                            </li>
							<li>
                                <a href="reg_addposition.php">Position Registration</a>
                            </li>
                        </ul>
                    </li>
					
					<!-- Programme -->
                    <li>
                        <a href="javascript:;" data-toggle="collapse" data-target="#list3"><i class="fa fa-university"></i>  &nbsp; Programme <i class="fa fa-fw fa-caret-down"></i></a>
                        <ul id="list3" class="collapse">
                            <li>
                                <a href="p_reg_programme.php">Programme Info </a>
                            </li>
                            <li>
                                <a href="p_reg_addprogramme.php">Programme Registration</a>
                            </li>
						</ul>
                    </li>

					<!-- Coursework -->
                    <li>
                        <a href="javascript:;" data-toggle="collapse" data-target="#list4"><i class="glyphicon glyphicon-book"></i>  &nbsp; Coursework <i class="fa fa-fw fa-caret-down"></i></a>
                        <ul id="list4" class="collapse">
                            <li>
                                <a href="p_reg_coursework.php">Coursework Info </a>
                            </li>
                            <li>
                                <a href="p_reg_addcoursework.php">Coursework Registration</a>
                            </li>
                            <li>
                                <a href="p_reg_subject.php">Subject Info </a>
                            </li>
                            <li>
                                <a href="p_reg_addsubject.php">Subject Registration</a>
                            </li>
						</ul>
                    </li>

					<!-- Research -->
                    <li>
                        <a href="javascript:;" data-toggle="collapse" data-target="#list5"><i class="glyphicon glyphicon-education"></i>  &nbsp; Research <i class="fa fa-fw fa-caret-down"></i></a>
                        <ul id="list5" class="collapse">
                            <li>
                                <a href="p_reg_research.php">Research Info </a>
                            </li>
                            <li>
                                <a href="p_reg_addresearch.php">Research Registration</a>
                            </li>
                            <li>
                                <a href="p_reg_field.php">Field Info </a>
                            </li>
                            <li>
                                <a href="p_reg_addfield.php">Field Registration</a>
                            </li>
						</ul>
                    </li>
					
					<!-- Finance -->
                    <li>
                        <a href="javascript:;" data-toggle="collapse" data-target="#list6"><i class="glyphicon glyphicon-usd"></i>  &nbsp; Finance <i class="fa fa-fw fa-caret-down"></i></a>
                        <ul id="list6" class="collapse ">
                            <li>
                                <a href="finance_editAcc.php" > Student Finance List</a>
                            </li>
                            <li>
                                <a href="finance_setpayment.php"> Add transaction</a>
                            </li>
                            <li>
                                <a href="finance_addgrant.php"> Add grant</a>
                            </li>
                        </ul>
                    </li>
										
					<!-- User Guideline -->
                    <li>
                        <a href="userguide.php"><i class="glyphicon glyphicon-question-sign"></i>  &nbsp; User Guideline</a>
                    </li>
					
                </ul>
            </div>
            <!-- /.navbar-collapse -->
        </nav>

        <!-- content inside dashboard -->
		<div id="page-wrapper" style="min-height:400px;">
            <div class="container-fluid">

				<div class="row">					
						
					<!-- 1st item -->
					<div class="item col-xs-6 col-md-4">
						<div class="thumbnail">
							<a href="profile.php">
								<img src="../source/picture/profile.png" alt="Profile Status" style="width:50%">
								<div class="caption">
									<p>Profile Status</p>
								</div>
							</a>
						</div>
					</div>
					
					<!-- 2nd item -->
					<div class="item col-xs-6 col-md-4">
						<div class="thumbnail">
							<a href="profile_viewstudent.php">
								<img src="../source/picture/postgraduate.png" alt="Postgraduate Info" style="width:50%">
								<div class="caption">
									<p>Postgraduate Info</p>
								</div>
							</a>
						</div>
					</div>
					
					<!-- 3th item -->
					<div class="item col-xs-6 col-md-4">
						<div class="thumbnail">
							<a href="profile_viewsupervisor.php">
								<img src="../source/picture/supervisor.png" alt="Supervisor Info" style="width:50%">
								<div class="caption">
									<p>Supervisor Info</p>
								</div>
							</a>
						</div>
					</div>
					
					<!-- 4th item -->
					<div class="item col-xs-6 col-md-4">
						<div class="thumbnail">
							<a href="reg_position.php">
								<img src="../source/picture/position.png" alt="Research Status" style="width:50%">
								<div class="caption">
									<p>Position Info</p>
								</div>
							</a>
						</div>
					</div>

					<!-- 5th item  -->
					<div class="item col-xs-6 col-md-4">
						<div class="thumbnail">
							<a href="p_reg_programme.php">
								<img src="../source/picture/programme.png" alt="Programme Info" style="width:50%">
								<div class="caption">
									<p>Programme Info</p>
								</div>
							</a>
						</div>
					</div>
					
					<!-- 6th item -->
					<div class="item col-xs-6 col-md-4">
						<div class="thumbnail">
							<a href="p_reg_coursework.php">
								<img src="../source/picture/coursework.png" alt="Coursework Info" style="width:50%">
								<div class="caption">
									<p>Coursework Info</p>
								</div>
							</a>
						</div>
					</div>								

					<!-- 7th item -->
					<div class="item col-xs-6 col-md-4">
						<div class="thumbnail">
							<a href="p_reg_research.php">
								<img src="../source/picture/research.png" alt="Research Info" style="width:50%">
								<div class="caption">
									<p>Research Info</p>
								</div>
							</a>
						</div>
					</div>

					<!-- 8th item  -->
					<div class="item col-xs-6 col-md-4">
						<div class="thumbnail">
							<a href="finance_editAcc.php">
								<img src="../source/picture/money.png" alt="Finance" style="width:50%">
								<div class="caption">
									<p>Finance</p>
								</div>
							</a>
						</div>
					</div>
					
					<!-- 9th item -->
					<div class="item col-xs-6 col-md-4">
						<div class="thumbnail">
							<a href="userguide.php">
								<img src="../source/picture/guideline.png" alt="User Guideline" style="width:50%">
								<div class="caption">
									<p>User Guideline</p>
								</div>
							</a>
						</div>
					</div>	
					
				</div>			
					
            </div>
            <!-- /.container-fluid -->

        </div>
        <!-- /#page-wrapper -->

    </div>
    <!-- /#wrapper -->

    <script>
	
	//logout confirmation
	$(document).ready(function() {	
		$(".logout").click(function(){		
			swal({
				title: 'Logout',
				text: "Logout from Postgraduate Management System",
				type: 'warning',
				showCancelButton: true,
				confirmButtonColor: '#3085d6',
				cancelButtonColor: '#d33',
				confirmButtonText: 'Yes'
			}).then(function () {
					window.location.href ="../logout.php";
			})			
		});		
	});
	</script>

</body>

</html>
