 <?php
	include("../dataconnect.php");
	if($_SESSION["loggedins"]!=1)
	{
		echo"<script> window.location.href ='../login.php';</script>";
	}
    session_start();
	//Student general information
	$stud_id = $_SESSION['stud_id'];
	$sql_student = "select * from STUDENT S, REGISTRATION R where 
					S.reg_id = R.reg_id and 
					stud_id = '$stud_id' ";
	$row_student = mysqli_fetch_assoc(mysqli_query($con,$sql_student));
	
	if($_SESSION['stud_type'] == 'Research')
	{
		$title = "Research Student";
	}
	else
	{
		$title = "Coursework Student";
	}
	
?>

<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Postgraduate</title>

    <!-- Bootstrap Core CSS -->
    <link href="../source/css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom CSS -->
    <link href="../source/css/sb-admin.css" rel="stylesheet">

    <!-- Custom Fonts -->
    <link href="../source/font-awesome-4.7.0/css/font-awesome.min.css" rel="stylesheet" type="text/css">

    <script src="../source/sweetalert/dist/sweetalert2.min.js"></script> 
    <link rel="stylesheet" type="text/css" href="../source/sweetalert/dist/sweetalert2.css">

</head>
<style>
    a:hover
    {
        text-decoration: none;
    }

    
</style>
<body>

    <div id="wrapper">

        <!-- Navigation -->
        <nav class="navbar navbar-inverse navbar-fixed-top" role="navigation">
            
			<!-- Left_Header(Display User Type) -->
			<div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-ex1-collapse">
                    <!-- Drop down bar in small screen -->
					<span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>				
				<a class="navbar-brand" href="index.php"><?php echo $title; ?></a>
            </div>		
            
			<!-- Middle_Header(Display User Name and ID) -->
			<div class="top-nav-right">
                <a class="navbar-brand" href="profile.php"><i class="fa fa-user"></i>  <?php echo $row_student['stud_name']; ?>  <?php echo $row_student['stud_code']; ?></a>
            </div>	
			
			<!-- Logout -->
            <ul class="nav navbar-right top-nav">
				<li class="dropdown">												
					<a href="#" class="logout"><i class="fa fa-fw fa-power-off"></i> Log Out</a>
                </li>
            </ul>
            
			<!-- Sidebar Menu Items - These collapse to the responsive navigation menu on small screens -->
            <div class="collapse navbar-collapse navbar-ex1-collapse">
                <ul class="nav navbar-nav side-nav">             
                    <!-- Dashboard -->
					<li>
                        <a href="index.php"><i class="glyphicon glyphicon-home"></i>  &nbsp; Dashboard</a>
                    </li>
					
					<!-- Profile -->
                    <li>
                        <a href="javascript:;" data-toggle="collapse" data-target="#list0"><i class="fa fa-fw fa-user"></i>  &nbsp; Profile <i class="fa fa-fw fa-caret-down"></i></a>
                        <ul id="list0" class="collapse">
							<li>
                                <a href="profile.php"> Display Profile</a>
                            </li>                            
							<li>
                                <a href="profile_edit.php"> Edit Profile</a>
                            </li>
							<li>
                                <a href="profile_reset.php"> Reset Password</a>
                            </li>							
                        </ul>						
                    </li>
					
					<!-- Coursework -->
                    <li id="sidebar_cw" class="coursework active">
                        <a href="javascript:;" data-toggle="collapse" data-target="#list1"><i class="glyphicon glyphicon-book"></i>  &nbsp; Coursework <i class="fa fa-fw fa-caret-down"></i></a>
                        <ul id="list1" class="collapse sidebar_cw in">
							<li>
                                <a href="CW_enroll.php"> Enroll Class </a>
                            </li>
                            <li>
                                <a href="CW_viewclass.php" style="color:white;background-color:black;"> View Class info </a>
							<li>
								<a href="CW_viewresult.php"> View Result </a>
							</li>
                        </ul>
                    </li>

					<!-- Research -->					
                    <li id="sidebar_res" class="research">
                        <a href="javascript:;" data-toggle="collapse" data-target="#list2"><i class="glyphicon glyphicon-education"></i>  &nbsp; Research <i class="fa fa-fw fa-caret-down"></i></a>
                        <ul id="list2" class="collapse sidebar_res">
                            <li>
                                <a href="res_status.php"> Status</a>
                            </li>
                            <li>
                                <a href="res_topic.php"> Field & Topic</a>
                            </li>
                            <li>
                                <a href="res_sup.php"> Supervisor Selection</a>
                            </li>
							<li>
                                <a href="res_upload.php"> Document Upload</a>
                            </li>
                        </ul>
                    </li>
					
					<!-- Finance -->
					<li>
                        <a href="javascript:;" data-toggle="collapse" data-target="#list3"><i class="glyphicon glyphicon-usd"></i>  &nbsp; Finance <i class="fa fa-fw fa-caret-down"></i></a>
                        <ul id="list3" class="collapse ">
                            <li>
                                <a href="finance_account.php" > Account Enquiry</a>
                            </li>
                            <li>
                                <a href="finance_grant.php"> View Grant</a>
                            </li>
                            <li>
                                <a href="finance_transaction.php"> Transaction History</a>
                            </li>
                        </ul>
                    </li>
					
					<!-- User guideline -->
                    <li>
                        <a href="userguide.php"><i class="glyphicon glyphicon-question-sign"></i>  &nbsp; User guideline</a>
                    </li>
                </ul>
            </div>
            <!-- /.navbar-collapse -->
        </nav>

        <div id="page-wrapper" style="min-height:660px;">
            <div class="container-fluid">
               <h2>View class</h2><br/>
                        <div class=" col-md-12 col-lg-12 "> 
                    <table class="table table-responsive" style="width: 100%;">
                        <tbody>
                          <tr>
                            <th>No</th>
                            <th>Class Code</th>
                            <th>Subject Name</th>
                            <th>Supervisor</th>
                            <th>Time</th>
                            <th>Venue</th>
                            <th>Action/Status</th>
                          </tr>
                          <?php
                                $sql1="select * from enrollment INNER JOIN class ON enrollment.class_id=class.class_id INNER JOIN subject ON class.subject_id=subject.subject_id INNER JOIN supervisor ON class.sup_id=supervisor.sup_id WHERE enrollment.stud_id ='$stud_id' ";
                                $result1=mysqli_query($con,$sql1);

                                $i=1;
                                if(mysqli_num_rows($result1)!=0)
                                {
                                    while($row1=mysqli_fetch_assoc($result1))
                                    {
                                ?>
                                <tr>
                                    <td><?php echo $i++ ;?></td>
                                    <td><?php echo $row1['class_code'];?></td>
                                    <td><?php echo $row1['subject_name'];?></td>
                                    <td><?php echo $row1['sup_name'];?></td>
                                    <td><?php echo $row1['class_day'].','.$row1['class_time']?></td>
                                    <td><?php echo $row1['class_venue']?></td>

                                    <?php
                                    if($row1['enrollment_status']=='Dropped')
                                    {
                                        ?>
                                    <td>Dropped</td>
                                    <?php
                                    }
									else if($row1['enrollment_status']=='End')
									{
										?>
									<td>End</td>
									<?php
									}
                                    else
                                    {
                                        ?>
                                        <td><a href="CW_dropclass.php?eid=<?php echo $row1['enrollment_id']; ?>" class="remove" onclick="return dropclass<?php echo $row1['class_code'];?>()"><span style="color:red;">Drop Class</span></a></td>
                                    <?php
                                    }
                                    ?>
                                </tr>

                                <script>
                                function dropclass<?php echo $row1['class_code'];?>()
                                {
                                        return confirm("Are you sure you want to DEACTIVE class <?php echo $row1['class_code']; ?> ?");
                                }
                                </script>

                                <?php
                                    }
                                }
                                 else
                        {
                        ?>
                        <tr>
                          <td colspan='7' style="text-align:center; font-size:1.4em;">No record found!</td>
                        </tr>
                        <?php
                        }
                           ?>
                        </tbody>
                  </table>
                  <a href="CW_enroll.php"><button type="button" class="btn btn-default btn-block addcbtn" style="background-color: #e4e4e4; "><i class="glyphicon glyphicon-plus"></i> Enroll class</button></a>
            </div>
            </div>
            <!-- /.container-fluid -->

        </div>
        <!-- /#page-wrapper -->

    </div>
    <!-- /#wrapper -->

    <!-- jQuery -->
    <script src="//code.jquery.com/jquery-1.9.1.js"></script>
    <!-- jQuery -->

    <!-- Bootstrap Core JavaScript -->
    <script src="../source/js/bootstrap.min.js"></script>
    <script src="//ajax.aspnetcdn.com/ajax/jquery.validate/1.9/jquery.validate.min.js"></script>
    <script type="text/javascript">

    $(document).ready(function() {
		
		//Determination of student type
		var stud_type = "<?php echo $_SESSION['stud_type']; ?>";
		if (stud_type == "Coursework")
		{
			$('.research').css({'display': 'none'});
		}
		else if (stud_type == "Research")
		{
			$('.coursework').css({'display': 'none'});
		}
		
		//logout confirmation
		$(".logout").click(function(){		
			swal({
				title: 'Logout',
				text: "Logout from Postgraduate Management System",
				type: 'warning',
				showCancelButton: true,
				confirmButtonColor: '#3085d6',
				cancelButtonColor: '#d33',
				confirmButtonText: 'Yes'
			}).then(function () {
					window.location.href ="../logout.php";
			})			
		});		
	});
	
    $(window).on('resize', function() {
		if($(window).width() < 400) 
		{
			$('.item').addClass('col-xs-12 col-md-6');
			$('.item').removeClass('col-xs-6 col-md-4');
		}
		else
		{
			$('.item').addClass('col-xs-6 col-md-4');
			$('.item').removeClass('col-xs-12 col-md-6');
		}
	})


</script>

</body>

</html>
