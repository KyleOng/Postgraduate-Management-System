<?php
	include("../dataconnect.php");
	if($_SESSION["loggedins"]!=1)
	{
		echo"<script> window.location.href ='../login.php';</script>";
	}
	session_start();
	$stud_id = $_SESSION['stud_id'];
	
	$sql_student = "select * from STUDENT S, REGISTRATION R where 
					S.reg_id = R.reg_id and
					stud_id='$stud_id'";
	$row_student = mysqli_fetch_assoc(mysqli_query($con,$sql_student));
	
	if($_SESSION['stud_type'] == 'Research')
	{
		$title = "Research Student";
	}
	else
	{
		$title = "Coursework Student";
	}
?>

<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
	
    <title>Postgraduate</title>

    <!-- Bootstrap Core CSS -->
    <link href="../source/css/bootstrap.min.css" rel="stylesheet">

	<!-- Custom CSS -->
    <link href="../source/css/sb-admin.css" rel="stylesheet">
	
	<!-- Awesome Fonts -->
    <link href="../source/font-awesome-4.7.0/css/font-awesome.min.css" rel="stylesheet" type="text/css">
	
	<!-- Sweet Alert -->
	<script src="../source/sweetalert/dist/sweetalert2.min.js"></script> 
	<link rel="stylesheet" type="text/css" href="../source/sweetalert/dist/sweetalert2.css">

	<!-- jQuery -->
    <script src="../source/js/jquery.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="../source/js/bootstrap.min.js"></script>
</head>
<style>
.pfont{
	font-size:20px;
}
.error{
	display: none;
	padding-top: 6px;
	padding-bottom: 6px;
}

</style>
<body>

    <div id="wrapper">

        <!-- Navigation -->
        <nav class="navbar navbar-inverse navbar-fixed-top" role="navigation">
            
			<!-- Left_Header(Display User Type) -->
			<div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-ex1-collapse">
                    <!-- Drop down bar in small screen -->
					<span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>				
				<a class="navbar-brand" href="index.php"><?php echo $title; ?></a>
            </div>		
            
			<!-- Middle_Header(Display User Name and ID) -->
			<div class="top-nav-right">
                <a class="navbar-brand" href="profile.php"><i class="fa fa-user"></i>  <?php echo $row_student['stud_name']; ?>  <?php echo $row_student['stud_code']; ?></a>
            </div>	
			
			<!-- Logout -->
            <ul class="nav navbar-right top-nav">
				<li class="dropdown">												
					<a href="#" class="logout"><i class="fa fa-fw fa-power-off"></i> Log Out</a>
                </li>
            </ul>
            
			<!-- Sidebar Menu Items - These collapse to the responsive navigation menu on small screens -->
            <div class="collapse navbar-collapse navbar-ex1-collapse">
                <ul class="nav navbar-nav side-nav">             
                    <!-- Dashboard -->
					<li>
                        <a href="index.php"><i class="glyphicon glyphicon-home"></i>  &nbsp; Dashboard</a>
                    </li>
					
					<!-- Profile -->
                    <li class="active">
                        <a href="javascript:;" data-toggle="collapse" data-target="#list0"><i class="fa fa-fw fa-user"></i>  &nbsp; Profile <i class="fa fa-fw fa-caret-down"></i></a>
                        <ul id="list0" class="collapse in">
							<li>
                                <a href="profile.php"> Display Profile</a>
                            </li>                            
							<li>
                                <a href="profile_edit.php"> Edit Profile</a>
                            </li>
							<li>
                                <a href="profile_reset.php" style="color:white;background-color:black;"> Reset Password</a>
                            </li>							
                        </ul>						
                    </li>
					
					<!-- Coursework -->
                    <li id="sidebar_cw" class="coursework">
                        <a href="javascript:;" data-toggle="collapse" data-target="#list1"><i class="glyphicon glyphicon-book"></i>  &nbsp; Coursework <i class="fa fa-fw fa-caret-down"></i></a>
                        <ul id="list1" class="collapse sidebar_cw">
							<li>
                                <a href="CW_enroll.php"> Enroll Class </a>
                            </li>
                            <li>
                                <a href="CW_viewclass.php"> View Class info </a>
                            </li>
							<li>
								<a href="CW_viewresult.php"> View Result </a>
							</li>
                        </ul>
                    </li>

					<!-- Research -->					
                    <li id="sidebar_res" class="research">
                        <a href="javascript:;" data-toggle="collapse" data-target="#list2"><i class="glyphicon glyphicon-education"></i>  &nbsp; Research <i class="fa fa-fw fa-caret-down"></i></a>
                        <ul id="list2" class="collapse sidebar_res">
                            <li>
                                <a href="res_status.php"> Status</a>
                            </li>
                            <li>
                                <a href="res_topic.php"> Field & Topic</a>
                            </li>
                            <li>
                                <a href="res_sup.php"> Supervisor Selection</a>
                            </li>
							<li>
                                <a href="res_upload.php"> Document Upload</a>
                            </li>
                        </ul>
                    </li>
					
					<!-- Finance -->
					<li>
                        <a href="javascript:;" data-toggle="collapse" data-target="#list3"><i class="glyphicon glyphicon-usd"></i>  &nbsp; Finance <i class="fa fa-fw fa-caret-down"></i></a>
                        <ul id="list3" class="collapse ">
                            <li>
                                <a href="finance_account.php" > Account Enquiry</a>
                            </li>
                            <li>
                                <a href="finance_grant.php"> View Grant</a>
                            </li>
                            <li>
                                <a href="finance_transaction.php"> Transaction History</a>
                            </li>
                        </ul>
                    </li>
					
					<!-- User guideline -->
                    <li>
                        <a href="userguide.php"><i class="glyphicon glyphicon-question-sign"></i>  &nbsp; User guideline</a>
                    </li>
                </ul>
            </div>
            <!-- /.navbar-collapse -->
        </nav>


        <!-- content inside dashboard -->
		<div id="page-wrapper" style="min-height:400px;">
            <div class="container-fluid">
				
				<h2>Reset Password</h2></br>
				
				<!-- Form of Reset Password-->
				<form method="post"> 
					<!-- Old Password -->
					<div class="row">
						<div class="col-xs-6 col-md-4">
							<p class="pfont"> Password </p>
						</div>
						<div class="col-xs-6 col-md-4">
							<input type="password" class="form-control" name="old_pass" required>
						</div>
					</div>
					<!-- New Password -->
					<div class="row">
						<div class="col-xs-6 col-md-4">
							<p class="pfont"> New Password </p>
						</div>
						<div class="col-xs-6 col-md-4">
							<input type="password" class="form-control" name="new_pass_1" required>
						</div>
					</div>
					<!-- New Password Confirmation-->
					<div class="row">
						<div class="col-xs-6 col-md-4">
							<p class="pfont"> New Password Confirmation</p>
						</div>
						<div class="col-xs-6 col-md-4">
							<input type="password" class="form-control" name="new_pass_2" required>
						</div>
					</div>
					<!-- Error Message -->
					<div class="row" style="margin-top:15px;">
						<div class="col-xs-12 col-md-8">
							<!-- Error Message for Not Equal to Old Password -->
							<div class="alert alert-danger error" id="error_1">
								<span class="glyphicon glyphicon-remove-circle"> Password Incorrect!</span>
							</div>
							<!-- Error Message for Not Equal to New Password -->
							<div class="alert alert-danger error" id="error_2">
								<span class="glyphicon glyphicon-remove-circle"> New Password Comfirmation Error!</span>
							</div>
						</div>
					</div>					
					
					<div class="row">
						<div class="col-xs-12 col-md-8">
							<button type="submit" class="btn btn-block" id="btnSubmit" name="btnSubmit" style="margin-top: 25px;"><i class="glyphicon glyphicon-send"></i> Submit</button>
						</div>
					</div>
				</form>
            </div>
            <!-- /.container-fluid -->

        </div>
        <!-- /#page-wrapper -->

    </div>
    <!-- /#wrapper -->

    <script>
	$(document).ready(function() {
		
		//Determination of student type
		var stud_type = "<?php echo $_SESSION['stud_type']; ?>";
		if (stud_type == "Coursework")
		{
			$('.research').css({'display': 'none'});
		}
		else if (stud_type == "Research")
		{
			$('.coursework').css({'display': 'none'});
		}
		
		//logout confirmation
		$(".logout").click(function(){		
			swal({
				title: 'Logout',
				text: "Logout from Postgraduate Management System",
				type: 'warning',
				showCancelButton: true,
				confirmButtonColor: '#3085d6',
				cancelButtonColor: '#d33',
				confirmButtonText: 'Yes'
			}).then(function () {
					window.location.href ="../logout.php";
			})			
		});
		
		//Password Reset
		
	});
	</script>

</body>

</html>

<?php
if(isset($_POST['btnSubmit']))
{
	
	$old_pass=$_POST['old_pass'];
	$new_pass_1=$_POST['new_pass_1'];
	$new_pass_2=$_POST['new_pass_2'];
	$token = 1;
	
	if(md5($old_pass) != $row_student['stud_password'])
	{
		echo 	"<script>
					$('#error_1').css('display', 'block');					
				</script>";
		$token = 0;
	} 
	if($new_pass_1 != $new_pass_2)
	{
		echo 	"<script>
					$('#error_2').css('display', 'block');					
				</script>";
		$token = 0;
	}
	if($token == 1)
	{
		$sql="UPDATE STUDENT SET 
			stud_password = '".md5($new_pass_1)."' 
			where stud_id = '".$row_student['stud_id']."'";
			
		
		if (mysqli_query($con, $sql)) {
		?>
			<script>
					swal({
						title: "Successfull!",
						text: "Password Reset Successful!",
						type: "success" 
					}).then(function() {
						window.location.href ="profile_reset.php";
					});
			</script>
		<?php
		}
		else{
			?>
			<script type="text/javascript">
				alert("failed");
			</script>
		<?php		
		}
	}
}
?>