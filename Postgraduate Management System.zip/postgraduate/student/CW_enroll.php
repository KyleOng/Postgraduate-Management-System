<?php
	include("../dataconnect.php");
	if($_SESSION["loggedins"]!=1)
	{
		echo"<script> window.location.href ='../login.php';</script>";
	}
	session_start();
	//Student general information
	$stud_id = $_SESSION['stud_id'];
	$sql_student = "select * from STUDENT S, REGISTRATION R where 
					S.reg_id = R.reg_id and 
					stud_id = '$stud_id' ";
	$row_student = mysqli_fetch_assoc(mysqli_query($con,$sql_student));
	
	if($_SESSION['stud_type'] == 'Research')
	{
		$title = "Research Student";
	}
	else
	{
		$title = "Coursework Student";
	}
?> 
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Postgraduate</title>

    <!-- Bootstrap Core CSS -->
    <link href="../source/css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom CSS -->
    <link href="../source/css/sb-admin.css" rel="stylesheet">

    <!-- Morris Charts CSS -->
    <link href="../source/css/plugins/morris.css" rel="stylesheet">

    <!-- Custom Fonts -->
    <link href="../source/font-awesome-4.7.0/css/font-awesome.min.css" rel="stylesheet" type="text/css">

    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->
	
	<!-- Sweet Alert -->
	<script src="../source/sweetalert/dist/sweetalert2.min.js"></script> 
	<link rel="stylesheet" type="text/css" href="../source/sweetalert/dist/sweetalert2.css"> 

</head>
<style>
    #form1 label.passError
    {   font-family: 'Tahoma' !important;
        color:#CC0000;
        font-weight:bold;
        font-size:13px;
        padding-left:20px;
        display:block;
    }
    #form1 label.passValid
    {   font-family: 'Tahoma' !important;
        color:#00bd00;
        font-weight:bold;
        font-size:13px;
        padding-left:20px;
        display:block;
    }

    .passError 
    {   background:url("../source/picture/error.png") no-repeat 2px 2px;
        padding-left: 16px;
    }

    .passValid 
    {   background:url("../source/picture/tick.png") no-repeat 2px 2px;
        padding-left: 16px;
        color:GREEN;
    }
    
</style>
<body>

    <div id="wrapper">

        <!-- Navigation -->
        <nav class="navbar navbar-inverse navbar-fixed-top" role="navigation">
            
			<!-- Left_Header(Display User Type) -->
			<div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-ex1-collapse">
                    <!-- Drop down bar in small screen -->
					<span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>				
				<a class="navbar-brand" href="index.php"><?php echo $title; ?></a>
            </div>		
            
			<!-- Middle_Header(Display User Name and ID) -->
			<div class="top-nav-right">
                <a class="navbar-brand" href="profile.php"><i class="fa fa-user"></i>  <?php echo $row_student['stud_name']; ?>  <?php echo $row_student['stud_code']; ?></a>
            </div>	
			
			<!-- Logout -->
            <ul class="nav navbar-right top-nav">
				<li class="dropdown">												
					<a href="#" class="logout"><i class="fa fa-fw fa-power-off"></i> Log Out</a>
                </li>
            </ul>
            
			<!-- Sidebar Menu Items - These collapse to the responsive navigation menu on small screens -->
            <div class="collapse navbar-collapse navbar-ex1-collapse">
                <ul class="nav navbar-nav side-nav">             
                    <!-- Dashboard -->
					<li>
                        <a href="index.php"><i class="glyphicon glyphicon-home"></i>  &nbsp; Dashboard</a>
                    </li>
					
					<!-- Profile -->
                    <li>
                        <a href="javascript:;" data-toggle="collapse" data-target="#list0"><i class="fa fa-fw fa-user"></i>  &nbsp; Profile <i class="fa fa-fw fa-caret-down"></i></a>
                        <ul id="list0" class="collapse">
							<li>
                                <a href="profile.php"> Display Profile</a>
                            </li>                            
							<li>
                                <a href="profile_edit.php"> Edit Profile</a>
                            </li>
							<li>
                                <a href="profile_reset.php"> Reset Password</a>
                            </li>							
                        </ul>						
                    </li>
					
					<!-- Coursework -->
                    <li id="sidebar_cw" class="coursework active">
                        <a href="javascript:;" data-toggle="collapse" data-target="#list1"><i class="glyphicon glyphicon-book"></i>  &nbsp; Coursework <i class="fa fa-fw fa-caret-down"></i></a>
                        <ul id="list1" class="collapse sidebar_cw in">
							<li>
                                <a href="CW_enroll.php" style="color:white;background-color:black;"> Enroll Class </a>
                            </li>
                            <li>
                                <a href="CW_viewclass.php"> View Class info </a>
                            </li>
							<li>
								<a href="CW_viewresult.php"> View Result </a>
							</li>							
                        </ul>
                    </li>

					<!-- Research -->					
                    <li id="sidebar_res" class="research">
                        <a href="javascript:;" data-toggle="collapse" data-target="#list2"><i class="glyphicon glyphicon-education"></i>  &nbsp; Research <i class="fa fa-fw fa-caret-down"></i></a>
                        <ul id="list2" class="collapse sidebar_res">
                            <li>
                                <a href="res_status.php"> Status</a>
                            </li>
                            <li>
                                <a href="res_topic.php"> Field & Topic</a>
                            </li>
                            <li>
                                <a href="res_sup.php"> Supervisor Selection</a>
                            </li>
							<li>
                                <a href="res_upload.php"> Document Upload</a>
                            </li>
                        </ul>
                    </li>
					
					<!-- Finance -->
					<li>
                        <a href="javascript:;" data-toggle="collapse" data-target="#list3"><i class="glyphicon glyphicon-usd"></i>  &nbsp; Finance <i class="fa fa-fw fa-caret-down"></i></a>
                        <ul id="list3" class="collapse ">
                            <li>
                                <a href="finance_account.php" > Account Enquiry</a>
                            </li>
                            <li>
                                <a href="finance_grant.php"> View Grant</a>
                            </li>
                            <li>
                                <a href="finance_transaction.php"> Transaction History</a>
                            </li>
                        </ul>
                    </li>
					
					<!-- User guideline -->
                    <li>
                        <a href="userguide.php"><i class="glyphicon glyphicon-question-sign"></i>  &nbsp; User guideline</a>
                    </li>
                </ul>
            </div>
            <!-- /.navbar-collapse -->
        </nav>
		
        <form method="post" action="" id="form1" name="form1">
        <div id="page-wrapper" style="min-height:660px;">
            <div class="container-fluid">
               <h2>Enroll Class</h2><br/>

    			<div class=" col-md-12 col-lg-12 "> 
                        <div class="row">
                            <div class="col-md-6">
                                <br/><label for="name">Class ID</label>
                                    <select class="form-control pw" id="csid" name="csid">
                                    <option value="empty">----------Please select a Class Code---------</option>
                                    <?php

                                    $sql10="select * from student INNER JOIN registration ON student.reg_id=registration.reg_id where student.stud_id='$stud_id' ";
                                    $result10=mysqli_query($con,$sql10);
                                    $row10=mysqli_fetch_assoc($result10);
                                    $prog_id=$row10['prog_id'];

                                    $query = $con->query("SELECT * FROM class INNER JOIN subject ON class.subject_id=subject.subject_id WHERE class_status='Active'  and subject.prog_id='$prog_id' ");

                                    $rowCount = $query->num_rows;

                                    if($rowCount > 0)
                                    {
                                        while($row = $query->fetch_assoc())
                                        { 
                                            echo '<option value="'.$row['class_id'].'">'.$row['class_code'].'</option>';
                                        }
                                    }
                                    else
                                    {
                                            echo '<option value="">Class ID not available</option>';
                                    }

                                    ?>
                                    </select>
                            </div>
                            <div class="col-md-6">
                                <br/><label for="name">Subject Name</label>
                                    <input type="text" class="form-control" name="subname" id="subname" readonly="true"/>
                            </div>
                        </div>
                        <br/><div class="row">
                          <div class="col-md-6">
                                <label for="name">Class Time</label>
                                 <input type="text" class="form-control" name="cstime"  id="cstime" readonly="true"/> 
                          </div>
                          <div class="col-md-6">
                                <label for="name">Day</label>
                                 <input type="text" class="form-control" name="csday"  id="csday" readonly="true"/> 
                            </div>

                          </div>
                          <br/><div class="row">
                          <div class="col-md-4">
                                <label for="name">Course Venue</label>
                                <input type="text" class="form-control" name="csvenue"  id="csvenue" readonly="true"/> 
                                </select>
                          </div>
                          <div class="col-md-4">
                                <label for="name">Supervisor</label>
                                    <input type="text" class="form-control" name="supid" id="supid" readonly="true"/>        
                          </div>
                          <div class="col-md-4">
                                <label for="name">Cost</label>
                                    <input type="text" class="form-control" name="subcost" id="subcost" readonly="true"/>      
                          </div>
                        </div>
                        <div class="row" hidden>
                            <div class="col-md-12">
                                <input type="text" class="form-control" name="subid" id="subid"  />
                            </div>
                        </div>
                        <br/>
                        <button type="submit" name="subbtn" class="btn btn-default btn-block addcbtn" style="background-color: #e4e4e4; "><i class="glyphicon glyphicon-ok-circle"></i>  Add class</button>
                        <a href="CW_viewclass.php"><button type="button" class="btn btn-default btn-block addcbtn" style="background-color: #e4e4e4; margin-top:10px; "><i class="glyphicon glyphicon-remove"></i> Cancel</button></a>
                </div>
            <!-- /.container-fluid -->
            <?php
                            if(isset($_POST['subbtn']))
                            {
                                $csid=$_POST['csid'];
                                $subid=$_POST['subid'];
                                $csvenue=$_POST['csvenue'];
                                $cscode=$_POST['cscode'];
                                $csday=$_POST['csday'];
                                $cstime=$_POST['cstime'];

                                $sql6="select * from enrollment where class_id='$csid' and stud_id='$stud_id' and (enrollment_status='Active' or enrollment_status='End')";
                                $result6=mysqli_query($con,$sql6);
                                $row6=mysqli_fetch_assoc($result6);

                                $sql7="select * from enrollment INNER JOIN class on enrollment.class_id=class.class_id where class.subject_id='$subid' and enrollment.stud_id='$stud_id' and (enrollment.enrollment_status='Active' or enrollment.enrollment_status='End') ";
                                $result7=mysqli_query($con,$sql7);
                                $row7=mysqli_fetch_assoc($result7);

                                $sql8="select * from student where stud_id='$stud_id' and stud_status='Active' ";
                                $result8=mysqli_query($con,$sql8);
                                $row8=mysqli_fetch_assoc($result8);
                                

                                $sql9="select * from enrollment INNER JOIN class ON enrollment.class_id=class.class_id WHERE enrollment.stud_id ='$stud_id' and class.class_day='$csday' and class.class_time='$cstime' and (enrollment.enrollment_status='Active' or enrollment.enrollment_status='End') ";
                                $result9=mysqli_query($con,$sql9);


                                if(mysqli_num_rows($result8)!=0)
                                {
                                    if(mysqli_num_rows($result6)==0)
                                    {   
                                        if(mysqli_num_rows($result9)!=0)
                                        {
                                          ?>
                                        <script type="text/javascript">
                                            swal("Opps!","Cannot add class. Time was crashing with previos class time.", "error")
                                        </script>
                                        <?php
                                        }

                                        else if(mysqli_num_rows($result7)!=0)
                                        {
                                            ?>
                                        <script type="text/javascript">
                                            swal("Opps!","Cannot add class. One subject can only have one class.")
                                        </script>
                                        <?php
                                        }
                                      
                                        else
                                        {
                                            mysqli_query($con,"insert into enrollment(stud_id,class_id,enrollment_status)values('$stud_id', '$csid','Active')");

                                        ?>
                                          <script type="text/javascript">
    										  swal({ 
                                                  title: "Successfull!",
                                                  text: "Class was added successsfully.Thank you.",
                                                  type: "success" 
                                              }).then(function() {
    											window.location.href = 'CW_viewclass.php';
                                              });
                                          </script>
                                        <?php
                                        }
                                    }
                                    else
                                    {
                                        ?>
                                        <script type="text/javascript">
                                            swal("Opps!","Cannot add same class.", "error")
                                        </script>
                                    <?php
                                    }
                                }
                                else
                                {
                                    ?>
                                        <script type="text/javascript">
                                            swal("Opps!","You already complete your program.", "error")
                                        </script>
                                    <?php
                                }
                            }
                        ?>

        </div>
        <!-- /#page-wrapper -->

    </div>
    </form>
    <!-- /#wrapper -->

    <!-- jQuery -->
    <script src="../source/js/jquery.js"></script>
    <script src="//code.jquery.com/jquery-1.9.1.js"></script>
    <!-- Bootstrap Core JavaScript -->
    <script src="../source/js/bootstrap.min.js"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.0/jquery.min.js"></script>
    <script src="//ajax.aspnetcdn.com/ajax/jquery.validate/1.9/jquery.validate.min.js"></script> 
    <script>

    $(document).ready(function () 
    {	
    	//Determination of student type
		var stud_type = "<?php echo $_SESSION['stud_type']; ?>";
		if (stud_type == "Coursework")
		{
			$('.research').css({'display': 'none'});
		}
		else if (stud_type == "Research")
		{
			$('.coursework').css({'display': 'none'});
		}
		
		//logout confirmation
		$(".logout").click(function(){		
			swal({
				title: 'Logout',
				text: "Logout from Postgraduate Management System",
				type: 'warning',
				showCancelButton: true,
				confirmButtonColor: '#3085d6',
				cancelButtonColor: '#d33',
				confirmButtonText: 'Yes'
			}).then(function () {
					window.location.href ="../logout.php";
			})			
		});		

	})


        $('#csid').change(function(){
            var classid = $(this).val();

            if(classid!="empty")
            {
                $.ajax({
                           type:'POST',
                           url:'ajax.php',
                           data:'classid='+classid,
                           success:function(data)
                           {
                                var Vals=JSON.parse(data);
                                $('#subname').val(Vals.subject);
                                $('#supid').val(Vals.sup);
                                $('#cstime').val(Vals.cstime);
                                $('#csvenue').val(Vals.csvenue);
                                $('#subcost').val(Vals.subfee);
                                $('#csday').val(Vals.csday);
                                $('#subid').val(Vals.subid);
                            }
                        });
            }
            else
            {
                $('#subname').val("");
                $('#supid').val("");
                $('#cstime').val("");
                $('#csvenue').val("");
                $('#subcost').val("");
                $('#csday').val("");
                $('#subid').val("");
            }
        });


        $("#expand1").hover(
     function() {
        $('.expand1').collapse('show');
      }, function() {
        $('.expand1').collapse('hide');
      }
    );
        $("#expand2").hover(
     function() {
        $('.expand2').collapse('show');
      }, function() {
        $('.expand2').collapse('hide');
      }
    );

        jQuery.validator.addMethod('csid1', function (value) {
        return (value !='empty');
    }, "Please choose a time slot.");


    $('#form1').validate(
    { // initialize the plugin
        errorPlacement: function (error, element) {
            error.insertAfter(element);
            if (element.hasClass('pw')) {
                element.next().removeClass('passValid').addClass('passError');
            }
        },
        success: function (label) {
            if (label.prev().hasClass('pw')) {
               label.text("Valid!");
            }
        },
        highlight: function (element, errorClass, validClass) {
            if ($(element).hasClass('pw')) {
                $(element).next().removeClass('passValid').addClass('passError');
            } else {
                $(element).addClass(errorClass).removeClass(validClass);
            }
        },
        unhighlight: function (element, errorClass, validClass) {
            if ($(element).hasClass('pw')) {
                $(element).next().removeClass('passError').addClass('passValid');
            } else {
                $(element).removeClass(errorClass).addClass(validClass);
            }
        },
        rules: {
                csid: 
                    {
                        required: true,
                        csid1:true
                    },

                },
                        
        messages:   {
                        csid:"Please select a class.",
                    },

    });

	$(window).on('resize', function() {
		if($(window).width() < 400) 
		{
			$('.item').addClass('col-xs-12 col-md-6');
			$('.item').removeClass('col-xs-6 col-md-4');
		}
		else
		{
			$('.item').addClass('col-xs-6 col-md-4');
			$('.item').removeClass('col-xs-12 col-md-6');
		}
	})

</script>

</body>

</html>
