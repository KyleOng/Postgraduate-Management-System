<?php
include("../dataconnect.php");
// if($_SESSION["loggedin"]!=1)
// 		header("Location: login.php");

$eid = $_REQUEST["eid"];

$sql = "update enrollment set enrollment_status='Dropped' where enrollment_id='$eid' ";
mysqli_query($con, $sql);

header("Location: CW_viewclass.php");

?>