<?php
	include("../dataconnect.php");
	if($_SESSION["loggedins"]!=1)
	{
		echo"<script> window.location.href ='../login.php';</script>";
	}
	session_start();
	$stud_id = $_SESSION['stud_id'];
	
	$sql_student = "select * from STUDENT S, REGISTRATION R, PROGRAMME P where 
					S.reg_id = R.reg_id and
					R.prog_id = P.prog_id and
					stud_id='$stud_id'";
	$row_student = mysqli_fetch_assoc(mysqli_query($con,$sql_student));
	
	if($_SESSION['stud_type'] == 'Research')
	{
		$title = "Research Student";
	}
	else
	{
		$title = "Coursework Student";
	}
?>

<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
	
    <title>Postgraduate</title>

    <!-- Bootstrap Core CSS -->
    <link href="../source/css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom CSS -->
    <link href="../source/css/sb-admin.css" rel="stylesheet">

	<!-- Awesome Fonts -->
    <link href="../source/font-awesome-4.7.0/css/font-awesome.min.css" rel="stylesheet" type="text/css">
	
	<!-- Sweet Alert -->
	<script src="../source/sweetalert/dist/sweetalert2.min.js"></script> 
	<link rel="stylesheet" type="text/css" href="../source/sweetalert/dist/sweetalert2.css">
	
	<!-- jQuery -->
    <script src="../source/js/jquery.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="../source/js/bootstrap.min.js"></script>
	
	<!-- Country -->
	<script type= "text/javascript" src = "../source/js/country2.js"></script>

	<script>		
	function TestFunc(){		
		var en_test = $("#en_test").find(":selected").val();		
		if (en_test=="MUET"){
			for(i=1;i<=6;i++){
				$('#en_mark').append($('<option>', {
					value: i,
					text: i
				}));
			}			
			var value = <?php echo $row_student['en_mark'];?>;
			$("#en_mark").val(value);
		}		
		else if (en_test=="IELTS"){
			for(i=1;i<=9;i=i+0.5){
				$('#en_mark').append($('<option>', {
					value: i,
					text: i
				}));
			}			
		}
		else if (en_test=="TOEFL"){
			for(i=1;i<=120;i++){
				$('#en_mark').append($('<option>', {
					value: i,
					text: i
				}));
			}			
		}
		var en_test = $("#en_test").find(":selected").val();
		$("#en_mark").val(value);		
	}	
	</script>	
	

</head>

<body>

    <div id="wrapper">

        <!-- Navigation -->
        <nav class="navbar navbar-inverse navbar-fixed-top" role="navigation">
            
			<!-- Left_Header(Display User Type) -->
			<div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-ex1-collapse">
                    <!-- Drop down bar in small screen -->
					<span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>				
				<a class="navbar-brand" href="index.php"><?php echo $title; ?></a>
            </div>		
            
			<!-- Middle_Header(Display User Name and ID) -->
			<div class="top-nav-right">
                <a class="navbar-brand" href="profile.php"><i class="fa fa-user"></i>  <?php echo $row_student['stud_name']; ?>  <?php echo $row_student['stud_code']; ?></a>
            </div>	
			
			<!-- Logout -->
            <ul class="nav navbar-right top-nav">
				<li class="dropdown">												
					<a href="#" class="logout"><i class="fa fa-fw fa-power-off"></i> Log Out</a>
                </li>
            </ul>
            
			<!-- Sidebar Menu Items - These collapse to the responsive navigation menu on small screens -->
            <div class="collapse navbar-collapse navbar-ex1-collapse">
                <ul class="nav navbar-nav side-nav">             
                    <!-- Dashboard -->
					<li>
                        <a href="index.php"><i class="glyphicon glyphicon-home"></i>  &nbsp; Dashboard</a>
                    </li>
					
					<!-- Profile -->
                    <li class="active">
                        <a href="javascript:;" data-toggle="collapse" data-target="#list0"><i class="fa fa-fw fa-user"></i>  &nbsp; Profile <i class="fa fa-fw fa-caret-down"></i></a>
                        <ul id="list0" class="collapse in">
							<li>
                                <a href="profile.php"> Display Profile</a>
                            </li>                            
							<li>
                                <a href="profile_edit.php" style="color:white;background-color:black;"> Edit Profile</a>
                            </li>
							<li>
                                <a href="profile_reset.php"> Reset Password</a>
                            </li>							
                        </ul>						
                    </li>
					
					<!-- Coursework -->
                    <li id="sidebar_cw" class="coursework">
                        <a href="javascript:;" data-toggle="collapse" data-target="#list1"><i class="glyphicon glyphicon-book"></i>  &nbsp; Coursework <i class="fa fa-fw fa-caret-down"></i></a>
                        <ul id="list1" class="collapse sidebar_cw">
							<li>
                                <a href="CW_enroll.php"> Enroll Class </a>
                            </li>
                            <li>
                                <a href="CW_viewclass.php"> View Class info </a>
                            </li>
							<li>
								<a href="CW_viewresult.php"> View Result </a>
							</li>
                        </ul>
                    </li>

					<!-- Research -->					
                    <li id="sidebar_res" class="research">
                        <a href="javascript:;" data-toggle="collapse" data-target="#list2"><i class="glyphicon glyphicon-education"></i>  &nbsp; Research <i class="fa fa-fw fa-caret-down"></i></a>
                        <ul id="list2" class="collapse sidebar_res">
                            <li>
                                <a href="res_status.php"> Status</a>
                            </li>
                            <li>
                                <a href="res_topic.php"> Field & Topic</a>
                            </li>
                            <li>
                                <a href="res_sup.php"> Supervisor Selection</a>
                            </li>
							<li>
                                <a href="res_upload.php"> Document Upload</a>
                            </li>
                        </ul>
                    </li>
					
					<!-- Finance -->
					<li>
                        <a href="javascript:;" data-toggle="collapse" data-target="#list3"><i class="glyphicon glyphicon-usd"></i>  &nbsp; Finance <i class="fa fa-fw fa-caret-down"></i></a>
                        <ul id="list3" class="collapse ">
                            <li>
                                <a href="finance_account.php" > Account Enquiry</a>
                            </li>
                            <li>
                                <a href="finance_grant.php"> View Grant</a>
                            </li>
                            <li>
                                <a href="finance_transaction.php"> Transaction History</a>
                            </li>
                        </ul>
                    </li>
					
					<!-- User guideline -->
                    <li>
                        <a href="userguide.php"><i class="glyphicon glyphicon-question-sign"></i>  &nbsp; User guideline</a>
                    </li>
                </ul>
            </div>
            <!-- /.navbar-collapse -->
        </nav>

        <!-- content inside dashboard -->
		<div id="page-wrapper" style="min-height:400px;">
            <div class="container-fluid">
				
				<!-- Heading -->
				<h2>Profile Edit</h2>				
				
				<div class="col-md-3 col-lg-3" align="center">
					<div class="panel panel-default">
						<div class="panel-body">						
								
							<!-- user profile pic -->
							<form class="form-horizontal" id="form111" role="form" method ="post" action="" enctype="multipart/form-data">
								<?php 											
									if($row_student['Profile_Picture']=="" || $row_student['Profile_Ext']==".")
									{
									?>
										<img alt="User Pic" src="../source/picture/user/defaultuser.jpg" class="img-rounded img-responsive pic">
										<input class='form-control' type='file' name='image' required>						
									<?php
									}
									else
									{
										echo "<img alt='User Pic' src='../source/picture/user/".$row_student['Profile_Picture'].$row_student['Profile_Ext']."' class='img-rounded img-responsive pic' >
											  <input class='form-control' type='file' name='image' required>";
									}
								?> 
								</br>
								<button type="submit" class="btn btn-default btn-block" style="background-color: #e4e4e4;" name='Submit'><i class="fa fa-upload"> Upload Image</i></button>
							</form>																		
						</div>
					</div>
				</div>

				<div class="col-md-9 col-lg-9">
					<div class="panel panel-default">
						<div class="panel-body">					
							
							<form method="post">
								<!-- user information -->
								<table class="table table-user-information">
									<tbody>
										<tr>
											<td>Student ID </td>
											<td><input type="text" class="form-control" value="<?php echo $_SESSION['stud_code'];?>" disabled></td>
										</tr>
										<tr>
											<td>Programme </td>
											<td><input type="text" class="form-control" value="<?php echo $row_student['prog_name'];?>" disabled></td>
										</tr>
										<tr>
											<td>Type </td>
											<td><input type="text" class="form-control" value="<?php echo $row_student['stud_type'];?>" disabled></td>
										</tr>
										<tr>
											<td>Name </td>
											<td><input type="text" class="form-control" value="<?php echo $row_student['stud_name'];?>" disabled></td>
										</tr>										  
										<tr>
											<td>IC </td>
											<td><input type="text" class="form-control" value="<?php echo $row_student['stud_ic'];?>" disabled></td>
										</tr>
										<tr>
											<td>Passport</td>
											<td><input type="text" class="form-control" value="<?php echo $row_student['stud_passport'];?>" disabled></td>
										</tr>
										<tr>
											<td>Gender</td>
											<td><input type="text" class="form-control" value="<?php echo $row_student['stud_gender'];?>" disabled></td>
										</tr>
										<tr>
											<td>Email</td>
											<td><input type="text" class="form-control" value="<?php echo $row_student['stud_email'];?>" disabled></td>
										</tr>
										<tr>
											<td>Contact Number</td>
											<td><input type="text" class="form-control" name="stud_contact" value="<?php echo $row_student['stud_contact'];?>" pattern=".{10,11}"></td>
										</tr>											
										<tr>
											<td>Address</td>
											<td><input type="text" class="form-control" name="stud_address" value="<?php echo $row_student['stud_address'];?>"></td>
										</tr>
										<tr>
											<td>State</td>	
											<td>
												<select class="form-control" id="stud_state" name="stud_state" required>
												</select>
											</td>
										</tr>
										<tr>
											<td>Postcode</td>
											<td><input type="text" class="form-control" name="stud_postcode" value="<?php echo $row_student['stud_postcode'];?>"  pattern=".{5}"></td>
										</tr>
										<tr>
											<td>Nation</td>
											<td>
												<select class="form-control" id="stud_nation" name="stud_nation" disabled>
												</select>
											</td>
										</tr>
										<tr>
											<td>Undergraduate University</td>
											<td><input type="text" class="form-control" value="<?php echo $row_student['und_grad'];?>" disabled></td>
										</tr>
										<tr>
											<td>CGPA</td>
											<td><input type="text" class="form-control" value="<?php echo $row_student['und_cgpa'];?>" disabled></td>
										</tr>
										<tr>
											<td>English Proficiency</td>
											<td>
												<select id="en_test" class="form-control" name="en_test" onchange="TestFunc()" value="<?php echo $row_student['en_test'];?>">
													<option value="MUET">MUET (Malaysian University English Test)</option>
													<option value="IELTS">IELTS (International English Language Testing System)</option>
													<option value="TOEFL">TOEFL (Test of English as a Foreign Language)</option>
												</select>
											</td>
										</tr>
										<tr>
											<td>Score</td>
											<td>
												<select id="en_mark" class="form-control" name="en_mark" required>														
												</select>
											</td>
										
										</tr>											
									</tbody>
								</table>            	
								
								<!-- script for country -->
								<script>
										var selectedNation = "<?php echo $row_student['stud_nation'];?>";
										var selectedState = "<?php echo $row_student['stud_state'];?>";
										populateCountries("stud_nation", "stud_state",selectedNation,selectedState);
								</script>			
								
								<button type="submit" class="btn btn-block" id="btnSubmit" name="btnSubmit"><i class="glyphicon glyphicon-send"></i> Submit</button>
							</form>
						</div>
					</div>
				</div>
			</div>
            <!-- /.container-fluid -->

        </div>
        <!-- /#page-wrapper -->

    </div>
    <!-- /#wrapper -->

</body>

<script>
$(document).ready(function() {
	
	//run eng test function
	TestFunc();
	
	//Determination of student type
	var stud_type = "<?php echo $_SESSION['stud_type']; ?>";
	if (stud_type == "Coursework")
	{
		$('.research').css({'display': 'none'});
	}
	else if (stud_type == "Research")
	{
		$('.coursework').css({'display': 'none'});
	}
	
	//logout confirmation
	$(".logout").click(function(){		
		swal({
			title: 'Logout',
			text: "Logout from Postgraduate Management System",
			type: 'warning',
			showCancelButton: true,
			confirmButtonColor: '#3085d6',
			cancelButtonColor: '#d33',
			confirmButtonText: 'Yes'
		}).then(function () {
				window.location.href ="../logout.php";
		})			
	});
	
	
});
</script>

</html>

<!-- profile picture code -->
<?php
	//define a maxim size for the uploaded images in Kb
	define ("MAX_SIZE","8000"); 
	//This function reads the extension of the file. It is used to determine if the
	// file  is an image by checking the extension.
	 function getExtension($str) {
			 $i = strrpos($str,".");
			 if (!$i) { return ""; }
			 $l = strlen($str) - $i;
			 $ext = substr($str,$i+1,$l);
			 return $ext;
	 }

	//This variable is used as a flag. The value is initialized with 0 (meaning no 
	// error  found)  
	//and it will be changed to 1 if an errro occures.  
	//If the error occures the file will not be uploaded.
	$errors=0;
	//checks if the form has been submitted
	if(isset($_POST['Submit'])) 
	{
		//reads the name of the file the user submitted for uploading
		$image=$_FILES['image']['name'];
		//if it is not empty
		if ($image) 
		{
		//get the original name of the file from the clients machine
			$filename = stripslashes($_FILES['image']['name']);
		//get the extension of the file in a lower case format
			$extension = getExtension($filename);
			$extension = strtolower($extension);
		//if it is not a known extension, we will suppose it is an error and 
		// will not  upload the file,  
		//otherwise we will do more tests
			if (($extension != "jpg") && ($extension != "jpeg") && ($extension !="png") && ($extension != "gif")) 
			{
			//print error message
				echo '<h1>Unknown extension!</h1>';
				$errors=1;
			}
			else
			{
				//get the size of the image in bytes
				 //$_FILES['image']['tmp_name'] is the temporary filename of the file
				 //in which the uploaded file was stored on the server
				 $size=filesize($_FILES['image']['tmp_name']);

				//compare the size with the maxim size we defined and print error if bigger
				if ($size > MAX_SIZE*1024)
				{
					echo '<h1>You have exceeded the size limit!</h1>';
					$errors=1;
				}

				//we will give an unique name, for example the time in unix time format
				$image_name=$row_student['stud_code'].'.'.$extension;
				//the new name will be containing the full path where will be stored (images folder)
				$newname="../source/picture/user/".$image_name;
				//we verify if the image has been uploaded, and print error instead
				$copied = copy($_FILES['image']['tmp_name'], $newname);
				if (!$copied) 
				{
					echo '<h1>Copy unsuccessfull!</h1>';
					$errors=1;
				}
			}
		}
	}
	
	//If no errors registred, print the success message
	 if(isset($_POST['Submit']) && !$errors) 
	 {
		echo "<h1>File Uploaded Successfully! </h1>";
		
		$sql2="update student set Profile_Picture='".$row_student['stud_code']."',Profile_Ext='.$extension' where stud_id=$stud_id";
		mysqli_query($con,$sql2);
		header("Location: profile_edit.php");
		mysqli_close($con);
	 }
			
?>

<!-- form edit -->
<?php
if(isset($_POST['btnSubmit']))
{
	$stud_contact=$_POST['stud_contact'];
	$stud_address=$_POST['stud_address'];
	$stud_state=$_POST['stud_state'];
	$stud_postcode=$_POST['stud_postcode'];
	$en_test=$_POST['en_test'];
	$en_mark=$_POST['en_mark'];
	
	$sql1 = "UPDATE REGISTRATION SET 
			stud_contact = '$stud_contact', 
			stud_address = '$stud_address', 
			stud_state = '$stud_state',
			stud_postcode = '$stud_postcode',
			en_test = '$en_test',
			en_mark = '$en_mark'
			where reg_id = '".$row_student['reg_id']."'";	
	
	if (mysqli_query($con, $sql1)) {
		?>
		<script>
				swal({
					title: "Successfull!",
					text: "Profile Edit Successful!",
					type: "success" 
				}).then(function() {
					window.location.href ="profile_edit.php";
				});
		</script>
	<?php
	}
	else{
		?>
		<script type="text/javascript">
			alert("failed");
		</script>
	<?php		
	}
}
?>