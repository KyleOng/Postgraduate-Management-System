<?php

include('../dataconnect.php');

if(isset($_POST["classid"]) && !empty($_POST["classid"])){
    $query4 = $con->query("SELECT subject.subject_name,subject.subject_fee,subject.subject_id,supervisor.sup_name,class.class_venue,class.class_time,class.class_day FROM class INNER JOIN subject ON class.subject_id=subject.subject_id INNER JOIN supervisor ON class.sup_id=supervisor.sup_id WHERE class.class_id = ".$_POST['classid']."");

    $rowCount = $query4->num_rows;
    
    if($rowCount > 0)
    {
        while($row4 = $query4->fetch_assoc())
        { 
            echo json_encode(array("subject"=>$row4['subject_name'],"sup"=>$row4['sup_name'],"cstime"=>$row4['class_time'],"csvenue"=>$row4['class_venue'],"subfee"=>$row4['subject_fee'],"csday"=>$row4['class_day'],"subid"=>$row4['subject_id']));
        }
    }
    else
    {
        echo "no data found";
    }
}



?>