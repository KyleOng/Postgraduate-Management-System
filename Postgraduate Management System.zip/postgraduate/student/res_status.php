<?php
	include("../dataconnect.php");
	if($_SESSION["loggedins"]!=1)
	{
		echo"<script> window.location.href ='../login.php';</script>";
	}
	session_start();
	//Student general information
	$stud_id = $_SESSION['stud_id'];

	//get student info
	$sql_check_field = "select * from RESEARCHSTD RES, Field F where RES.field_id = F.field_id and S.stud_id = '$stud_id';";
	if(mysqli_num_rows(mysqli_query($con,$sql_check_field)) > 0)
	{
		$sql_student = "select * from STUDENT S, REGISTRATION R, RESEARCHSTD RES, Field F , PROGRAMME PROG where 
						S.stud_id = RES.stud_id and 
						S.reg_id = R.reg_id and 
						RES.field_id = F.field_id and 
						R.prog_id = PROG.prog_id and
						S.stud_id = '$stud_id'";	
	}
	else
	{
		$sql_student = "select * from STUDENT S, REGISTRATION R, RESEARCHSTD RES, PROGRAMME PROG where 
						S.stud_id = RES.stud_id and 
						S.reg_id = R.reg_id and 
						R.prog_id = PROG.prog_id and
						S.stud_id = '$stud_id'";		
	}
	$query_student = mysqli_query($con,$sql_student);

	$row_student = mysqli_fetch_assoc(mysqli_query($con,$sql_student));
	//Main supervisor information
	$main_sup = $row_student['sup_id'];
	$sql_main_sup = "select * from SUPERVISOR where sup_id = '$main_sup'";
	$row_main_sup = mysqli_fetch_assoc(mysqli_query($con,$sql_main_sup));
	//Co supervisor information
	$co_sup = $row_student['co_sup_id'];
	$sql_co_sup = "select * from SUPERVISOR where sup_id = '$co_sup'";
	$row_co_sup = mysqli_fetch_assoc(mysqli_query($con,$sql_co_sup));	
	
	if($_SESSION['stud_type'] == 'Research')
	{
		$title = "Research Student";
	}
	else if($_SESSION['stud_type'] == 'Coursework')
	{
		$title = "Coursework Student";
	}
?>

<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
	
    <title>Postgraduate</title>

    <!-- Bootstrap Core CSS -->
    <link href="../source/css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom CSS -->
    <link href="../source/css/sb-admin.css" rel="stylesheet">

	<!-- Awesome Fonts -->
    <link href="../source/font-awesome-4.7.0/css/font-awesome.min.css" rel="stylesheet" type="text/css">
	
	<!-- Sweet Alert -->
	<script src="../source/sweetalert/dist/sweetalert2.min.js"></script> 
	<link rel="stylesheet" type="text/css" href="../source/sweetalert/dist/sweetalert2.css">
	
	<!-- jQuery -->
    <script src="../source/js/jquery.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="../source/js/bootstrap.min.js"></script>

</head>
<style>
td {
    vertical-align: middle;
}

</style>
<body>

    <div id="wrapper">

        <!-- Navigation -->
        <nav class="navbar navbar-inverse navbar-fixed-top" role="navigation">
            
			<!-- Left_Header(Display User Type) -->
			<div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-ex1-collapse">
                    <!-- Drop down bar in small screen -->
					<span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>				
				<a class="navbar-brand" href="index.php"><?php echo $title; ?></a>
            </div>		
            
			<!-- Middle_Header(Display User Name and ID) -->
			<div class="top-nav-right">
                <a class="navbar-brand" href="profile.php"><i class="fa fa-user"></i>  <?php echo $row_student['stud_name']; ?>  <?php echo $row_student['stud_code']; ?></a>
            </div>	
			
			<!-- Logout -->
            <ul class="nav navbar-right top-nav">
				<li class="dropdown">												
					<a href="#" class="logout"><i class="fa fa-fw fa-power-off"></i> Log Out</a>
                </li>
            </ul>
            
			<!-- Sidebar Menu Items - These collapse to the responsive navigation menu on small screens -->
            <div class="collapse navbar-collapse navbar-ex1-collapse">
                <ul class="nav navbar-nav side-nav">             
                    <!-- Dashboard -->
					<li>
                        <a href="index.php"><i class="glyphicon glyphicon-home"></i>  &nbsp; Dashboard</a>
                    </li>
					
					<!-- Profile -->
                    <li>
                        <a href="javascript:;" data-toggle="collapse" data-target="#list0"><i class="fa fa-fw fa-user"></i>  &nbsp; Profile <i class="fa fa-fw fa-caret-down"></i></a>
                        <ul id="list0" class="collapse">
							<li>
                                <a href="profile.php"> Display Profile</a>
                            </li>                            
							<li>
                                <a href="profile_edit.php"> Edit Profile</a>
                            </li>
							<li>
                                <a href="profile_reset.php"> Reset Password</a>
                            </li>							
                        </ul>						
                    </li>
					
					<!-- Coursework -->
                    <li id="sidebar_cw" class="coursework">
                        <a href="javascript:;" data-toggle="collapse" data-target="#list1"><i class="glyphicon glyphicon-book"></i>  &nbsp; Coursework <i class="fa fa-fw fa-caret-down"></i></a>
                        <ul id="list1" class="collapse sidebar_cw">
							<li>
                                <a href="CW_enroll.php"> Enroll Class </a>
                            </li>
                            <li>
                                <a href="CW_viewclass.php"> View Class info </a>
                            </li>
							<li>
								<a href="CW_viewresult.php"> View Result </a>
							</li>
                        </ul>
                    </li>

					<!-- Research -->					
                    <li id="sidebar_res" class="research active">
                        <a href="javascript:;" data-toggle="collapse" data-target="#list2"><i class="glyphicon glyphicon-education"></i>  &nbsp; Research <i class="fa fa-fw fa-caret-down"></i></a>
                        <ul id="list2" class="collapse sidebar_res in">
                            <li>
                                <a href="res_status.php" style="color:white;background-color:black;"> Status</a>
                            </li>
                            <li>
                                <a href="res_topic.php"> Field & Topic</a>
                            </li>
                            <li>
                                <a href="res_sup.php"> Supervisor Selection</a>
                            </li>
							<li>
                                <a href="res_upload.php"> Document Upload</a>
                            </li>
                        </ul>
                    </li>
					
					<!-- Finance -->
					<li>
                        <a href="javascript:;" data-toggle="collapse" data-target="#list3"><i class="glyphicon glyphicon-usd"></i>  &nbsp; Finance <i class="fa fa-fw fa-caret-down"></i></a>
                        <ul id="list3" class="collapse ">
                            <li>
                                <a href="finance_account.php" > Account Enquiry</a>
                            </li>
                            <li>
                                <a href="finance_grant.php"> View Grant</a>
                            </li>
                            <li>
                                <a href="finance_transaction.php"> Transaction History</a>
                            </li>
                        </ul>
                    </li>
					
					<!-- User guideline -->
                    <li>
                        <a href="userguide.php"><i class="glyphicon glyphicon-question-sign"></i>  &nbsp; User guideline</a>
                    </li>
                </ul>
            </div>
            <!-- /.navbar-collapse -->
        </nav>

        <!-- content inside dashboard -->
		<div id="page-wrapper" style="min-height:400px;">
            <div class="container-fluid">
										
				<!-- Heading-->
				<h2>Research Status</h2>
										
				<!-- research information -->
				<div class=" col-md-12 col-lg-12"> 
					<table class="table table-responsive" style="width: 100%;" id="val_table">
						<tbody>
							<tr>
								<td width="30%">Research Topic </td>
								<td width="2%">:</td>
								<td class="val_td"><?php echo $row_student['res_topic']; ?></td>
							</tr>
							<tr>
								<td>Programme </td>
								<td>:</td>
								<td class="val_td"><?php echo $row_student['prog_name']; ?></td>
							</tr>
							<tr>
								<td>Field </td>
								<td>:</td>
								<td class="val_td"><?php echo $row_student['field_name']; ?></td>
							</tr>
							<tr>
								<td>Main Supervisor </td>
								<td>:</td>
								<td class="val_td"><?php echo $row_main_sup['sup_name']; ?></td>
							</tr>
							<tr>
								<td>Co Supervisor </td>
								<td>:</td>
								<td class="val_td"><?php echo $row_co_sup['sup_name']; ?></td>
							</tr>										  
							<tr>
								<td>Research Status</td>
								<td>:</td>
								<td class="val_td"><?php echo $row_student['res_status']; ?></td>
							</tr>
							<tr>
								<td>Journal Name</td>
								<td>:</td>
								<td class="val_td"><?php echo $row_student['jor_name']; ?></td>
							</tr>											
							<tr>
								<td>Journal Status</td>
								<td>:</td>
								<td class="val_td"><?php echo $row_student['jor_status']; ?></td>
							</tr>
							<tr>
								<td>Jornal Published Date</td>
								<td>:</td>
								<td class="val_td"><?php echo $row_student['jor_date']; ?></td>
							</tr>											
						</tbody>
					</table>                 
				</div>							
			</div>
            <!-- /.container-fluid -->

        </div>
        <!-- /#page-wrapper -->

    </div>
    <!-- /#wrapper -->

</body>

<script>
//function to set empty row as '-'
function validate(){		
	$('#val_table .val_td').each(function() {
		$(this).find(".val_td").html(); 
		if($(this).html() == "")
		{
			$(this).html("-"); 
		}		
	});	
}	

	
$(document).ready(function() {
	
	//function to set empty row as '-'
	validate();
	
	//Determination of student type
	var stud_type = "<?php echo $_SESSION['stud_type']; ?>";
	if (stud_type == "Coursework")
	{
		$('.research').css({'display': 'none'});
	}
	else if (stud_type == "Research")
	{
		$('.coursework').css({'display': 'none'});
	}
	
	//logout confirmation
	$(".logout").click(function(){		
		swal({
			title: 'Logout',
			text: "Logout from Postgraduate Management System",
			type: 'warning',
			showCancelButton: true,
			confirmButtonColor: '#3085d6',
			cancelButtonColor: '#d33',
			confirmButtonText: 'Yes'
		}).then(function () {
				window.location.href ="../logout.php";
		})			
	});	
});
</script>

</html>
