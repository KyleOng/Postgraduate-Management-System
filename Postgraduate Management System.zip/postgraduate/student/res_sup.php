<?php
	include("../dataconnect.php");
	if($_SESSION["loggedins"]!=1)
	{
		echo"<script> window.location.href ='../login.php';</script>";
	}

	session_start();
	//Student General information
	$stud_id = $_SESSION['stud_id'];
	$sql_student = "select * from STUDENT S, REGISTRATION R, RESEARCHSTD RES, FIELD F, PROGRAMME PROG where 
					S.stud_id = RES.stud_id and 
					S.reg_id = R.reg_id and 
					R.prog_id = PROG.prog_id and
					F.field_id = RES.field_id and
					S.stud_id = '$stud_id'";
	$row_student = mysqli_fetch_assoc(mysqli_query($con,$sql_student));		

	//if not select field, not able to select supervisor
	if ($row_student['field_id'] == '' || $row_student['res_topic'] == '')
	{
		$proceed = 'F';
	}
	else
	{
		$proceed = 'T';
		//if supervisor not selected, submit_status = F
		if ($row_student['sup_id'] == '' || $row_student['co_sup_id'] == '')
		{
			$submit_status = 'F';		
		}
		else //if supervisor selected, submit_status = T
		{
			$submit_status = 'T';
			//Set info of main supervisor
			$sql_main_sup = "Select * from Supervisor SUP, POSITION P where SUP.pos_id = P.pos_id and sup_id = ".$row_student['sup_id'].";";
			$row_main_sup = mysqli_fetch_assoc(mysqli_query($con,$sql_main_sup));
			//Set info of co supervisor
			$sql_co_sup = "Select * from Supervisor SUP, POSITION P where SUP.pos_id = P.pos_id and SUP.sup_id = ".$row_student['co_sup_id'].";";
			$row_co_sup = mysqli_fetch_assoc(mysqli_query($con,$sql_co_sup));			
		}	
	}
	
	if($_SESSION['stud_type'] == 'Research')
	{
		$title = "Research Student";
	}
	else if($_SESSION['stud_type'] == 'Coursework')
	{
		$title = "Coursework Student";
	}
?>

<!DOCTYPE html>
<html lang="en">
<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
	
    <title>Postgraduate</title>

    <!-- Bootstrap Core CSS -->
    <link href="../source/css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom CSS -->
    <link href="../source/css/sb-admin.css" rel="stylesheet">

	<!-- Awesome Fonts -->
    <link href="../source/font-awesome-4.7.0/css/font-awesome.min.css" rel="stylesheet" type="text/css">
	
	<!-- Sweet Alert -->
	<script src="../source/sweetalert/dist/sweetalert2.min.js"></script> 
	<link rel="stylesheet" type="text/css" href="../source/sweetalert/dist/sweetalert2.css">
	
	<!-- jQuery -->
    <script src="../source/js/jquery.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="../source/js/bootstrap.min.js"></script>

</head>
<style>
.deco-none {
	color: inherit;
	text-decoration: inherit;
}

.deco-none:link {
	color: inherit;
	text-decoration: inherit;
}

.deco-none:hover {
	color: inherit;
	text-decoration: inherit;
}
.error{
	display: none; !important;
	padding-top: 6px;
	padding-bottom: 6px;
}
</style>
<body>

    <div id="wrapper">

        <!-- Navigation -->
        <nav class="navbar navbar-inverse navbar-fixed-top" role="navigation">
            
			<!-- Left_Header(Display User Type) -->
			<div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-ex1-collapse">
                    <!-- Drop down bar in small screen -->
					<span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>				
				<a class="navbar-brand" href="index.php"><?php echo $title; ?></a>
            </div>		
            
			<!-- Middle_Header(Display User Name and ID) -->
			<div class="top-nav-right">
                <a class="navbar-brand" href="profile.php"><i class="fa fa-user"></i>  <?php echo $row_student['stud_name']; ?>  <?php echo $row_student['stud_code']; ?></a>
            </div>	
			
			<!-- Logout -->
            <ul class="nav navbar-right top-nav">
				<li class="dropdown">												
					<a href="#" class="logout"><i class="fa fa-fw fa-power-off"></i> Log Out</a>
                </li>
            </ul>
            
			<!-- Sidebar Menu Items - These collapse to the responsive navigation menu on small screens -->
            <div class="collapse navbar-collapse navbar-ex1-collapse">
                <ul class="nav navbar-nav side-nav">             
                    <!-- Dashboard -->
					<li>
                        <a href="index.php"><i class="glyphicon glyphicon-home"></i>  &nbsp; Dashboard</a>
                    </li>
					
					<!-- Profile -->
                    <li>
                        <a href="javascript:;" data-toggle="collapse" data-target="#list0"><i class="fa fa-fw fa-user"></i>  &nbsp; Profile <i class="fa fa-fw fa-caret-down"></i></a>
                        <ul id="list0" class="collapse">
							<li>
                                <a href="profile.php"> Display Profile</a>
                            </li>                            
							<li>
                                <a href="profile_edit.php"> Edit Profile</a>
                            </li>
							<li>
                                <a href="profile_reset.php"> Reset Password</a>
                            </li>							
                        </ul>						
                    </li>
					
					<!-- Coursework -->
                    <li id="sidebar_cw" class="coursework">
                        <a href="javascript:;" data-toggle="collapse" data-target="#list1"><i class="glyphicon glyphicon-book"></i>  &nbsp; Coursework <i class="fa fa-fw fa-caret-down"></i></a>
                        <ul id="list1" class="collapse sidebar_cw">
							<li>
                                <a href="CW_enroll.php"> Enroll Class </a>
                            </li>
                            <li>
                                <a href="CW_viewclass.php"> View Class info </a>
                            </li>
							<li>
								<a href="CW_viewresult.php"> View Result </a>
							</li>
                        </ul>
                    </li>

					<!-- Research -->					
                    <li id="sidebar_res" class="research active">
                        <a href="javascript:;" data-toggle="collapse" data-target="#list2"><i class="glyphicon glyphicon-education"></i>  &nbsp; Research <i class="fa fa-fw fa-caret-down"></i></a>
                        <ul id="list2" class="collapse sidebar_res in">
                            <li>
                                <a href="res_status.php"> Status</a>
                            </li>
                            <li>
                                <a href="res_topic.php"> Field & Topic</a>
                            </li>
                            <li>
                                <a href="res_sup.php" style="color:white;background-color:black;"> Supervisor Selection</a>
                            </li>
							<li>
                                <a href="res_upload.php"> Document Upload</a>
                            </li>
                        </ul>
                    </li>
					
					<!-- Finance -->
					<li>
                        <a href="javascript:;" data-toggle="collapse" data-target="#list3"><i class="glyphicon glyphicon-usd"></i>  &nbsp; Finance <i class="fa fa-fw fa-caret-down"></i></a>
                        <ul id="list3" class="collapse ">
                            <li>
                                <a href="finance_account.php" > Account Enquiry</a>
                            </li>
                            <li>
                                <a href="finance_grant.php"> View Grant</a>
                            </li>
                            <li>
                                <a href="finance_transaction.php"> Transaction History</a>
                            </li>
                        </ul>
                    </li>
					
					<!-- User guideline -->
                    <li>
                        <a href="userguide.php"><i class="glyphicon glyphicon-question-sign"></i>  &nbsp; User guideline</a>
                    </li>
                </ul>
            </div>
            <!-- /.navbar-collapse -->
        </nav>

        <!-- content inside dashboard -->
		<div id="page-wrapper" style="min-height:400px;">
            <div class="container-fluid">
				
				<!-- Heading-->
				<h2> Selection</h2> 
				
				<div class=" col-md-12 col-lg-12 "> 
							
					<!-- Form of Supervisor-->
					<form method="post"> 
						<table class="table table-responsive">
							<tbody>
								<tr>
									<td width="30%">Main Supervisor </td>
									<td>			
										<?php
											echo "<select class='form-control' id='main_sup_select' name='main_sup_select' required>";
											echo "<option disabled selected value> -- select main supervisor -- </option>";
											$sql_available_sup = "Select * from Supervisor SUP, POSITION P, MAJOR M where 
																	SUP.sup_id = M.sup_id and
																	SUP.pos_id = P.pos_id and
																	stud_limit > stud_amount and
																	field_id = ".$row_student['field_id'].";";
											$row_available_sup = mysqli_query($con,$sql_available_sup);										
											while($result_available_sup = mysqli_fetch_assoc($row_available_sup))
											{
												echo "<option value=".$result_available_sup['sup_id'].">".$result_available_sup['pos_name']." : ".$result_available_sup['sup_name']."</option>";												
											}
											echo "</select>";	
										?>
									</td>
								</tr>
								<tr>
									<td>Co Supervisor </td>
									<td>			
										<?php
											echo "<select class='form-control' id='co_sup_select' name='co_sup_select' required>";
											echo "<option disabled selected value> -- select co supervisor -- </option>";
											$sql_available_sup = "Select * from Supervisor SUP, POSITION P, MAJOR M where 
																	SUP.sup_id = M.sup_id and
																	SUP.pos_id = P.pos_id and
																	stud_limit > stud_amount and
																	field_id = ".$row_student['field_id'].";";
											$row_available_sup = mysqli_query($con,$sql_available_sup);										
											while($result_available_sup = mysqli_fetch_assoc($row_available_sup))
											{
												echo "<option value=".$result_available_sup['sup_id'].">".$result_available_sup['pos_name']." : ".$result_available_sup['sup_name']."</option>";												
											}
											echo "</select>";	
										?>
									</td>
								</tr>	
									
							</tbody>
						</table>

						<button type="submit" class="btn btn-block" id="btnSubmit" name="btnSubmit"><i class="glyphicon glyphicon-send"></i> Submit</button>
					</form>							
				</div>

				<!-- Error if not select field -->
				<div class=" col-md-12 col-lg-12 "> 	
					<br>	
					<a class="deco-none" href="res_topic.php">
						<div class="error alert alert-danger" id="error_1">
							<span class="glyphicon glyphicon-remove-circle"> Must select topic & field first!</span>
						</div>
					</a>
				</div>	
				
				<div class="row">
					<br>
						<div class="col-md-6 col-lg-6" id="main_sup_info">
							<h3>Main Supervisor</h3>
							<table class="table table-responsive">
								<tbody>
									<tr>
										<td width="50%">Name </td>
										<td id="main_name">-</td>
									</tr>
									<tr>
										<td>Position </td>
										<td id="main_pos">-</td>
									</tr>	
									<tr>
										<td>Gender </td>
										<td id="main_gender">-</td>
									</tr>											
									<tr>
										<td>Email </td>
										<td id="main_mail">-</td>
									</tr>
									<tr>
										<td>Contact </td>
										<td id="main_contact">-</td>
									</tr>
									<tr>
										<td>Office </td>
										<td id="main_office">-</td>
									</tr>
									<tr>
										<td>Consultant Day </td>
										<td id="main_cons_day">-</td>
									</tr>
									<tr>
										<td>Consultant Duration</td>
										<td id="main_cons_duration">-</td>
									</tr>
								</tbody>
							</table>
						</div>						
						<div class="col-md-6 col-lg-6" id="co_sup_info">
							<h3>Co Supervisor</h3>
							<table class="table table-responsive">
								<tbody>
									<tr>
										<td width="50%">Name </td>
										<td id="co_name">-</td>
									</tr>
									<tr>
										<td>Position </td>
										<td id="co_pos">-</td>
									</tr>	
									<tr>
										<td>Gender </td>
										<td id="co_gender">-</td>
									</tr>											
									<tr>
										<td>Email </td>
										<td id="co_mail">-</td>
									</tr>
									<tr>
										<td>Contact </td>
										<td id="co_contact">-</td>
									</tr>
									<tr>
										<td>Office </td>
										<td id="co_office">-</td>
									</tr>
									<tr>
										<td>Consultant Day </td>
										<td id="co_cons_day">-</td>
									</tr>
									<tr>
										<td>Consultant Duration</td>
										<td id="co_cons_duration">-</td>
									</tr>											
								</tbody>
							</table>
						</div>
						</div>
			
			</div>
            <!-- /.container-fluid -->

        </div>
        <!-- /#page-wrapper -->

    </div>
    <!-- /#wrapper -->

</body>

<script>
function setInfo(type)
{
	if(type == 'main')	//set main supervisor info
	{
		var sup_id = $('#main_sup_select').val();
		//using ajax to pass sup_id to res_sup_ajax.php and get Object response
		$.ajax({
			type: 'POST',
			url: 'res_sup_ajax.php',
			data: {sup_id: sup_id},
			dataType : 'json',
			success: function (response) {
				$('#main_name').html(response.sup_name);
				$('#main_pos').html(response.pos_name);
				$('#main_gender').html(response.sup_gender);
				$('#main_mail').html(response.sup_email);
				$('#main_contact').html(response.sup_contact);
				$('#main_office').html(response.sup_office);
				$('#main_cons_day').html(response.sup_consultday);
				$('#main_cons_duration').html(response.sup_consulttime);
			},
			error: function () {
				alert("not valid");
			}
		});
	}
	else	//set co supervisor info
	{
		var sup_id = $('#co_sup_select').val();
		//using ajax to pass sup_id to res_sup_ajax.php and get Object response
		$.ajax({
			type: 'POST',
			url: 'res_sup_ajax.php',
			data: {sup_id: sup_id},
			dataType : 'json',
			success: function (response) {
				$('#co_name').html(response.sup_name);
				$('#co_pos').html(response.pos_name);
				$('#co_gender').html(response.sup_gender);
				$('#co_mail').html(response.sup_email);
				$('#co_contact').html(response.sup_contact);
				$('#co_office').html(response.sup_office);
				$('#co_cons_day').html(response.sup_consultday);
				$('#co_cons_duration').html(response.sup_consulttime);
			},
			error: function () {
				alert("not valid");
			}
		});		
	}
}

function clearInfo(type)
{
	if(type == 'main')	//clear main supervisor info
	{
		$('#main_name').html('-');
		$('#main_pos').html('-');
		$('#main_gender').html('-');
		$('#main_mail').html('-');
		$('#main_contact').html('-');
		$('#main_office').html('-');
		$('#main_cons_day').html('-');
		$('#main_cons_duration').html('-');		
	}
	else	//clear co supervisor info
	{
		$('#co_name').html('-');
		$('#co_pos').html('-');
		$('#co_gender').html('-');
		$('#co_mail').html('-');
		$('#co_contact').html('-');
		$('#co_office').html('-');
		$('#co_cons_day').html('-');
		$('#co_cons_duration').html('-');		
	}
}


$(document).ready(function() {
	
	//avoid select same supervisor
	$('#main_sup_select').change(function() {
		if($('#main_sup_select').val() ==  $('#co_sup_select').val()){
			$('#co_sup_select').val("");
			clearInfo("co");
		};
		setInfo("main");
	});
	$('#co_sup_select').change(function() {
		if($('#main_sup_select').val() ==  $('#co_sup_select').val()){
			$('#main_sup_select').val("");
			clearInfo("main");
		};
		setInfo("co");
	});
	
	//disable if topic and field not yet submitted
	var proceed = "<?php echo $proceed; ?>";
	if (proceed == "F")
	{
		$('#error_1').css('display', 'block');	
		$('#main_sup_select').prop('disabled', true);
		$('#co_sup_select').prop('disabled', true);
		$('#btnSubmit').attr('disabled', 'disabled');
	}
	else
	{
		$('#error_1').css('display', 'none');					
		var submit_status = "<?php echo $submit_status; ?>";
		//supervisor already selected, disable button and display info directly
		if (submit_status == "T")
		{
			$('#main_sup_select').prop('disabled', true);
			$('#main_sup_select').val('<?php echo $row_student['sup_id']; ?>');
			$('#co_sup_select').prop('disabled', true);
			$('#co_sup_select').val('<?php echo $row_student['co_sup_id']; ?>');
			$('#btnSubmit').html('Submitted');
			$('#btnSubmit').attr('disabled', 'disabled');	
			
			//main supervisor info
			$('#main_name').html('<?php echo $row_main_sup['sup_name']; ?>');
			$('#main_pos').html('<?php echo $row_main_sup['pos_name']; ?>');
			$('#main_gender').html('<?php echo $row_main_sup['sup_gender']; ?>');
			$('#main_mail').html('<?php echo $row_main_sup['sup_email']; ?>');
			$('#main_contact').html('<?php echo $row_main_sup['sup_contact']; ?>');
			$('#main_office').html('<?php echo $row_main_sup['sup_office']; ?>');
			$('#main_cons_day').html('<?php echo $row_main_sup['sup_consultday']; ?>');
			$('#main_cons_duration').html('<?php echo $row_main_sup['sup_consulttime']; ?>');

			//co supervisor info
			$('#co_name').html('<?php echo $row_co_sup['sup_name']; ?>');
			$('#co_pos').html('<?php echo $row_co_sup['pos_name']; ?>');
			$('#co_gender').html('<?php echo $row_co_sup['sup_gender']; ?>');
			$('#co_mail').html('<?php echo $row_co_sup['sup_email']; ?>');
			$('#co_contact').html('<?php echo $row_co_sup['sup_contact']; ?>');
			$('#co_office').html('<?php echo $row_co_sup['sup_office']; ?>');
			$('#co_cons_day').html('<?php echo $row_co_sup['sup_consultday']; ?>');
			$('#co_cons_duration').html('<?php echo $row_co_sup['sup_consulttime']; ?>');
			
		}		
	}

	//Determination of student type
	var stud_type = "<?php echo $_SESSION['stud_type']; ?>";
	if (stud_type == "Coursework")
	{
		$('.research').css({'display': 'none'});
	}
	else if (stud_type == "Research")
	{
		$('.coursework').css({'display': 'none'});
	}
	
	//logout confirmation
	$(".logout").click(function(){		
		swal({
			title: 'Logout',
			text: "Logout from Postgraduate Management System",
			type: 'warning',
			showCancelButton: true,
			confirmButtonColor: '#3085d6',
			cancelButtonColor: '#d33',
			confirmButtonText: 'Yes'
		}).then(function () {
				window.location.href ="../logout.php";
		})			
	});	
	
});	


</script>

</html>

<?php

if(isset($_POST['btnSubmit']))
{
	
	$sup_id=$_POST['main_sup_select'];
	$co_sup_id=$_POST['co_sup_select'];
	
	$sql = "UPDATE RESEARCHSTD SET sup_id = '$sup_id', co_sup_id = '$co_sup_id', res_status = 'Proposal Preparation' where stud_id = '$stud_id'";
	
	
	if (mysqli_query($con, $sql)) {
		//update student amount of supervisor
		$sql_update_sup = "update SUPERVISOR SET stud_amount = (stud_amount + 1) where sup_id in ('$sup_id','$co_sup_id');";
		mysqli_query($con, $sql_update_sup);
		?>
		<script type="text/javascript">
			swal({ 
					title: "Successfull!",
					text: "Supervisor Selection Successfull",
					type: "success"
			});
			//set the info of selected supervisor
			$('#main_sup_select').prop('disabled', true);
			$('#main_sup_select').val('<?php echo $sup_id; ?>');
			$('#co_sup_select').prop('disabled', true);
			$('#co_sup_select').val('<?php echo $co_sup_id; ?>');
			$('#btnSubmit').html('Submitted');
			$('#btnSubmit').attr('disabled', 'disabled');
			setInfo("main");
			setInfo("co");
		</script>
	<?php
	}
	else{
		?>
		<script type="text/javascript">
			alert("failed");
		</script>
	<?php		
	}
	

}
?>