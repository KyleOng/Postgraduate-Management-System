<?php
	include("../dataconnect.php");
	if($_SESSION["loggedins"]!=1)
	{
		echo"<script> window.location.href ='../login.php';</script>";
	}

	$sup_id = $_POST['sup_id'];
	$sql = "select * from SUPERVISOR S, POSITION P where S.pos_id = P.pos_id and sup_id = '$sup_id';";
	$row = mysqli_fetch_assoc(mysqli_query($con,$sql));

	if(mysqli_fetch_assoc(mysqli_query($con,$sql)))
	{
		$array = array(
						"sup_name"=>$row['sup_name'],
						"pos_name"=>$row['pos_name'],
						"sup_gender"=>$row['sup_gender'],
						"sup_email"=>$row['sup_email'],
						"sup_contact"=>$row['sup_contact'],
						"sup_office"=>$row['sup_office'],
						"sup_consultday"=>$row['sup_consultday'],
						"sup_consulttime"=>$row['sup_consulttime']
						);		
		echo json_encode($array);
	}
?>