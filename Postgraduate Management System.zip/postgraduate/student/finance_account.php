<?php
	include("../dataconnect.php");
	if($_SESSION["loggedins"]!=1)
	{
		echo"<script> window.location.href ='../login.php';</script>";
	}
	session_start();
	//Student general information	
	$stud_id = $_SESSION['stud_id'];	
	$sql_student = "select * from STUDENT S, REGISTRATION R, PROGRAMME P where 
					S.reg_id = R.reg_id and
					R.prog_id = P.prog_id and
					stud_id='$stud_id'";
	$row_student = mysqli_fetch_assoc(mysqli_query($con,$sql_student));
	$type = $_SESSION['stud_type'];
	if($_SESSION['stud_type'] == 'Research')
	{
		$title = "Research Student";
	}
	else
	{
		$title = "Coursework Student";
	}
?>

<!DOCTYPE html>
<html lang="en">
<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
	
    <title>Postgraduate</title>

    <!-- Bootstrap Core CSS -->
    <link href="../source/css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom CSS -->
    <link href="../source/css/sb-admin.css" rel="stylesheet">

	<!-- Awesome Fonts -->
    <link href="../source/font-awesome-4.7.0/css/font-awesome.min.css" rel="stylesheet" type="text/css">

	<!-- Sweet Alert -->
	<script src="../source/sweetalert/dist/sweetalert2.min.js"></script> 
	<link rel="stylesheet" type="text/css" href="../source/sweetalert/dist/sweetalert2.css">
	
	<!-- jQuery -->
    <script src="../source/js/jquery.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="../source/js/bootstrap.min.js"></script>
</head>

<body>

    <div id="wrapper">

        <!-- Navigation -->
        <nav class="navbar navbar-inverse navbar-fixed-top" role="navigation">
            
			<!-- Left_Header(Display User Type) -->
			<div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-ex1-collapse">
                    <!-- Drop down bar in small screen -->
					<span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>				
				<a class="navbar-brand" href="index.php"><?php echo $title; ?></a>
            </div>		
            
			<!-- Middle_Header(Display User Name and ID) -->
			<div class="top-nav-right">
                <a class="navbar-brand" href="profile.php"><i class="fa fa-user"></i>  <?php echo $row_student['stud_name']; ?>  <?php echo $row_student['stud_code']; ?></a>
            </div>	
			
			<!-- Logout -->
            <ul class="nav navbar-right top-nav">
				<li class="dropdown">												
					<a href="#" class="logout"><i class="fa fa-fw fa-power-off"></i> Log Out</a>
                </li>
            </ul>
            
			<!-- Sidebar Menu Items - These collapse to the responsive navigation menu on small screens -->
            <div class="collapse navbar-collapse navbar-ex1-collapse">
                <ul class="nav navbar-nav side-nav">             
                    <!-- Dashboard -->
					<li>
                        <a href="index.php"><i class="glyphicon glyphicon-home"></i>  &nbsp; Dashboard</a>
                    </li>
					
					<!-- Profile -->
                    <li>
                        <a href="javascript:;" data-toggle="collapse" data-target="#list0"><i class="fa fa-fw fa-user"></i>  &nbsp; Profile <i class="fa fa-fw fa-caret-down"></i></a>
                        <ul id="list0" class="collapse">
							<li >
                                <a href="profile.php"> Display Profile</a>
                            </li>                            
							<li>
                                <a href="profile_edit.php"> Edit Profile</a>
                            </li>
							<li>
                                <a href="profile_reset.php"> Reset Password</a>
                            </li>							
                        </ul>						
                    </li>
					
					<!-- Coursework -->
                    <li id="sidebar_cw" class="coursework">
                        <a href="javascript:;" data-toggle="collapse" data-target="#list1"><i class="glyphicon glyphicon-book"></i>  &nbsp; Coursework <i class="fa fa-fw fa-caret-down"></i></a>
                        <ul id="list1" class="collapse sidebar_cw">
							<li>
                                <a href="CW_enroll.php"> Enroll Class </a>
                            </li>
                            <li>
                                <a href="CW_viewclass.php"> View Class info </a>
                            </li>
							<li>
								<a href="CW_viewresult.php"> View Result </a>
							</li>
                        </ul>
                    </li>

					<!-- Research -->					
                    <li id="sidebar_res" class="research">
                        <a href="javascript:;" data-toggle="collapse" data-target="#list2"><i class="glyphicon glyphicon-education"></i>  &nbsp; Research <i class="fa fa-fw fa-caret-down"></i></a>
                        <ul id="list2" class="collapse sidebar_res">
                            <li>
                                <a href="res_status.php"> Status</a>
                            </li>
                            <li>
                                <a href="res_topic.php"> Field & Topic</a>
                            </li>
                            <li>
                                <a href="res_sup.php"> Supervisor Selection</a>
                            </li>
							<li>
                                <a href="res_upload.php"> Document Upload</a>
                            </li>
                        </ul>
                    </li>
					
					<!-- Finance -->
                    <li class="active">
                        <a href="javascript:;" data-toggle="collapse" data-target="#list3"><i class="glyphicon glyphicon-usd"></i>  &nbsp; Finance <i class="fa fa-fw fa-caret-down"></i></a>
                        <ul id="list3" class="collapse in">
                            <li>
                                <a href="finance_account.php" style="color:white;background-color:black;"> Account Enquiry</a>
                            </li>
                            <li>
                                <a href="finance_grant.php"> View Grant</a>
                            </li>
                            <li>
                                <a href="finance_transaction.php"> Transaction History</a>
                            </li>
                        </ul>
                    </li>

					
					<!-- User guideline -->
                    <li>
                        <a href="userguide.php"><i class="glyphicon glyphicon-question-sign"></i>  &nbsp; User guideline</a>
                    </li>
                </ul>
            </div>
            <!-- /.navbar-collapse -->
        </nav>

        <!-- content -->
		<div id="page-wrapper" style="min-height:400px;">
            <div class="container-fluid">
				
				<h2>Account Enquiry</h2><br/>
				<?php 
				if ($_SESSION['stud_type'] == 'Research') // student type is research have different calculations for fee
				{
				?>
				<!-- student finance account table -->
                <div class=" col-md-12 col-lg-12 "> 
                    <table class="table table-responsive table-bordered" style="width: 100%;">
                        <tbody>
                          <tr>
							<th>No</th>
                            <th>Programme Name</th>
							<th>Year</th>
							<th>Register Fee</th>
							<th>Annual Resource Fee</th>
							<th>Annual Tuition Fee</th>
							<th>Examination Fee</th>
                          </tr>
                          <?php
								$sql1="select *,FLOOR(DATEDIFF(CURRENT_DATE,(select intake_date from student where stud_id=$stud_id))/365) as datediff from research INNER JOIN registration ON registration.prog_id=research.prog_id INNER JOIN programme ON programme.prog_id=research.prog_id INNER JOIN student ON registration.reg_id=student.reg_id WHERE student.stud_id = '$stud_id'";
                                
                                $result1=mysqli_query($con,$sql1);

								$i=1;
                                if(mysqli_num_rows($result1)!=0)
                                {
                                    while($row1=mysqli_fetch_assoc($result1))
                                    {
                                
                                echo"<tr>";
									 echo"<td>". $i++." </td>";
                                     echo"<td>". $row1['prog_name']."</td>";
                                     echo"<td>". $row1['datediff']."</td>";
                                     echo"<td>". $row1['res_reg_fee']."</td>";
                                    echo" <td>". $row1['res_annual_resource_fee']."</td>";
                                    echo" <td>". $row1['res_annual_tuition_fee']."</td>";
                                     echo"<td>". $row1['res_examination_fee']."</td>";
									$duration=$row1['datediff'];
									mysqli_query($con,"UPDATE Student SET duration ='$duration' WHERE student.stud_id = $stud_id ");
                                echo" </tr>";
                                
                                    }
                                }
                                 else
								{
								?>
								<tr>
								  <td colspan='7' style="text-align:center; font-size:1.4em;">No record found!</td>
								</tr>
								<?php
								}
								
                           ?>
                        </tbody>
					</table>
				</div>
				
				<!-- student overal finance status table -->
				<div class=" col-md-12 col-lg-12 "> 
				
                    <table class="table table-responsive table-bordered" style="width: 100%;">
                        <tbody>
                          <tr>
                            <th>Total Fee</th>
							<th>Total Paid</th>
                            <th>Balance </th>
                          </tr>
						  
                          <?php
						  $check="select * from payment where stud_id=$stud_id";
						  
						  if (mysqli_num_rows(mysqli_query($con,$check))>0)
						  {
							 $sql2="SELECT (research.res_reg_fee +research.res_examination_fee) + ((research.res_annual_resource_fee + research.res_annual_tuition_fee)*student.duration) as total,
								student.stud_total_pay ,((research.res_reg_fee +research.res_examination_fee) + ((research.res_annual_resource_fee + research.res_annual_tuition_fee)*student.duration)-sum(payment.pay_amount)) as balance
								from research,registration,student,payment  where research.prog_id=registration.prog_id and registration.reg_id=student.reg_id and payment.stud_id=student.stud_id and student.stud_id=$stud_id"; 
						  }
						  else
						  {
							 $sql2="SELECT (research.res_reg_fee +research.res_examination_fee) + ((research.res_annual_resource_fee + research.res_annual_tuition_fee)*student.duration) as total,
								student.stud_total_pay ,((research.res_reg_fee +research.res_examination_fee) + ((research.res_annual_resource_fee + research.res_annual_tuition_fee)*student.duration)) as balance
								from research,registration,student  where research.prog_id=registration.prog_id and registration.reg_id=student.reg_id and student.stud_id=$stud_id";
						  }
								
                                
                                $result2=mysqli_query($con,$sql2);

                                if(mysqli_num_rows($result2)!=0)
                                {
                                    while($row1=mysqli_fetch_assoc($result2))
                                    {
                                ?>
                                    <td><?php echo $row1['total'];?></td>
                                    <td><?php echo $row1['stud_total_pay'];?></td>
                                    <td><?php echo $row1['balance'];?></td>
									<?php $total=$row1['total'];?>
									<?php mysqli_query($con,"UPDATE Student SET stud_finance ='$total' WHERE student.stud_id = '$stud_id' ");?>
        
                                </tr>
                                <?php
                                    }
                                }
                                 else
								{
									?>
									<tr>
									  <td colspan='7' style="text-align:center; font-size:1.4em;">No record found!</td>
									</tr>
									<?php
								}
								
								
							?>
                        </tbody>
					</table>
				</div>
				<?php
				}
				
	//-------------------------------------------------------------------------------------------------------------------------------------------------			
	
			if ($_SESSION['stud_type'] == 'Coursework')   // student type is research have different calculations for fee
				{
				?>
	
				<!--   student finance table  -->
	
                <div class=" col-md-12 col-lg-12 "> 
                    <table class="table table-responsive table-bordered" style="width: 100%;">
                        <tbody>
                          <tr>
							<th>No</th>
                            <th>Programme Name</th>
							<th>Year</th>
							<th>Register Fee</th>
							<th>Annual Resource Fee</th>
							<th>Tuition Fee</th>
							<th>Total Subject Fee</th>
							<th>Total Credit Hour</th>
                          </tr>
                          <?php
								$sql1="select * ,FLOOR(DATEDIFF(CURRENT_DATE,(select intake_date from student where stud_id=$stud_id))/365) as datediff , 

								(SELECT SUM(subject.subject_fee) from subject,registration,student Where subject.prog_id=registration.prog_id and registration.reg_id=student.reg_id and student.stud_id=$stud_id) as totalsubjectfee

								, (SELECT SUM(subject.subject_credit_hr) as SumCredit from subject,registration,student Where subject.prog_id=registration.prog_id and registration.reg_id=student.reg_id and student.stud_id=$stud_id) as SumCredit
								
								from coursework INNER JOIN registration ON registration.prog_id=coursework.prog_id INNER JOIN programme ON programme.prog_id=coursework.prog_id INNER JOIN student ON registration.reg_id=student.reg_id WHERE student.stud_id = $stud_id";
                                
                                $result1=mysqli_query($con,$sql1);

								$i=1;
                                if(mysqli_num_rows($result1)!=0)
                                {
                                    while($row1=mysqli_fetch_assoc($result1))
                                    {
                          
                                echo"<tr>";
									echo"<td>".$i++."</td>";
                                   echo" <td>".$row1['prog_name']."</td>";
                                   echo" <td>".$row1['datediff']."</td>";
                                   echo" <td>".$row1['cs_reg_fee']."</td>";
                                   echo" <td>".$row1['cs_annual_resource_fee']."</td>";
                                   echo" <td>".$row1['cs_tuition_fee']."</td>";
                                   echo" <td>".$row1['totalsubjectfee']."</td>";
                                   echo" <td>".$row1['SumCredit']."</td>";
									$duration=$row1['datediff'];
									
									mysqli_query($con,"UPDATE Student SET duration ='$duration' WHERE student.stud_id = $stud_id ");
									
                                echo"</tr>";
                          
                                    }
                                }
                                 else
                        {
                        ?>
                        <tr>
                          <td colspan='7' style="text-align:center; font-size:1.4em;">No record found!</td>
                        </tr>
                        <?php
                        }
                           ?>
                        </tbody>
					</table>
				</div>
				
				<!--  overal student finance table-->
	
				<div class=" col-md-12 col-lg-12 "> 
				
                    <table class="table table-responsive table-bordered" style="width: 100%;">
                        <tbody>
                          <tr>
                            <th>Total Fee</th>
							<th>Total Paid</th>
                            <th>Balance </th>
                          </tr>
						  
                          <?php
							$check="select * from payment where stud_id=$stud_id";
						  
							if (mysqli_num_rows(mysqli_query($con,$check))>0)
							{
								$sql2="select coursework.cs_reg_fee + coursework.cs_tuition_fee + (coursework.cs_annual_resource_fee*student.duration) +

										(select SUM(subject.subject_fee) from subject,registration,student Where subject.prog_id=registration.prog_id and registration.reg_id=student.reg_id and student.stud_id=$stud_id) as totalfee, 

										sum(payment.pay_amount) as totalpay,

										(select coursework.cs_reg_fee + coursework.cs_tuition_fee + (coursework.cs_annual_resource_fee*student.duration) +
										(select SUM(subject.subject_fee) from subject,registration,student Where subject.prog_id=registration.prog_id and registration.reg_id=student.reg_id and student.stud_id=$stud_id))-(select sum(payment.pay_amount) from payment where payment.stud_id=student.stud_id and student.stud_id=$stud_id) as balance

										from coursework,registration,student,payment WHERE coursework.prog_id=registration.prog_id and registration.reg_id=student.reg_id and student.stud_id=$stud_id and payment.stud_id=student.stud_id";
							}
							
							else
							{
								$sql2="select coursework.cs_reg_fee + coursework.cs_tuition_fee + (coursework.cs_annual_resource_fee*student.duration) +

										(select SUM(subject.subject_fee) from subject,registration,student Where subject.prog_id=registration.prog_id and registration.reg_id=student.reg_id and student.stud_id=$stud_id) as totalfee, 

										

										(select coursework.cs_reg_fee + coursework.cs_tuition_fee + (coursework.cs_annual_resource_fee*student.duration) +
										(select SUM(subject.subject_fee) from subject,registration,student Where subject.prog_id=registration.prog_id and registration.reg_id=student.reg_id and student.stud_id=$stud_id)) as balance

										from coursework,registration,student WHERE coursework.prog_id=registration.prog_id and registration.reg_id=student.reg_id and student.stud_id=$stud_id";
							}
						  
								
                                
                                $result2=mysqli_query($con,$sql2);

                                if(mysqli_num_rows($result2)!=0)
                                {
                                    while($row1=mysqli_fetch_assoc($result2))
                                    {
                                ?>
                                    <td><?php echo $row1['totalfee'];?></td>
                                    <td><?php echo $row1['totalpay'];?></td>
                                    <td><?php echo $row1['balance'];?></td>
									<?php $total=$row1['totalfee'];?>
									<?php mysqli_query($con,"UPDATE Student SET stud_finance ='$total' WHERE student.stud_id = '$stud_id' ");?>
        
                                </tr>
                                <?php
                                    }
                                }
                                 else
								{
									?>
									<tr>
									  <td colspan='7' style="text-align:center; font-size:1.4em;">No record found!</td>
									</tr>
									<?php
								}
								
								
							?>
                        </tbody>
					</table>
				</div>
				
				<div class=" col-md-12 col-lg-12 "> 
					<button onClick="reply_click()"  class="btn btn-block" id="btnDelete" name="btnDelete"><span class="glyphicon glyphicon-share"></span> Subject Details</button>
				</div>
				<?php
				}

				?>
            
			</div>
            <!-- /.container-fluid -->

        </div>
        <!-- /#page-wrapper -->

    </div>
    <!-- /#wrapper -->

</body>

<script>
$(document).ready(function() {
	
	//Determination of student type
	var stud_type = "<?php echo $_SESSION['stud_type']; ?>";
	if (stud_type == "Coursework")
	{
		$('.research').css({'display': 'none'});
	}
	else if (stud_type == "Research")
	{
		$('.coursework').css({'display': 'none'});
	}
	
	//logout confirmation
	$(".logout").click(function(){		
		swal({
			title: 'Logout',
			text: "Logout from Postgraduate Management System",
			type: 'warning',
			showCancelButton: true,
			confirmButtonColor: '#3085d6',
			cancelButtonColor: '#d33',
			confirmButtonText: 'Yes'
		}).then(function () {
				window.location.href ="../logout.php";
		})			
	});
});

function reply_click(){
		window.location.href ="finance_subjectL.php";

	}
</script>

</html>
