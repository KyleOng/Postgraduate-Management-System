<?php
	include("dataconnect.php");
	unset($_SESSION['stud_id']);
	unset($_SESSION['stud_code']);
	unset($_SESSION['stud_type']);
	unset($_SESSION['sup_id']);
	unset($_SESSION['sup_code']);
	unset($_SESSION["admin_id"]);
	unset($_SESSION["loggedins"]);	
	
	echo "<script>window.location.href ='login.php';</script>";
?>