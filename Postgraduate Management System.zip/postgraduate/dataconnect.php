<?php
$host="localhost";
$user="root";
$password="";
$db="pmsdb";

$con=mysqli_connect($host,$user,$password,$db);
$mysqli_conn = new mysqli($host,$user,$password,$db); //connect to MySql

    if(!isset($_SESSION)) 
    { 
        session_start(); 
    } 

ob_start();
error_reporting(0);
?>