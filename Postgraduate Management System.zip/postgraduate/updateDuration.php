<?php
	include("dataconnect.php");

	$sql_duration="Update STUDENT set duration = DATEDIFF(CURDATE(),intake_date)/365 where stud_status = 'active' or stud_status = 'pregraduate';";
	mysqli_query($con,$sql_duration);
?>