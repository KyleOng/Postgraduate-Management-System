<?php
	include("../dataconnect.php");
	if($_SESSION["loggedins"]!=1)
	{
		echo"<script> window.location.href ='../login.php';</script>";
	}
	session_start();
	$sup_id = $_SESSION["sup_id"];
	$sup_code = $_SESSION["sup_code"];
	
	$sql_sup = "select * from SUPERVISOR where sup_id='$sup_id'";
	$row_sup = mysqli_fetch_assoc(mysqli_query($con,$sql_sup));
	
	$sup_prog_id = $row_sup['prog_id'];
	$sql_prog = "select * from PROGRAMME where prog_id='$sup_prog_id'";
	$row_prog = mysqli_fetch_assoc(mysqli_query($con,$sql_prog));
	$sup_prog_name = $row_prog['prog_name'];
	
	$sup_pos_id = $row_sup['pos_id'];
	$sql_pos = "select * from POSITION where pos_id='$sup_pos_id'";
	$row_pos = mysqli_fetch_assoc(mysqli_query($con,$sql_pos));
	$sup_pos_name = $row_pos['pos_name'];
?>

<!DOCTYPE html>
<html lang="en">
<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Supervisor Class Edit</title>

    <!-- Bootstrap Core CSS -->
    <link href="../source/css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom CSS -->
    <link href="../source/css/sb-admin.css" rel="stylesheet">

    <!-- Custom Fonts -->
    <link href="../source/font-awesome-4.7.0/css/font-awesome.min.css" rel="stylesheet" type="text/css">

	<!-- Sweet Alert -->
	<script src="../source/sweetalert/dist/sweetalert2.min.js"></script> 
	<link rel="stylesheet" type="text/css" href="../source/sweetalert/dist/sweetalert2.css">

    <script src="../source/js/jquery.js"></script>


</head>
<style>
    label
    {
        margin-top: 10px;
    }

    a:hover
    {
        text-decoration: none;
    }

    #form1 label.passError
    {   font-family: 'Tahoma' !important;
        color:#CC0000;
        font-weight:bold;
        font-size:13px;
        padding-left:20px;
        display:block;
    }
    #form1 label.passValid
    {   font-family: 'Tahoma' !important;
        color:#00bd00;
        font-weight:bold;
        font-size:13px;
        padding-left:20px;
        display:block;
    }

    .passError 
    {   background:url("../source/picture/error.png") no-repeat 2px 2px;
        padding-left: 16px;
    }

    .passValid 
    {   background:url("../source/picture/tick.png") no-repeat 2px 2px;
        padding-left: 16px;
        color:GREEN;
    }
</style>


<body>

    <div id="wrapper">

        <!-- Navigation -->
        <nav class="navbar navbar-inverse navbar-fixed-top" role="navigation">
            
			<!-- Left_Header(Display User Type) -->
			<div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-ex1-collapse">
                    <!-- Drop down bar in small screen -->
					<span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>				
				<a class="navbar-brand" href="index.php"><?php echo $sup_pos_name; ?></a>
            </div>		
            
			<!-- Middle_Header(Display User Name and ID) -->
			<div class="top-nav-right">
                <a class="navbar-brand" href="profile.php"><i class="fa fa-user"></i>  <?php echo $row_sup['sup_name']; ?>  <?php echo $row_sup['sup_code']; ?></a>
            </div>	
			
			<!-- Logout -->
            <ul class="nav navbar-right top-nav">
				<li class="dropdown">												
					<a href="#" class="logout"><i class="fa fa-fw fa-power-off"></i> Log Out</a>
                </li>
            </ul>
            
			<!-- Sidebar Menu Items - These collapse to the responsive navigation menu on small screens -->
            <div class="collapse navbar-collapse navbar-ex1-collapse">
                <ul class="nav navbar-nav side-nav">             
                    <!-- Dashboard -->
					<li>
                        <a href="index.php"><i class="glyphicon glyphicon-home"></i>  &nbsp; Dashboard</a>
                    </li>
					
					<!-- Profile -->
                    <li>
                        <a href="javascript:;" data-toggle="collapse" data-target="#list0"><i class="fa fa-fw fa-user"></i>  &nbsp; Profile <i class="fa fa-fw fa-caret-down"></i></a>
                        <ul id="list0" class="collapse">
							<li>
                                <a href="profile.php"> Display Profile</a>
                            </li>                            
							<li>
                                <a href="profile_edit.php"> Edit Profile</a>
                            </li>
							<li>
                                <a href="profile_reset.php"> Reset Password</a>
                            </li>	
							<li>
                                <a href="profile_addfield.php"> Add Field</a>
                            </li>							
                        </ul>						
                    </li>
					
					<!-- Coursework -->
                    <li id="sidebar_cw" class="active">
                        <a href="javascript:;" data-toggle="collapse" data-target="#list1"><i class="glyphicon glyphicon-book"></i>  &nbsp; Coursework <i class="fa fa-fw fa-caret-down"></i></a>
                        <ul id="list1" class="collapse sidebar_cw in">
							<li>
                                <a href="CW_class.php" style="color:white;background-color:black;"> View Class Info</a>
                            </li>                            
							<li>
                                <a href="CW_addclass.php"> Open New Class</a>
                            </li>
                            <li>
                                <a href="CW_updateresult.php"> Update Student Result</a>
                            </li>
                            <li>
                                <a href="CW_classStuList.php"> Generate Report</a>
                            </li>							
                        </ul>
                    </li>

					<!-- Research -->					
                    <li id="sidebar_res">
                        <a href="javascript:;" data-toggle="collapse" data-target="#list2"><i class="glyphicon glyphicon-education"></i>  &nbsp; Research <i class="fa fa-fw fa-caret-down"></i></a>
                        <ul id="list2" class="collapse sidebar_res">
                            <li>
                                <a href="res_view_status.php"> View Research Status</a>
                            </li>
                            <li>
                                <a href="res_update.php"> Update Status & Journal</a>
                            </li>
                            <li>
                                <a href="res_journal.php"> Update Journal Status</a>
                            </li> 
                            <li>
                                <a href="res_download.php"> Download Document</a>
                            </li>
                        </ul>
                    </li>

					<!-- User guideline -->
                    <li>
                        <a href="userguide.php"><i class="glyphicon glyphicon-question-sign"></i>  &nbsp; User guideline</a>
                    </li>
                </ul>
            </div>
            <!-- /.navbar-collapse -->
        </nav>

        <!-- form started -->
        <form method="post" action="" id="form1" name="form1">
        <div id="page-wrapper" style="min-height:660px;">
            <div class="container-fluid">
				<h2>Edit Class</h2><br/>
                <?php
                    $ci = $_REQUEST["ci"];
                    $sql = "select * from class where class_id='$ci' ";
                    $result = mysqli_query($con,$sql);
                    $row = mysqli_fetch_assoc($result);
                ?>
                        <div class="row">
                          <div class="col-md-12">
                                <label for="name">Subject Name</label>
                                <select class="form-control pw" name="subname" disabled>
                                    <option disabled>----------Please select a subject---------</option>
                                    <?php

                                    $sql1="select * from subject";
                                    $result1=mysqli_query($con,$sql1);
                                    while($row1=mysqli_fetch_assoc($result1))
                                    {

                                    ?>
                                    <option value="<?php echo $row1['subject_id'];?>" <?php if($row1['subject_id']==$row['subject_id']) echo "selected=selected" ;?> ><?php echo $row1['subject_name'];?></option>
                                            <?php
                                                }
                                        ?>
                                </select>
                          </div>
                          </div>
                          <div class="row">
                          <div class="col-md-4">
                                <label for="venue">Class Venue</label>
                                <select class="form-control pw" name="csvenue" id="csvenue">
                                    <option disabled> ----------Please select a venue---------</option>
                                    <option value="CQCR3005">CQCR3005</option>
                                    <option value="CQBR2002">CQBR2002</option>
                                    <option value="CQMR1004">CQMR1004</option>
                                    <option value="CQAR0001">CQAR0001</option>
                                </select>
                                    <?php 
                                        $venue1=$row['class_venue']; 

                                        ?>
                                        <script>
                                            var spnm_value = '<?php echo $venue1 ?>';
                                            $('#csvenue option').each(function(){
                                                var $this = $(this); // cache this jQuery object to avoid overhead

                                                if ($this.val() == spnm_value) { // if this option's value is equal to our value
                                                    $this.prop('selected', true); // select this option
                                                    return false;
                                                }
                                            });
                                        </script>
                          </div>
                          <div class="col-md-4">
                                <label for="code">Class Code</label>
                                <input type="text" class="form-control pw" placeholder="Exp: TSN0001" value="<?php echo $row['class_code']?>" name="cscode" disabled>
                          </div>
                        </div>
                        <div class="row">
                          <div class="col-md-8">
                                <label for="Starttime">Class Time</label>
                                <select class="form-control pw" name="cstime" id="cstime">
                                    <option disabled> ----------Please select a time slot---------</option>
                                    <option value="9.00am-11.00am" >9.00  am - 11.00 am</option>
                                    <option value="11.00am-1.00pm">11.00 am - 1.00 pm</option>
                                    <option value="1.00pm-3.00pm">1.00   pm - 3.00 pm</option>
                                    <option value="3.00pm-5.00pm">3.00   pm - 5.00 pm</option>
                                    <option value="5.00pm-7.00pm">5.00   pm - 7.00 pm</option>
                                </select>

                                <?php 
                                        $time1=$row['class_time']; 

                                        ?>
                                        <script>
                                            var spnm_value = '<?php echo $time1 ?>';
                                            $('#cstime option').each(function(){
                                                var $this = $(this); // cache this jQuery object to avoid overhead

                                                if ($this.val() == spnm_value) { // if this option's value is equal to our value
                                                    $this.prop('selected', true); // select this option
                                                    return false;
                                                }
                                            });
                                        </script>

                          </div>
                          <div class="col-md-4" style="margin-top: 15px;">
                                <label for="Day"></label>
                                <select class="form-control pw" name="csday" id="csday">
                                    <option disabled>----------Please select a day---------</option>
                                    <option value="Monday" selected>Monday</option>
                                    <option value="Tuesday">Tuesday</option>
                                    <option value="Wednesday">Wednesday</option>
                                    <option value="Thursday">Thursday</option>
                                    <option value="Friday">Friday</option>
                                </select>
                                <?php 
                                        $day1=$row['class_day']; 

                                        ?>
                                        <script>
                                            var spnm_value = '<?php echo $day1 ?>';
                                            $('#csday option').each(function(){
                                                var $this = $(this); // cache this jQuery object to avoid overhead

                                                if ($this.val() == spnm_value) { // if this option's value is equal to our value
                                                    $this.prop('selected', true); // select this option
                                                    return false;
                                                }
                                            });
                                        </script>

                          </div>
                        </div>

                        <br/>
                        <button type="submit" name="subbtn" class="btn btn-default btn-block addcbtn" style="background-color: #e4e4e4; "><i class="glyphicon glyphicon-floppy-saved" ></i> Save</button>
                        <a href="CW_class.php"><button type="button" class="btn btn-default btn-block addcbtn" style="background-color: #e4e4e4; margin-top:10px; "><i class="glyphicon glyphicon-remove"></i> Cancel</button></a>
                </div>
			</div>
            </div>
            </form>
            <!-- /.container-fluid -->
            <!-- form end -->

        </div>
        <!-- /#page-wrapper -->

    </div>

    <?php
        if(isset($_POST['subbtn']))
        {

            $subid=$_POST['subname'];
            $csvenue=$_POST['csvenue'];
            $cscode=$_POST['cscode'];
            $csday = $_POST['csday'];
            $cstime = $_POST['cstime'];

            $sql6="select class_code from class where not class_code='$cscode'";
            $result6=mysqli_query($con,$sql6);
            $row6=mysqli_fetch_assoc($result6);

            // $sql7="select * from class where sup_id='$idselect' and class_day='$csday' and class_start_time='$csstarttime' and class_end_time='$csendtime' ";

            $sql7="select * from class where class_day='$csday' and class_time='$cstime' and class_venue='$csvenue'";
            $result7=mysqli_query($con,$sql7);

            $sql8="select * from class where sup_id='$sup_id' and class_day='$csday' and class_time='$cstime'";
            $result8=mysqli_query($con,$sql8);

            // for($x=0; $x<mysqli_num_rows($result8) ; $x++)
            // {
            //   $preclasstime[$x]=$row8['class_time'];
            //   list($day[$x], $start[$x], $end[$x]) = split('[,-]', $preclasstime[$x]);

            //   echo "Day: $day[$x], start: $start[$x], end: $end[$x] <br />\n";
            // }
            if(mysqli_num_rows($result7)!=0)
            {
                ?>
                    <script type="text/javascript">
                        swal("Opps!","Class venue was not available at this time", "error")
                    </script>
                    <?php
            }
            else if(mysqli_num_rows($result8)!=0)
            {
                ?>
                    <script type="text/javascript">
                        swal("Opps!","Class was crash with previous time", "error")
                    </script>
                    <?php
            }
                  
            else
            {
                mysqli_query($con,"update class set class_venue='$csvenue', class_time='$cstime',class_day='$csday' where class_id='$ci' ");

            ?>
              <script type="text/javascript">
                  swal({ 
                      title: "Successfull!",
                      text: "Class was update successsfully.Thank you.",
                      type: "success" 
                  }).then(function() {
                        window.location.href = 'CW_class.php';
                  });
              </script>
            <?php
            }

    }

    ?>
    <!-- /#wrapper -->

     <script src="//code.jquery.com/jquery-1.9.1.js"></script>
    <!-- jQuery -->

    <!-- Bootstrap Core JavaScript -->
    <script src="../source/js/bootstrap.min.js"></script>
    <script src="//ajax.aspnetcdn.com/ajax/jquery.validate/1.9/jquery.validate.min.js"></script>
    <script type="text/javascript">


$(document).ready(function () 
{
		$(".logout").click(function(){		
		swal({
			title: 'Logout',
			text: "Logout from Postgraduate Management System",
			type: 'warning',
			showCancelButton: true,
			confirmButtonColor: '#3085d6',
			cancelButtonColor: '#d33',
			confirmButtonText: 'Yes'
		}).then(function () {
				window.location.href ="../logout.php";
		})			
	});
	
	
	
	jQuery.validator.addMethod('subname1', function (value) {
        return (value !='empty');
    }, "Please choose a subject.");

    jQuery.validator.addMethod('csvenue1', function (value) {
        return (value !='empty');
    }, "Please choose a venue.");

    jQuery.validator.addMethod('csday1', function (value) {
        return (value !='empty');
    }, "Please choose a day.");

    jQuery.validator.addMethod('cscode1', function (value, element) {
        return this.optional(element) || (value.match(/([A-Z]{3})+(\d{4}$)/));
    }, 'Please enter the correct format of class code. Exp: TSN0001');

    jQuery.validator.addMethod('cstime1', function (value) {
        return (value !='empty');
    }, "Please choose a time slot.");


    $('#form1').validate(
    { // initialize the plugin
        errorPlacement: function (error, element) {
            error.insertAfter(element);
            if (element.hasClass('pw')) {
                element.next().removeClass('passValid').addClass('passError');
            }
        },
        success: function (label) {
            if (label.prev().hasClass('pw')) {
               label.text("Valid!");
            }
        },
        highlight: function (element, errorClass, validClass) {
            if ($(element).hasClass('pw')) {
                $(element).next().removeClass('passValid').addClass('passError');
            } else {
                $(element).addClass(errorClass).removeClass(validClass);
            }
        },
        unhighlight: function (element, errorClass, validClass) {
            if ($(element).hasClass('pw')) {
                $(element).next().removeClass('passError').addClass('passValid');
            } else {
                $(element).removeClass(errorClass).addClass(validClass);
            }
        },
        rules: {
                subname: 
                    {
                        required: true,
                        subname1:true
                    },   
                csvenue:
                    {
                        required: true,
                        csvenue1:true
                    },
                csday:
                    {
                        required: true,
                        csday1:true
                    },
                cstime:
                    {
                        required: true,
                        cstime1:true
                    },    
                cscode: 
                    {
                        required: true,
                        minlength:7,
                        cscode1:true
                    },

                },
                        
        messages:   {
                        subname:"Please select a subject.",
                        csvenue:"Please select a venue.",
                        csday:"Please select a day.",
                        cstime:"Please select a time slot.",
                        cscode: {
                                    required: "Please enter a class code.",
                                    minlength: "Please enter the correct format of class code. Exp: TSN0001"
                                    },
                                
                    },

    });

    
});

</script>
</body>

</html>
