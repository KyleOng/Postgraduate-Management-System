<?php
	include("../dataconnect.php");
	if($_SESSION["loggedins"]!=1)
	{
		echo"<script> window.location.href ='../login.php';</script>";
	}
	session_start();
	$sup_id = $_SESSION["sup_id"];
	$sup_code = $_SESSION["sup_code"];
	
	$sql_sup = "select * from SUPERVISOR SUP, POSITION P, PROGRAMME PROG where 
				SUP.pos_id = P.pos_id and
				SUP.prog_id = PROG.prog_id and
				sup_id='$sup_id'";
	$row_sup = mysqli_fetch_assoc(mysqli_query($con,$sql_sup));
	
?>

<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
	
    <title>General Research Information</title>

    <!-- Bootstrap Core CSS -->
    <link href="../source/css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom CSS -->
    <link href="../source/css/sb-admin.css" rel="stylesheet">

	<!-- Awesome Fonts -->
    <link href="../source/font-awesome-4.7.0/css/font-awesome.min.css" rel="stylesheet" type="text/css">
	
	<!-- Sweet Alert -->
	<script src="../source/sweetalert/dist/sweetalert2.min.js"></script> 
	<link rel="stylesheet" type="text/css" href="../source/sweetalert/dist/sweetalert2.css">
	
	<!-- jQuery -->
    <script src="../source/js/jquery.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="../source/js/bootstrap.min.js"></script>
	
	<!-- Sort Table -->
	<link rel="stylesheet" type="text/css" href="../source/DataTables/datatables.min.css"/>
	<script type="text/javascript" src="../source/DataTables/datatables.min.js"></script>

</head>
<style>
table.dataTable thead th {
  vertical-align: middle;
}
.deco-none {
	color: inherit;
	text-decoration: inherit;
}

.deco-none:link {
	color: inherit;
	text-decoration: inherit;
}

.deco-none:hover {
	color: inherit;
	text-decoration: inherit;
}
</style>
<body>

    <div id="wrapper">

        <!-- Navigation -->
        <nav class="navbar navbar-inverse navbar-fixed-top" role="navigation">
            
			<!-- Left_Header(Display User Type) -->
			<div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-ex1-collapse">
                    <!-- Drop down bar in small screen -->
					<span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>				
				<a class="navbar-brand" href="index.php"><?php echo $row_sup['pos_name']; ?></a>
            </div>	
            
			<!-- Middle_Header(Display User Name and ID) -->
			<div class="top-nav-right">
                <a class="navbar-brand" href="profile.php"><i class="fa fa-user"></i>  <?php echo $row_sup['sup_name']; ?>  <?php echo $row_sup['sup_code']; ?></a>
            </div>	
			
			<!-- Logout -->
            <ul class="nav navbar-right top-nav">
				<li class="dropdown">												
					<a href="#" class="logout"><i class="fa fa-fw fa-power-off"></i> Log Out</a>
                </li>
            </ul>
            
			<!-- Sidebar Menu Items - These collapse to the responsive navigation menu on small screens -->
            <div class="collapse navbar-collapse navbar-ex1-collapse">
                <ul class="nav navbar-nav side-nav">             
                    <!-- Dashboard -->
					<li>
                        <a href="index.php"><i class="glyphicon glyphicon-home"></i>  &nbsp; Dashboard</a>
                    </li>
					
					<!-- Profile -->
                    <li>
                        <a href="javascript:;" data-toggle="collapse" data-target="#list0"><i class="fa fa-fw fa-user"></i>  &nbsp; Profile <i class="fa fa-fw fa-caret-down"></i></a>
                        <ul id="list0" class="collapse">
							<li>
                                <a href="profile.php"> Display Profile</a>
                            </li>                            
							<li>
                                <a href="profile_edit.php"> Edit Profile</a>
                            </li>
							<li>
                                <a href="profile_reset.php"> Reset Password</a>
                            </li>							
							<li>
                                <a href="profile_addfield.php"> Add Field</a>
                            </li>
						</ul>						
                    </li>
					
					<!-- Coursework -->
                    <li id="sidebar_cw">
                        <a href="javascript:;" data-toggle="collapse" data-target="#list1"><i class="glyphicon glyphicon-book"></i>  &nbsp; Coursework <i class="fa fa-fw fa-caret-down"></i></a>
                        <ul id="list1" class="collapse sidebar_cw">
							<li>
                                <a href="CW_class.php" > View Class Info</a>
                            </li>                            
							<li>
                                <a href="CW_addclass.php"> Open New Class</a>
                            </li>
                            <li>
                                <a href="CW_updateresult.php"> Update Student Result</a>
                            </li>
                            <li>
                                <a href="CW_classStuList.php"> Generate Report</a>
                            </li>							
                        </ul>
                    </li>

					<!-- Research -->					
                    <li id="sidebar_res" class="research active">
                        <a href="javascript:;" data-toggle="collapse" data-target="#list2"><i class="glyphicon glyphicon-education"></i>  &nbsp; Research <i class="fa fa-fw fa-caret-down"></i></a>
                        <ul id="list2" class="collapse sidebar_res in">
                            <li>
                                <a href="res_view_status.php" style="color:white;background-color:black;"> General Research Information</a>
                            </li>
                            <li>
                                <a href="res_update.php"> Research Status Update</a>
                            </li>
                            <li>
                                <a href="res_journal.php"> Journal Status Update</a>
                            </li>   
							<li>
                                <a href="res_download.php"> Document Download</a>
                            </li>
                        </ul>
                    </li>
					
					<!-- User guideline -->
                    <li>
                        <a href="userguide.php"><i class="glyphicon glyphicon-question-sign"></i>  &nbsp; User guideline</a>
                    </li>
                </ul>
            </div>
            <!-- /.navbar-collapse -->
        </nav>

        <!-- content inside dashboard -->
		<div id="page-wrapper" style="min-height:400px;">
            <div class="container-fluid">
										
				<!-- Heading-->
				<h2>Postgraduate Research & Journal Status</h2>
				<br>
				
				<!-- Search -->
				<div class="col-md-6 col-lg-6">
					<form class="form-inline">
						<label><strong><span class="glyphicon glyphicon-search"></span> Search : </strong></label>
						<input type="text" id="sortTableSearchBar" class="form-control"></input>	
					</form>
					<br>
				</div>
				<div class="col-md-6 col-lg-6">
					<div class="btn-group btn-group-justified">
						<div class="btn-group">
							<button id="excelBtn" class="btn btn-success"><i class="fa fa-file-excel-o"></i> Excel</button>
						</div>
						<div class="btn-group">
							<button id="pdfBtn" class="btn btn-warning"><i class="fa fa-file-pdf-o"></i> PDF</button>
						</div>
						<div class="btn-group">
							<button id="printBtn" class="btn btn-primary"><i class="glyphicon glyphicon-print"></i> Print</button>
						</div>
					</div>
					<br>
				</div>
				
				<!-- research information -->
				<div class=" col-md-12 col-lg-12 table-responsive"> 
					<table class="table display table-bordered " id="sortTable">
						<thead>
							<tr>
								<th>No</th>
								<th>ID</th>
								<th>Name</th>
								<th>Relationship</th>
								<th>Topic</th>
								<th>Field</th>
								<th>Research Status</th>
								<th>Journal Status</th>
								<th>Journal Title</th>
								<th>Published Date</th>
							</tr>
						</thead>
						<tbody> 
							<?php
								$sql_stud = "select * from RESEARCHSTD RES, STUDENT S, REGISTRATION R, Field F where 
											S.stud_id = RES.stud_id and 
											S.reg_id = R.reg_id and 
											RES.field_id = F.field_id and
											RES.stud_id in ( select DISTINCT(stud_id) FROM researchstd where sup_id = ".$sup_id." or co_sup_id = ".$sup_id.")
											order by (RES.stud_id);";							
											
								
								$result_stud = mysqli_query($con, $sql_stud);
								if (mysqli_num_rows($result_stud) > 0) {
									$i = 1;
									while($row_stud = mysqli_fetch_assoc($result_stud)) {
										if($row_stud['sup_id'] == $row_sup['sup_id'])
										{
											$relation = "main";
										}
										else
										{
											$relation = "co";
										}
										echo "<tr>";
										echo "<td> - </td>";
										echo "<td>".$row_stud['stud_code']."</td>";
										echo "<td>".$row_stud['stud_name']."</td>";
										echo "<td>".$relation."</td>";
										echo "<td>".$row_stud['res_topic']."</td>";
										echo "<td>".$row_stud['field_name']."</td>";
										echo "<td>".$row_stud['res_status']."</td>";
										echo "<td>".$row_stud['jor_status']."</td>";
										echo "<td>".$row_stud['jor_name']."</td>";
										echo "<td>".$row_stud['jor_date']."</td>";
										echo "</tr>";
										$i++;
									}
								}
								else
								{
									echo "<tr>";
									echo "<td> - </td>";
									echo "<td> - </td>";
									echo "<td> - </td>";
									echo "<td> - </td>";
									echo "<td> - </td>";
									echo "<td> - </td>";
									echo "<td> - </td>";
									echo "<td> - </td>";
									echo "<td> - </td>";
									echo "<td> - </td>";
									echo "</tr>";
								}
							?>
						</tbody>
					</table>  
					</br>
				</div>							
			
				<div class="col-md-4 col-lg-4">
					<a class="deco-none" href="res_update.php"><button class="btn btn-block"><span class="glyphicon glyphicon-share"></span> Research Status Update</button></a>
				</div>
				<div class="col-md-4 col-lg-4">
					<a class="deco-none" href="res_journal.php"><button class="btn btn-block"><span class="glyphicon glyphicon-share"></span> Journal Status Update</button></a>
				</div>
				<div class="col-md-4 col-lg-4">
					<a class="deco-none" href="res_download.php"><button class="btn btn-block"><span class="glyphicon glyphicon-share"></span> Document Download</button></a>
				</div>						

			</div>
            <!-- /.container-fluid -->

        </div>
        <!-- /#page-wrapper -->

    </div>
    <!-- /#wrapper -->

</body>

<script>
$(document).ready(function() {
	
	//set table sortable
	var myTable  = $('#sortTable').DataTable( {
		"lengthChange": false,		//disable length of row
		"paging": false,			//disable paging
		"searching": true,			//use own search bar
		"export":true,				//able to export
		"columnDefs": [ {			//1st column
            "searchable": false,
            "orderable": false,
            "targets": 0
        } ],
        "order": [[ 1, 'asc' ]],				
		dom: 'Bfrtip',				//add button group
        buttons: [
            'excel', 'pdf', 'print'
        ]
	} );
	myTable.on( 'order.dt search.dt', function () {
        myTable.column(0, {search:'applied', order:'applied'}).nodes().each( function (cell, i) {
            cell.innerHTML = i+1;
        } );
    } ).draw();
	
	
	//Self search bar
	$('#sortTableSearchBar').keyup(function(){
		  myTable.search($(this).val()).draw() ;
	});
	$('#sortTable_filter').hide();
	
	//Set exeel, pdf, print button link
	$('#excelBtn').click(function () { 
		$('.dt-button.buttons-excel.buttons-html5')[0].click();
	});
	$('.dt-button.buttons-excel.buttons-html5').hide();
	$('#pdfBtn').click(function () { 
		$('.dt-button.buttons-pdf.buttons-html5')[0].click();
	});
	$('.dt-button.buttons-pdf.buttons-html5').hide();
	$('#printBtn').click(function () {
		$('.dt-button.buttons-print')[0].click();
	});
	$('.dt-button.buttons-print').hide();
	
	//Determination of student type
	var stud_type = "<?php echo $_SESSION['stud_type']; ?>";
	if (stud_type == "Coursework")
	{
		$('.research').css({'display': 'none'});
	}
	else if (stud_type == "Research")
	{
		$('.coursework').css({'display': 'none'});
	}
	
	//logout confirmation
	$(".logout").click(function(){		
		swal({
			title: 'Logout',
			text: "Logout from Postgraduate Management System",
			type: 'warning',
			showCancelButton: true,
			confirmButtonColor: '#3085d6',
			cancelButtonColor: '#d33',
			confirmButtonText: 'Yes'
		}).then(function () {
				window.location.href ="../logout.php";
		})			
	});	
});
</script>
</html>
