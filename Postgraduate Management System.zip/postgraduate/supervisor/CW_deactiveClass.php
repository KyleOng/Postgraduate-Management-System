<?php
include("../dataconnect.php");
// if($_SESSION["loggedin"]!=1)
// 		header("Location: login.php");

$ci = $_REQUEST["cid"];

$sql = "update class set class_status='Deactive' where class_id='$ci' ";
mysqli_query($con, $sql);

header("Location: CW_class.php");

?>