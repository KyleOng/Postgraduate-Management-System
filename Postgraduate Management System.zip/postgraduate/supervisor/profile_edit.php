<?php
	include("../dataconnect.php");
	if($_SESSION["loggedins"]!=1)
	{
		echo"<script> window.location.href ='../login.php';</script>";
	}
	session_start();
	$sup_id = $_SESSION["sup_id"];
	$sup_code = $_SESSION["sup_code"];
	
	$sql_sup = "select * from SUPERVISOR where sup_id='$sup_id'";
	$row_sup = mysqli_fetch_assoc(mysqli_query($con,$sql_sup));
	
	$sup_prog_id = $row_sup['prog_id'];
	$sql_prog = "select * from PROGRAMME where prog_id='$sup_prog_id'";
	$row_prog = mysqli_fetch_assoc(mysqli_query($con,$sql_prog));
	$sup_prog_name = $row_prog['prog_name'];
	
	$sup_pos_id = $row_sup['pos_id'];
	$sql_pos = "select * from POSITION where pos_id='$sup_pos_id'";
	$row_pos = mysqli_fetch_assoc(mysqli_query($con,$sql_pos));
	$sup_pos_name = $row_pos['pos_name'];
?>

<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
	
    <title>Supervisor Profile</title>

    <!-- Bootstrap Core CSS -->
    <link href="../source/css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom CSS -->
    <link href="../source/css/sb-admin.css" rel="stylesheet">

	<!-- Awesome Fonts -->
    <link href="../source/font-awesome-4.7.0/css/font-awesome.min.css" rel="stylesheet" type="text/css">
	
	<!-- Sweet Alert -->
	<script src="../source/sweetalert/dist/sweetalert2.min.js"></script> 
	<link rel="stylesheet" type="text/css" href="../source/sweetalert/dist/sweetalert2.css">
	
	<!-- jQuery -->
    <script src="../source/js/jquery.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="../source/js/bootstrap.min.js"></script>
	
	<!-- Country -->
	<script type= "text/javascript" src = "../source/js/country2.js"></script>

</head>
<style>
@media (min-width: 768px) {
	.equal {
		display: flex;
		flex-wrap: wrap;
	}
	  
	.pic {
		padding-top: 18px;
	}
}

.table-user-information > tbody > tr {
    border-top: 1px solid rgb(221, 221, 221);
}

.table-user-information > tbody > tr:first-child {
    border-top: 0;
}

.table-user-information > tbody > tr > td {
    border-top: 0;
}

.panel-border {
    border-color: #000000;
}

.panel-footer {
    padding: 30px 15px;
    background-color: #f5f5f5;
    border-top: 1px solid #ddd;
    border-bottom-right-radius: 3px;
    border-bottom-left-radius: 3px;
}

</style>
<body>

    <div id="wrapper">

        <!-- Navigation -->
        <nav class="navbar navbar-inverse navbar-fixed-top" role="navigation">
            
			<!-- Left_Header(Display User Type) -->
			<div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-ex1-collapse">
                    <!-- Drop down bar in small screen -->
					<span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>				
				<a class="navbar-brand" href="index.php"><?php echo $sup_pos_name; ?></a>
            </div>		
            
			<!-- Middle_Header(Display User Name and ID) -->
			<div class="top-nav-right">
                <a class="navbar-brand" href="profile.php"><i class="fa fa-user"></i>  <?php echo $row_sup['sup_name']; ?>  <?php echo $row_sup['sup_code']; ?></a>
            </div>	
			
			<!-- Logout -->
            <ul class="nav navbar-right top-nav">
				<li class="dropdown">												
					<a href="#" class="logout"><i class="fa fa-fw fa-power-off"></i> Log Out</a>
                </li>
            </ul>
            
			<!-- Sidebar Menu Items - These collapse to the responsive navigation menu on small screens -->
            <div class="collapse navbar-collapse navbar-ex1-collapse">
                <ul class="nav navbar-nav side-nav">             
                    <!-- Dashboard -->
					<li>
                        <a href="index.php"><i class="glyphicon glyphicon-home"></i>  &nbsp; Dashboard</a>
                    </li>
					
					<!-- Profile -->
                    <li class="active">
                        <a href="javascript:;" data-toggle="collapse" data-target="#list0"><i class="fa fa-fw fa-user"></i>  &nbsp; Profile <i class="fa fa-fw fa-caret-down"></i></a>
                        <ul id="list0" class="collapse in">
							<li>
                                <a href="profile.php"> Display Profile</a>
                            </li>                            
							<li>
                                <a href="profile_edit.php" style="color:white;background-color:black;"> Edit Profile</a>
                            </li>
							<li>
                                <a href="profile_reset.php"> Reset Password</a>
                            </li>	
							<li>
                                <a href="profile_addfield.php"> Add Field</a>
                            </li>							
                        </ul>						
                    </li>
					
					<!-- Coursework -->
                    <li id="sidebar_cw">
                        <a href="javascript:;" data-toggle="collapse" data-target="#list1"><i class="glyphicon glyphicon-book"></i>  &nbsp; Coursework <i class="fa fa-fw fa-caret-down"></i></a>
                        <ul id="list1" class="collapse sidebar_cw">
							<li>
                                <a href="CW_class.php" > View Class Info</a>
                            </li>                            
							<li>
                                <a href="CW_addclass.php"> Open New Class</a>
                            </li>
                            <li>
                                <a href="CW_updateresult.php"> Update Student Result</a>
                            </li>
                            <li>
                                <a href="CW_classStuList.php"> Generate Report</a>
                            </li>							
                        </ul>
                    </li>

					<!-- Research -->					
                    <li id="sidebar_res">
                        <a href="javascript:;" data-toggle="collapse" data-target="#list2"><i class="glyphicon glyphicon-education"></i>  &nbsp; Research <i class="fa fa-fw fa-caret-down"></i></a>
                        <ul id="list2" class="collapse sidebar_res">
                            <li>
                                <a href="res_view_status.php"> View Research Status</a>
                            </li>
                            <li>
                                <a href="res_update.php"> Update Status & Journal</a>
                            </li>
                            <li>
                                <a href="res_journal.php"> Update Journal Status</a>
                            </li> 
                            <li>
                                <a href="res_download.php"> Download Document</a>
                            </li>
                        </ul>
                    </li>
					
					<!-- User guideline -->
                    <li>
                        <a href="userguide.php"><i class="glyphicon glyphicon-question-sign"></i>  &nbsp; User guideline</a>
                    </li>
                </ul>
            </div>
            <!-- /.navbar-collapse -->
        </nav>

        <!-- content inside dashboard -->
		<div id="page-wrapper" style="min-height:400px;">
            <div class="container-fluid">
				
				<!-- Heading -->
				<h2>Profile Edit</h2>				
				
				<div class="col-md-3 col-lg-3" align="center">
					<div class="panel panel-default">
						<div class="panel-body">						
								
							<!-- user profile pic -->
							<form class="form-horizontal" id="form111" role="form" method ="post" action="" enctype="multipart/form-data">
								<?php 											
									if($row_sup['Profile_Picture']=="" || $row_sup['Profile_Ext']==".")
									{
									?>
										<img alt="User Pic" src="../source/picture/user/defaultuser.jpg" class="img-rounded img-responsive pic">
										<input class='form-control' type='file' name='image' required>						
									<?php
									}
									else
									{
										echo "<img alt='User Pic' src='../source/picture/user/".$row_sup['Profile_Picture'].$row_sup['Profile_Ext']."' class='img-rounded img-responsive pic' >
											  <input class='form-control' type='file' name='image' required>";
									}
								?> 
								</br>
								<button type="submit" class="btn btn-default btn-block" style="background-color: #e4e4e4;" name='Submit'><i class="fa fa-upload"> Upload Image</i></button>
							</form>																		
						</div>
					</div>
				</div>

				<div class="col-md-9 col-lg-9">
					<div class="panel panel-default">
						<div class="panel-body">					
							
							<form method="post">
								<!-- user information -->
									<table class="table table-user-information">
										<tbody>
											<tr>
												<td>Supervisor ID </td>
												<td><input type="text" class="form-control" value="<?php echo $_SESSION['sup_code'];?>" disabled></td>
											</tr>									
											<tr>
												<td>Name </td>
												<td><input type="text" class="form-control" value="<?php echo $row_sup['sup_name'];?>" disabled></td>
											</tr>										  
											<tr>
												<td>IC </td>
												<td><input type="text" class="form-control" value="<?php echo $row_sup['sup_IC'];?>" disabled></td>
											</tr>
											<tr>
												<td>Email</td>
												<td><input type="text" class="form-control" value="<?php echo $row_sup['sup_email'];?>" disabled></td>
											</tr>
											<tr>
												<td>Contact Number</td>
												<td><input type="text" class="form-control" name="sup_contact" value="<?php echo $row_sup['sup_contact'];?>" pattern=".{10,11}"></td>
											</tr>
											<tr>
												<td>Gender</td>
												<td><input type="text" class="form-control" value="<?php echo $row_sup['sup_gender'];?>" disabled></td>
											</tr>											
											<tr>
												<td>Address</td>
												<td><input type="text" class="form-control" name="sup_address" value="<?php echo $row_sup['sup_address'];?>"></td>
											</tr>
											<tr>
												<td>State</td>
												<td>
													<select class="form-control" id="sup_state" name="sup_state" required>
														<option value="Johor">Johor</option>
														<option value="Kedah">Kedah</option>
														<option value="Kelantan">Kelantan</option>
														<option value="Melaka">Melaka</option>
														<option value="Negeri Sembilan">Negeri Sembilan</option>
														<option value="Pahang">Pahang</option>
														<option value="Perak">Perak</option>
														<option value="Perlis">Perlis</option>
														<option value="Pulau Pinang">Pulau Pinang</option>
														<option value="Sabah">Sabah</option>
														<option value="Sarawak">Sarawak</option>
														<option value="Selangor">Selangor</option>
														<option value="Terrenganu">Terrenganu</option>
													</select>
												</td>
											</tr>
											<tr>
												<td>Postcode</td>
												<td><input type="text" class="form-control" name="sup_postcode" value="<?php echo $row_sup['sup_postcode'];?>" pattern=".{5}"></td>
											</tr>
											<tr>
												<td>Progamme</td>
												<td><input type="text" class="form-control" value="<?php echo $row_prog['prog_name'];?>" disabled></td>
											</tr>
											<tr>
												<td>Position</td>
												<td><input type="text" class="form-control" value="<?php echo $row_pos['pos_name'];?>" disabled></td>
											</tr>
											<tr>
												<td>Student Amount</td>
												<td><input type="text" class="form-control" value="<?php echo $row_sup['stud_amount'];?>" disabled></td>
											</tr>
											<tr>
												<td>Status</td>
												<td><input type="text" class="form-control" value="<?php echo $row_sup['sup_status'];?>" disabled></td>
											</tr>
											<tr>
												<td>Consult Day</td>
												<td>
													<select class="form-control" id="sup_consultday" name="sup_consultday" required>
														<option value="Monday">Monday</option>
														<option value="Tuesday">Tuesday</option>
														<option value="Wednesday">Wednesday</option>
														<option value="Thursday">Thursday</option>
														<option value="Friday">Friday</option>
														<option value="Saturday">Saturday</option>
													</select>
												</td>
											</tr>
											<tr>
												<td>Consult Time</td>
												<td>
													<select class="form-control" id="sup_consulttime" name="sup_consulttime" required>
														<option value="9:00am-11:00am">9:00am-11:00am</option>
														<option value="10:00am-12:00pm">10:00am-12:00pm</option>
														<option value="11:00pm-1:00pm">11:00pm-1:00pm</option>
														<option value="2:00pm-4:00pm">2:00pm-4:00pm</option>
														<option value="3:00pm-5:00pm">3:00pm-5:00pm</option>
														<option value="4:00pm-6:00pm">4:00pm-6:00pm</option>
													</select>
												</td>
											</tr>											
										</tbody>
									</table>     		
								
								<button type="submit" class="btn btn-block" id="btnSubmit" name="btnSubmit"><i class="glyphicon glyphicon-edit"></i> Submit</button>
							</form>
						</div>
					</div>
				</div>
			</div>
            <!-- /.container-fluid -->

        </div>
        <!-- /#page-wrapper -->

    </div>
    <!-- /#wrapper -->

</body>

    <script>
	$(document).ready(function() {
		
		//logout confirmation
		$(".logout").click(function(){		
			swal({
				title: 'Logout',
				text: "Logout from Postgraduate Management System",
				type: 'warning',
				showCancelButton: true,
				confirmButtonColor: '#3085d6',
				cancelButtonColor: '#d33',
				confirmButtonText: 'Yes'
			}).then(function () {
					window.location.href ="../logout.php";
			})			
		});
	});
	</script>

</html>

<!-- profile picture code -->
<?php
	//define a maxim size for the uploaded images in Kb
	define ("MAX_SIZE","8000"); 
	//This function reads the extension of the file. It is used to determine if the
	// file  is an image by checking the extension.
	 function getExtension($str) {
			 $i = strrpos($str,".");
			 if (!$i) { return ""; }
			 $l = strlen($str) - $i;
			 $ext = substr($str,$i+1,$l);
			 return $ext;
	 }

	//This variable is used as a flag. The value is initialized with 0 (meaning no 
	// error  found)  
	//and it will be changed to 1 if an errro occures.  
	//If the error occures the file will not be uploaded.
	$errors=0;
	//checks if the form has been submitted
	if(isset($_POST['Submit'])) 
	{
		//reads the name of the file the user submitted for uploading
		$image=$_FILES['image']['name'];
		//if it is not empty
		if ($image) 
		{
		//get the original name of the file from the clients machine
			$filename = stripslashes($_FILES['image']['name']);
		//get the extension of the file in a lower case format
			$extension = getExtension($filename);
			$extension = strtolower($extension);
		//if it is not a known extension, we will suppose it is an error and 
		// will not  upload the file,  
		//otherwise we will do more tests
			if (($extension != "jpg") && ($extension != "jpeg") && ($extension !="png") && ($extension != "gif")) 
			{
			//print error message
				echo '<h1>Unknown extension!</h1>';
				$errors=1;
			}
			else
			{
				//get the size of the image in bytes
				 //$_FILES['image']['tmp_name'] is the temporary filename of the file
				 //in which the uploaded file was stored on the server
				 $size=filesize($_FILES['image']['tmp_name']);

				//compare the size with the maxim size we defined and print error if bigger
				if ($size > MAX_SIZE*1024)
				{
					echo '<h1>You have exceeded the size limit!</h1>';
					$errors=1;
				}

				//we will give an unique name, for example the time in unix time format
				$image_name=$row_sup['sup_code'].'.'.$extension;
				//the new name will be containing the full path where will be stored (images folder)
				$newname="../source/picture/user/".$image_name;
				//we verify if the image has been uploaded, and print error instead
				$copied = copy($_FILES['image']['tmp_name'], $newname);
				if (!$copied) 
				{
					echo '<h1>Copy unsuccessfull!</h1>';
					$errors=1;
				}
			}
		}
	}
	
	//If no errors registred, print the success message
	 if(isset($_POST['Submit']) && !$errors) 
	 {
		echo "<h1>File Uploaded Successfully! </h1>";
		
		$sql2="update supervisor set Profile_Picture='".$row_sup['sup_code']."',Profile_Ext='.$extension' where sup_id=$sup_id";
		mysqli_query($con,$sql2);
		header("Location: profile_edit.php");
		mysqli_close($con);
	 }
			
?>

<!-- form edit -->
<?php
if(isset($_POST['btnSubmit']))
{
	
	$sup_contact=$_POST['sup_contact'];
	$sup_address=$_POST['sup_address'];
	$sup_state=$_POST['sup_state'];
	$sup_postcode=$_POST['sup_postcode'];
	$sup_consultday=$_POST['sup_consultday'];
	$sup_consulttime=$_POST['sup_consulttime'];
	
	$sql1 = "UPDATE SUPERVISOR SET 
			sup_contact = '$sup_contact', 
			sup_address = '$sup_address', 
			sup_state = '$sup_state',
			sup_postcode = '$sup_postcode',
			sup_consultday = '$sup_consultday',
			sup_consulttime = '$sup_consulttime' 
			where sup_id = '".$row_sup['sup_id']."'";
	
	
	if (mysqli_query($con, $sql1)) {
		?>
		<script>
				swal({
					title: "Successfull!",
					text: "Profile Edit Successful!",
					type: "success" 
				}).then(function() {				
					window.location.href ="profile_edit.php";
				});
		</script>
	<?php
	}
	else{
		?>
		<script type="text/javascript">
			alert("failed");
		</script>
	<?php		
	}
	//header('Location: profile_edit.php');
}
?>