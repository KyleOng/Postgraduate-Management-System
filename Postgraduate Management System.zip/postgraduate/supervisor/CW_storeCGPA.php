<?php
	include("../dataconnect.php");
	session_start();


	$sql2="select SUM(enrollment.class_gpa*subject.subject_credit_hr) AS totgpa,enrollment.stud_id as studentid,SUM(subject.subject_credit_hr) as totcredit, coursework.cs_total_credit_hr AS cstotcredithr from enrollment 
		INNER JOIN class ON enrollment.class_id=class.class_id 
		INNER JOIN subject ON class.subject_id=subject.subject_id
        INNER JOIN coursework ON subject.prog_id=coursework.prog_id
			where enrollment.enrollment_status='End' GROUP BY enrollment.stud_id  ";
    $result2=mysqli_query($con,$sql2);

	while($row2=mysqli_fetch_assoc($result2)) 
	{
		$tot_gpa=$row2['totgpa'];
		$studid=$row2['studentid'];
		$totcredit=$row2['totcredit'];
		$cstotcredit=$row2['cstotcredithr'];
		$cgpa=$tot_gpa/$totcredit;

		mysqli_query($con,"UPDATE courseworkstd SET cw_cgpa='$cgpa',cw_credit_hr='$totcredit' where stud_id='$studid' ");

		if($cstotcredit==$totcredit)
		{
			mysqli_query($con,"UPDATE student SET stud_status='Complete' where stud_id='$studid' ");
		}
		echo '$cgpa';
	}
	
	echo "<script>window.location.href ='CW_classStuList.php';</script>";
?>