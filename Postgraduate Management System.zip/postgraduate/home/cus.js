$(document).ready(function(){
	
	var scrolllink=$('.button');
	
	scrolllink.click(function(e){
		e.preventDefault();
		$('body,html').animate({
			scrollTop:$(this.hash).offset().top - 70
		},1000);
	});
});

