<!DOCTYPE html>
<html lang="en">
	<head>
		<meta charset="utf-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<title>Home</title>
		
		
		<link rel="stylesheet" href="home2.css"/>
	</head>
	
	<body>
		<header class="header">
		<img src="PMSblack.png" alt="PMS logo" class="logo">
			<nav class="nav">
			<ul>
				<li><a href="home.php">Home</a></li>
				<li id="active"><a href="#">Programme</a></li>
				</li>
				<li><a href="requirement.php">Requirements</a></li>
				<li><a href="download.php">Download</a></li>
				<li><a href="../login.php">Login</a></li>	
			</ul>
			</nav>
	</header>
		
	<section id="programme">
		<div class="container">
				<div class="slidebutton">
					<ul>
						<li><a href="#eng" class="button button-home2 button-small" >Engineering</a></li>
						<li><a href="#it" class="button button-home2 button-small" >Information Technology</a></li>
						<li><a href="#cm" class="button button-home2 button-small" >Creative Multimedia</a></li>
						<li><a href="#bm" class="button button-home2 button-small" >Business Management</a></li>
					</ul>
				</div>
		</div>
	</section>
	
		<section id="programme">
		<div class="container">
		
		<!----------------             ENGINEERING          ------------------->

				<h1 id="eng">Engineering</h1>
				<p>Graduate Institute of Engineering</p>
				<table border="1" cellpadding="1" cellspacing="1" style="width:555px">
					<thead>
						<tr>
							<th rowspan="2" scope="col" style="text-align:center; vertical-align:middle; width:30px">No</th>
							<th rowspan="2" scope="col" style="text-align:center; vertical-align:middle; width:160px">Programme</th>
							<th colspan="3" scope="col" style="width:90px">Structure</th>
							<th colspan="2" scope="col" style="width:100px">Mode Of Study</th>
							<th rowspan="2" scope="col" style="width:70px">Cyberjaya Campus</th>
							<th rowspan="2" scope="col" style="width:70px">Melaka Campus</th>
							<th rowspan="2" scope="col" style="width:50px">PSDC*</th>
						</tr>
						<tr>
							<th scope="col" style="text-align:center; vertical-align:middle; width:25px">A</th>
							<th scope="col" style="text-align:center; vertical-align:middle; width:25px">B</th>
							<th scope="col" style="text-align:center; vertical-align:middle; width:25px">C</th>
							<th scope="col" style="width:50px">Full Time</th>
							<th scope="col" style="width:50px">Part Time</th>
						</tr>
					</thead>
					<tbody>
						<tr>
							<td style="text-align:center; vertical-align:middle">1</td>
							<td>Master of Engineering (Telecommunications) <em>[M.Eng. (Telecommunications)]</em></td>
							<td style="text-align:center; vertical-align:middle">&nbsp;</td>
							<td style="text-align:center; vertical-align:middle">&nbsp;</td>
							<td style="text-align:center; vertical-align:middle"><img src="images/blue_tick.png" /></td>
							<td style="text-align:center; vertical-align:middle"><img src="images/green_tick.png" /></td>
							<td style="text-align:center; vertical-align:middle"><img src="images/red_tick.png" /></td>
							<td style="text-align:center; vertical-align:middle"><img src="images/blue_tick.png" /></td>
							<td style="text-align:center; vertical-align:middle">&nbsp;</td>
							<td style="text-align:center; vertical-align:middle"><img src="images/blue_tick.png" /></td>
						</tr>
					<tr>
							<td style="text-align:center; vertical-align:middle">2</td>
							<td>Master of Electrical and Electronic Engineering</td>
							<td style="text-align:center; vertical-align:middle">&nbsp;</td>
							<td style="text-align:center; vertical-align:middle">&nbsp;</td>
							<td style="text-align:center; vertical-align:middle"><img src="images/blue_tick.png" /></td>
							<td style="text-align:center; vertical-align:middle"><img src="images/blue_tick.png" /></td>
							<td style="text-align:center; vertical-align:middle"><img src="images/blue_tick.png" /></td>
							<td style="text-align:center; vertical-align:middle"><img src="images/blue_tick.png" /></td>
							<td style="text-align:center; vertical-align:middle">&nbsp;</td>
							<td style="text-align:center; vertical-align:middle">
							<p>&nbsp;</p>
							</td>
						</tr>
						<tr>
							<td style="text-align:center; vertical-align:middle">3</td>
							<td>Master of Science in Sustainable Systems Management [M. Sc. (SSM)]</td>
							<td style="text-align:center; vertical-align:middle">&nbsp;</td>
							<td style="text-align:center; vertical-align:middle">&nbsp;</td>
							<td style="text-align:center; vertical-align:middle"><img src="images/blue_tick.png" /></td>
							<td style="text-align:center; vertical-align:middle"><img src="images/blue_tick.png" /></td>
							<td style="text-align:center; vertical-align:middle"><img src="images/blue_tick.png" /></td>
							<td style="text-align:center; vertical-align:middle"><img src="images/blue_tick.png" /></td>
							<td style="text-align:center; vertical-align:middle">&nbsp;</td>
							<td style="text-align:center; vertical-align:middle">&nbsp;</td>
						</tr>
						<tr>
							<td style="text-align:center; vertical-align:middle">4</td>
							<td>Master of Science in Engineering Business Management [M.Sc (EBM)]</td>
							<td style="text-align:center; vertical-align:middle">&nbsp;</td>
							<td style="text-align:center; vertical-align:middle">&nbsp;</td>
							<td style="text-align:center; vertical-align:middle"><img src="images/blue_tick.png" /></td>
							<td style="text-align:center; vertical-align:middle"><img src="images/blue_tick.png" /></td>
							<td style="text-align:center; vertical-align:middle"><img src="images/blue_tick.png" /></td>
							<td style="text-align:center; vertical-align:middle"><img src="images/blue_tick.png" /></td>
							<td style="text-align:center; vertical-align:middle">&nbsp;</td>
							<td style="text-align:center; vertical-align:middle">&nbsp;</td>
						</tr>
				</table>
				
				<p>Faculty of Engineering and Technology</p>
				<table border="1" cellpadding="1" cellspacing="1" style="width:555px">
					<thead>
						<tr>
							<th rowspan="2" scope="col" style="text-align:center; vertical-align:middle; width:30px">No</th>
							<th rowspan="2" scope="col" style="text-align:center; vertical-align:middle; width:160px">Programme</th>
							<th colspan="3" scope="col" style="width:90px">Structure</th>
							<th colspan="2" scope="col" style="width:100px">Mode Of Study</th>
							<th rowspan="2" scope="col" style="width:70px">Cyberjaya Campus</th>
							<th rowspan="2" scope="col" style="width:70px">Melaka Campus</th>
							<th rowspan="2" scope="col" style="width:50px">PSDC*</th>
						</tr>
						<tr>
							<th scope="col" style="text-align:center; vertical-align:middle; width:25px">A</th>
							<th scope="col" style="text-align:center; vertical-align:middle; width:25px">B</th>
							<th scope="col" style="text-align:center; vertical-align:middle; width:25px">C</th>
							<th scope="col" style="width:50px">Full Time</th>
							<th scope="col" style="width:50px">Part Time</th>
						</tr>
					</thead>
					<tbody>
						<tr>
							<td style="text-align:center; vertical-align:middle">1</td>
							<td>Master of Engineering in Embedded System <em>[M.Eng. (Embedded System)]</em></td>
							<td style="text-align:center; vertical-align:middle">&nbsp;</td>
							<td style="text-align:center; vertical-align:middle">&nbsp;</td>
							<td style="text-align:center; vertical-align:middle"><img src="images/blue_tick.png" /></td>
							<td style="text-align:center; vertical-align:middle"><img src="images/blue_tick.png" /></td>
							<td style="text-align:center; vertical-align:middle"><img src="images/blue_tick.png" /></td>
							<td style="text-align:center; vertical-align:middle">&nbsp;</td>
							<td style="text-align:center; vertical-align:middle"><img src="images/blue_tick.png" /></td>
							<td style="text-align:center; vertical-align:middle">&nbsp;</td>
						</tr>
						<tr>
							<td style="text-align:center; vertical-align:middle">2</td>
							<td>Master of Engineering in Advanced Manufacturing Management <em>[M.Eng. (Adv. Manufacturing Mgmt.)]</em></td>
							<td style="text-align:center; vertical-align:middle">&nbsp;</td>
							<td style="text-align:center; vertical-align:middle">&nbsp;</td>
							<td style="text-align:center; vertical-align:middle"><img src="images/blue_tick.png" /></td>
							<td style="text-align:center; vertical-align:middle"><img src="images/blue_tick.png" /></td>
							<td style="text-align:center; vertical-align:middle"><img src="images/blue_tick.png" /></td>
							<td style="text-align:center; vertical-align:middle">&nbsp;</td>
							<td style="text-align:center; vertical-align:middle"><img src="images/blue_tick.png" /></td>
							<td style="text-align:center; vertical-align:middle">&nbsp;</td>
						</tr>
					</tbody>
				</table>
		</div>
	</section>
	
	<!----------------             Information Technologies          ------------------->
	<h1 id="it">Information Technologies</h1>
	<p>Faculty of Computing and Informatics</p>
				<table border="1" cellpadding="1" cellspacing="1" style="width:555px">
				<thead>
					<tr>
						<th rowspan="2" scope="col" style="text-align:center; vertical-align:middle; width:30px">No</th>
						<th rowspan="2" scope="col" style="text-align:center; vertical-align:middle; width:160px">Programme</th>
						<th colspan="3" scope="col" style="width:90px">Structure</th>
						<th colspan="2" scope="col" style="width:100px">Mode Of Study</th>
						<th rowspan="2" scope="col" style="width:70px">Cyberjaya Campus</th>
						<th rowspan="2" scope="col" style="width:70px">Melaka Campus</th>
						<th rowspan="2" scope="col" style="width:50px">PSDC*</th>
					</tr>
					<tr>
						<th scope="col" style="text-align:center; vertical-align:middle; width:25px">A</th>
						<th scope="col" style="text-align:center; vertical-align:middle; width:25px">B</th>
						<th scope="col" style="text-align:center; vertical-align:middle; width:25px">C</th>
						<th scope="col" style="width:50px">Full Time</th>
						<th scope="col" style="width:50px">Part Time</th>
					</tr>
				</thead>
				<tbody>
					<tr>
						<td style="text-align:center; vertical-align:middle">1</td>
						<td>Master of Computer Science in Software Engineering and Software Architecture [M.Comp.Sc.(SESA)]</td>
						<td style="text-align:center; vertical-align:middle">&nbsp;</td>
						<td style="text-align:center; vertical-align:middle">&nbsp;</td>
						<td style="text-align:center; vertical-align:middle"><img src="images/blue_tick.png" /></td>
						<td style="text-align:center; vertical-align:middle"><img src="images/blue_tick.png" /></td>
						<td style="text-align:center; vertical-align:middle">&nbsp;</td>
						<td style="text-align:center; vertical-align:middle"><img src="images/blue_tick.png" /></td>
						<td style="text-align:center; vertical-align:middle">&nbsp;</td>
						<td style="text-align:center; vertical-align:middle">&nbsp;</td>
					</tr>
				</tbody>
			</table>
			
	<!----------------             Creative Multimedia          ------------------->
	<h1 id="cm">Creative Multimedia</h1>
	<p>Faculty of Creative Multimedia</p>
			<table border="1" cellpadding="1" cellspacing="1" style="width:555px">
			<thead>
				<tr>
					<th rowspan="2" scope="col" style="text-align:center; vertical-align:middle; width:30px">No</th>
					<th rowspan="2" scope="col" style="text-align:center; vertical-align:middle; width:160px">Programme</th>
					<th colspan="3" scope="col" style="width:90px">Structure</th>
					<th colspan="2" scope="col" style="width:100px">Mode Of Study</th>
					<th rowspan="2" scope="col" style="width:70px">Cyberjaya Campus</th>
					<th rowspan="2" scope="col" style="width:70px">Melaka Campus</th>
					<th rowspan="2" scope="col" style="width:50px">PSDC*</th>
				</tr>
				<tr>
					<th scope="col" style="text-align:center; vertical-align:middle; width:25px">A</th>
					<th scope="col" style="text-align:center; vertical-align:middle; width:25px">B</th>
					<th scope="col" style="text-align:center; vertical-align:middle; width:25px">C</th>
					<th scope="col" style="width:50px">Full Time</th>
					<th scope="col" style="width:50px">Part Time</th>
				</tr>
			</thead>
			<tbody>
				<tr>
					<td style="text-align:center; vertical-align:middle">1</td>
					<td>Master of Knowledge Management with Multimedia <em>[</em>M.K.M with MM.<em>]</em></td>
					<td style="text-align:center; vertical-align:middle">&nbsp;</td>
					<td style="text-align:center; vertical-align:middle">&nbsp;</td>
					<td style="text-align:center; vertical-align:middle"><img src="images/blue_tick.png" /></td>
					<td style="text-align:center; vertical-align:middle"><img src="images/blue_tick.png" /></td>
					<td style="text-align:center; vertical-align:middle">&nbsp;</td>
					<td style="text-align:center; vertical-align:middle"><img src="images/blue_tick.png" /></td>
					<td style="text-align:center; vertical-align:middle">&nbsp;</td>
					<td style="text-align:center; vertical-align:middle">&nbsp;</td>
				</tr>
				<tr>
					<td style="text-align:center; vertical-align:middle">2</td>
					<td>Master of Multimedia (E-learning Technologies) <em>[</em>M.MM. (e-Learning Tech.)<em>]</em></td>
					<td style="text-align:center; vertical-align:middle">&nbsp;</td>
					<td style="text-align:center; vertical-align:middle">&nbsp;</td>
					<td style="text-align:center; vertical-align:middle"><img src="images/blue_tick.png" /></td>
					<td style="text-align:center; vertical-align:middle"><img src="images/blue_tick.png" /></td>
					<td style="text-align:center; vertical-align:middle">&nbsp;</td>
					<td style="text-align:center; vertical-align:middle"><img src="images/blue_tick.png" /></td>
					<td style="text-align:center; vertical-align:middle">&nbsp;</td>
					<td style="text-align:center; vertical-align:middle">&nbsp;</td>
				</tr>
			</tbody>
		</table>

	<!----------------             Business and Mangement          ------------------->
	<h1 id="bm">Business Management</h1>
	<p>Faculty of Management</p>
		<table border="1" cellpadding="1" cellspacing="1" style="width:555px">
		<thead>
			<tr>
				<th rowspan="2" scope="col" style="text-align:center; vertical-align:middle; width:30px">No</th>
				<th rowspan="2" scope="col" style="text-align:center; vertical-align:middle; width:160px">Programme</th>
				<th colspan="3" scope="col" style="width:90px">Structure</th>
				<th colspan="2" scope="col" style="width:100px">Mode Of Study</th>
				<th rowspan="2" scope="col" style="width:70px">Cyberjaya Campus</th>
				<th rowspan="2" scope="col" style="width:70px">Melaka Campus</th>
				<th rowspan="2" scope="col" style="width:50px">PSDC*</th>
			</tr>
			<tr>
				<th scope="col" style="text-align:center; vertical-align:middle; width:25px">A</th>
				<th scope="col" style="text-align:center; vertical-align:middle; width:25px">B</th>
				<th scope="col" style="text-align:center; vertical-align:middle; width:25px">C</th>
				<th scope="col" style="width:50px">Full Time</th>
				<th scope="col" style="width:50px">Part Time</th>
			</tr>
		</thead>
		<tbody>
			<tr>
				<td style="text-align:center; vertical-align:middle">1</td>
				<td>Master of Philosophy<em> (M.Phil.)</em></td>
				<td style="text-align:center; vertical-align:middle"><img src="images/blue_tick.png" /></td>
				<td style="text-align:center; vertical-align:middle">&nbsp;</td>
				<td style="text-align:center; vertical-align:middle">&nbsp;</td>
				<td style="text-align:center; vertical-align:middle"><img src="images/blue_tick.png" /></td>
				<td style="text-align:center; vertical-align:middle"><img src="images/blue_tick.png" /></td>
				<td style="text-align:center; vertical-align:middle"><img src="images/blue_tick.png" /></td>
				<td style="text-align:center; vertical-align:middle">&nbsp;</td>
				<td style="text-align:center; vertical-align:middle">&nbsp;</td>
			</tr>
			<tr>
				<td style="text-align:center; vertical-align:middle">2</td>
				<td>Doctor of Philosophy (Management <em>[</em><em>Ph.D. (Management)</em><em>]</em></td>
				<td style="text-align:center; vertical-align:middle"><img src="images/blue_tick.png" /></td>
				<td style="text-align:center; vertical-align:middle">&nbsp;</td>
				<td style="text-align:center; vertical-align:middle">&nbsp;</td>
				<td style="text-align:center; vertical-align:middle"><img src="images/blue_tick.png" /></td>
				<td style="text-align:center; vertical-align:middle"><img src="images/blue_tick.png" /></td>
				<td style="text-align:center; vertical-align:middle"><img src="images/blue_tick.png" /></td>
				<td style="text-align:center; vertical-align:middle">&nbsp;</td>
				<td style="text-align:center; vertical-align:middle">&nbsp;</td>
			</tr>
		</tbody>
	</table>
	
	<p>Graduate School of Management</p>
		<table border="1" cellpadding="1" cellspacing="1" style="width:555px">
		<thead>
			<tr>
				<th rowspan="2" scope="col" style="text-align:center; vertical-align:middle; width:30px">No</th>
				<th rowspan="2" scope="col" style="text-align:center; vertical-align:middle; width:160px">Programme</th>
				<th colspan="3" scope="col" style="width:90px">Structure</th>
				<th colspan="2" scope="col" style="width:100px">Mode Of Study</th>
				<th rowspan="2" scope="col" style="width:70px">Cyberjaya Campus</th>
				<th rowspan="2" scope="col" style="width:70px">Melaka Campus</th>
				<th rowspan="2" scope="col" style="width:50px">PSDC*</th>
			</tr>
			<tr>
				<th scope="col" style="text-align:center; vertical-align:middle; width:25px">A</th>
				<th scope="col" style="text-align:center; vertical-align:middle; width:25px">B</th>
				<th scope="col" style="text-align:center; vertical-align:middle; width:25px">C</th>
				<th scope="col" style="width:50px">Full Time</th>
				<th scope="col" style="width:50px">Part Time</th>
			</tr>
		</thead>
		<tbody>
			<tr>
				<td style="text-align:center; vertical-align:middle">1</td>
				<td>Master of Philosophy<em> (M.Phil.)</em></td>
				<td style="text-align:center; vertical-align:middle"><img src="images/blue_tick.png" /></td>
				<td style="text-align:center; vertical-align:middle">&nbsp;</td>
				<td style="text-align:center; vertical-align:middle">&nbsp;</td>
				<td style="text-align:center; vertical-align:middle"><img src="images/blue_tick.png" /></td>
				<td style="text-align:center; vertical-align:middle"><img src="images/blue_tick.png" /></td>
				<td style="text-align:center; vertical-align:middle"><img src="images/blue_tick.png" /></td>
				<td style="text-align:center; vertical-align:middle">&nbsp;</td>
				<td style="text-align:center; vertical-align:middle">&nbsp;</td>
			</tr>
			<tr>
				<td style="text-align:center; vertical-align:middle">2</td>
				<td>Doctor of Philosophy (Management)<em> [Ph.D. (Management)]</em></td>
				<td style="text-align:center; vertical-align:middle"><img src="images/blue_tick.png" /></td>
				<td style="text-align:center; vertical-align:middle">&nbsp;</td>
				<td style="text-align:center; vertical-align:middle">&nbsp;</td>
				<td style="text-align:center; vertical-align:middle"><img src="images/blue_tick.png" /></td>
				<td style="text-align:center; vertical-align:middle"><img src="images/blue_tick.png" /></td>
				<td style="text-align:center; vertical-align:middle"><img src="images/blue_tick.png" /></td>
				<td style="text-align:center; vertical-align:middle">&nbsp;</td>
				<td style="text-align:center; vertical-align:middle">&nbsp;</td>
			</tr>
		</tbody>
	</table>

	<p>Faculty of Business</p>
	<table border="1" cellpadding="1" cellspacing="1" style="width:555px">
		<thead>
			<tr>
				<th rowspan="2" scope="col" style="text-align:center; vertical-align:middle; width:30px">No</th>
				<th rowspan="2" scope="col" style="text-align:center; vertical-align:middle; width:160px">Programme</th>
				<th colspan="3" scope="col" style="width:90px">Structure</th>
				<th colspan="2" scope="col" style="width:100px">Mode Of Study</th>
				<th rowspan="2" scope="col" style="width:70px">Cyberjaya Campus</th>
				<th rowspan="2" scope="col" style="width:70px">Melaka Campus</th>
				<th rowspan="2" scope="col" style="width:50px">PSDC*</th>
			</tr>
			<tr>
				<th scope="col" style="text-align:center; vertical-align:middle; width:25px">A</th>
				<th scope="col" style="text-align:center; vertical-align:middle; width:25px">B</th>
				<th scope="col" style="text-align:center; vertical-align:middle; width:25px">C</th>
				<th scope="col" style="width:50px">Full Time</th>
				<th scope="col" style="width:50px">Part Time</th>
			</tr>
		</thead>
		<tbody>
			<tr>
				<td style="text-align:center; vertical-align:middle">1</td>
				<td>Master of Philosophy<em> (M.Phil.)</em></td>
				<td style="text-align:center; vertical-align:middle"><img src="images/blue_tick.png" /></td>
				<td style="text-align:center; vertical-align:middle">&nbsp;</td>
				<td style="text-align:center; vertical-align:middle">&nbsp;</td>
				<td style="text-align:center; vertical-align:middle"><img src="images/blue_tick.png" /></td>
				<td style="text-align:center; vertical-align:middle"><img src="images/blue_tick.png" /></td>
				<td style="text-align:center; vertical-align:middle">&nbsp;</td>
				<td style="text-align:center; vertical-align:middle"><img src="images/blue_tick.png" /></td>
				<td style="text-align:center; vertical-align:middle">&nbsp;</td>
			</tr>
			<tr>
				<td style="text-align:center; vertical-align:middle">2</td>
				<td>Doctor of Philosophy (Management)<em> [Ph.D. (Management)]</em></td>
				<td style="text-align:center; vertical-align:middle"><img src="images/blue_tick.png" /></td>
				<td style="text-align:center; vertical-align:middle">&nbsp;</td>
				<td style="text-align:center; vertical-align:middle">&nbsp;</td>
				<td style="text-align:center; vertical-align:middle"><img src="images/blue_tick.png" /></td>
				<td style="text-align:center; vertical-align:middle"><img src="images/blue_tick.png" /></td>
				<td style="text-align:center; vertical-align:middle">&nbsp;</td>
				<td style="text-align:center; vertical-align:middle"><img src="images/blue_tick.png" /></td>
				<td style="text-align:center; vertical-align:middle">&nbsp;</td>
			</tr>
		</tbody>
	</table>

	
	<!----------------             Footer          ------------------->
		<footer>
			<div class="container2">
				<div class="col-3">
					<p>&#169;Copyright-PMS 2017. All Rights Reserved</p>
					<h1 class="footdes">Prototype Team.</h1>
				</div>
			
				<div class="col-1">
					<ul class="unstyle-list">
						<li>navigation</li>
						<li><a href="home.php" >//home</a></li>
						<li><a href="#">//programme</a></li>
						<li><a href="requirement.php">//requirement</a></li>
						<li id="active"><a href="download.php">//downloads</a></li>
					</ul>
				</div>
				<div class="col-1">
					<ul class="unstyle-list">
						<li>social</li>
						<li><a href="#">//blog</a></li>
						<li><a href="#">//facebook</a></li>
						<li><a href="#">//twitter</a></li>
					</ul>
				</div>
			</div>
		</footer>
		
	</body>
			
			</body>
		
<!--------------  menu scrolling  -------------------->
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.0/jquery.min.js"></script>
	<script src="js/jquery.js"></script>
	<script src="js/bootstrap.min.js"></script>
	<script src="scroll.js"></script>
	<script src="slidedown.js"></script>
	<script src="cus.js"></script>
		
	</body>