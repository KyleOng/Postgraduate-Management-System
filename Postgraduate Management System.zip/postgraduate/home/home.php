<?php 

include("../dataconnect.php");

?>

<!DOCTYPE html>

<html lang="en">
	<head>
		<meta charset="utf-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<title>Home</title>
	
		<link rel="stylesheet" href="home.css"/>
		

    <script src="js/jquery.js"></script>
	<script src="scroll.js"></script>
	
	<!-- Awesome Fonts -->
    <link href="../source/font-awesome-4.7.0/css/font-awesome.min.css" rel="stylesheet" type="text/css">
		
	<!-- sweetalert -->
	<script src="../source/sweetalert/dist/sweetalert2.min.js"></script>		
	<link rel="stylesheet" type="text/css" href="../source/sweetalert/dist/sweetalert2.css">
	
	<!-- bootstrap -->
	<link href="../source/css/bootstrap.min.css" rel="stylesheet">
	<script src="../source/js/bootstrap.min.js"></script>
	
	<!-- jquery -->
	<script src="../source/js/jquery.js"></script>
	
	<!-- country -->
	<script type= "text/javascript" src = "../source/js/country.js"></script>
		
	<!-- Registration -->
	<script>
	
	function TestFunc(){
		document.getElementById("en_mark").options.length = 1;
		var i;
		var en_test_type= document.forms[0].en_test.value;
		if (en_test_type=="MUET"){
			for(i=1;i<7;i++){
				var newOption=document.createElement("option");
				newOption.text=i;
				document.getElementById("en_mark").add(newOption);
			}
		}
		else if (en_test_type=="IELTS"){
			for(i=0;i<9.5;i=i+0.5){
				var newOption=document.createElement("option");
				newOption.text=i;
				document.getElementById("en_mark").add(newOption);
			}
		}
		else if (en_test_type=="TOEFL"){
			for(i=0;i<121;i++){
				var newOption=document.createElement("option");
				newOption.text=i;
				document.getElementById("en_mark").add(newOption);
			}
		}
	}
	
	function StructureFunc(){
		document.getElementById("programme").options.length = 1;
		var selected_Structure= document.forms[0].stud_type.value;
		if (selected_Structure=="Coursework"){	
			<?php
			$programmeList=mysqli_query($con,"SELECT * FROM programme WHERE `prog_type`='Coursework' or `prog_type`='Both';");
			while($row = mysqli_fetch_array($programmeList,MYSQLI_ASSOC)) {
				?>
				var newOption=document.createElement("option");
				newOption.value="<?php echo $row['prog_id']?>";
				newOption.text="<?php echo $row['prog_name']?>";
				document.getElementById("programme").add(newOption);
				<?php
			}
			?>
		}
		else if (selected_Structure=="Research"){
			<?php
			$programmeList=mysqli_query($con,"SELECT * FROM programme WHERE `prog_type`='Research' or `prog_type`='Both';");
			while($row = mysqli_fetch_array($programmeList,MYSQLI_ASSOC)) {
				?>
				var newOption=document.createElement("option");
				newOption.value="<?php echo $row['prog_id']?>";
				newOption.text="<?php echo $row['prog_name']?>";
				document.getElementById("programme").add(newOption);
				<?php
			}
			?>
		}
	}
	
	function showBlankError(id,error_id,br_id,error_message){
		document.getElementById(id).style.backgroundColor = "#ffcccc";
		document.getElementById(error_id).innerHTML=error_message.replace(error_message,"You can't leave this blank");
		document.getElementById(error_id).hidden=false;
		document.getElementById(br_id).hidden=true;
	}
	
	function showInvalidError(id,error_id,br_id,error_message){
		document.getElementById(id).style.backgroundColor = "#ffcccc";
		document.getElementById(error_id).innerHTML=error_message.replace(error_message,"Invalid format");
		document.getElementById(error_id).hidden=false;
		document.getElementById(br_id).hidden=true;
	}
	
	function showNoError(id,error_id,br_id){
		document.getElementById(id).style.backgroundColor = "white";
		document.getElementById(error_id).hidden=true;
		document.getElementById(br_id).hidden=false;
	}
	
	function showDuplicateError(id,error_id,br_id,error_message){
		document.getElementById(id).style.backgroundColor = "#ffcccc";
		document.getElementById(error_id).innerHTML=error_message.replace(error_message,"This input has been used");
		document.getElementById(error_id).hidden=false;
		document.getElementById(br_id).hidden=true;
	}
	
	function InputValidation(id,reg,duplicateChecking){
		var error_id="error_"+id;
		var br_id="br_"+id;
		var error_message=document.getElementById(error_id).innerHTML; 
		if(reg.test(document.getElementById(id).value) == false){
			if ((document.getElementById(id).value) == ""){
				showBlankError(id,error_id,br_id,error_message);
			}
			else{
				showInvalidError(id,error_id,br_id,error_message);
			}
		}
		else{
			showNoError(id,error_id,br_id);
			if(duplicateChecking==true) duplicateCheck(id);
		}
	}
	
	function duplicateCheck(id){
		var error_id="error_"+id;
		var br_id="br_"+id;
		var error_message=document.getElementById(error_id).innerHTML; 
		$.post('duplicateCheck.php',{check_attribute: document.getElementById(id).value, type:id},
		function(result){
			if (result=="exist"){
				showDuplicateError(id,error_id,br_id,error_message);
			}
			else{
				showNoError(id,error_id,br_id);
			}
		});
	}

	function submitFunc(){
		var id;
		var errorCount=0;
		var all_id=["stud_name","stud_country","stud_email","stud_contact","stud_gender","stud_address","stud_state","stud_postcode","und_grad","und_cgpa","en_test","en_mark","stud_type","programme"];
		var local_id=["stud_name","stud_ic","stud_email","stud_contact","stud_gender","stud_address","stud_state","stud_postcode","und_grad","und_cgpa","en_test","en_mark","stud_type","programme"];
		var international_id=["stud_name","stud_passport","stud_email","stud_contact","stud_gender","stud_address","stud_state","stud_postcode","und_grad","und_cgpa","en_test","en_mark","stud_type","programme"];
		if(document.getElementById("stud_ic").disabled==false){
			id=local_id;
		}
		else if(document.getElementById("stud_passport").disabled==false){
			id=international_id;
		}
		else{
			id=all_id;
		}
		
		for(i=0;i<id.length;i++){
			var error_id="error_"+id[i];
			var br_id="br_"+id[i];
			var error_message=document.getElementById(error_id).innerHTML;
			if(document.getElementById(id[i]).value=="" || document.getElementById(error_id).hidden==false){
				if(document.getElementById(id[i]).value==""){
					showBlankError(id[i],error_id,br_id,error_message);
					errorCount++;
				}
				if(document.getElementById(error_id).hidden==false){
					errorCount++;
				}
			}	
		}
		if (errorCount>0){
			swal(
			  'Error',
			  'Please make sure all the inputs are inserted and in correct format',
			  'error'
			);
			return false;
		}
		else{
			return true;
		}
	}
	
	</script>	
	
	</head>
	
	<body>
		<header class="header">
		<img src="PMSblack.png" alt="PMS logo" class="logo">
			<nav class="nav">
			<ul>
				<li id="active"><a href="#"><font size="2">Home</font></a></li>
				<li><a href="program.php"><font size="2">Programme</font></a></li>
				</li>
				<li><a href="requirement.php"><font size="2">Requirements</font></a></li>
				<li><a href="download.php"><font size="2">Download</font></a></li>
				<li><a href="../login.php"><font size="2">Login</font></a></li>	
			</ul>
			</nav>
		</header>
		<section class="home-word">
			<div class="container">
				<h1 class="title"><font size="8">Making things looks great</font> 
					<span><font size="6">for Postgraduate who make great stuff<font></span>
				</h1>
				<a href="#" data-toggle="modal" data-target="#Registration" class="button button-home">Register Now</a>
			</div>
		</section>
		
		<div class="container2">
			<section class="home-about">
			<div class="home-about-textbox">
				<h1 class="footdes">Who we are</h1>
				<p><font size="3">
					<strong>The Postgraduate Management System (PMS)</strong> is the central coordinator for university-wide postgraduate programs,
						activities and support which cooperation with faculties. PMS was designed by <strong>team Prototype</strong>.
				</font></p>
				<p><font size="3">
					PMS provides postgraduate support for programs in <strong>Information Technology, Management & Business,
					Creative Multimedia and Engineering</strong>. These postgraduate programs are structured in two categories : 
					<strong>Doctoral programs by Coursework and Dissertation as well PhD by Research</strong>. Three intakes per years, applicants can choose to
					commence their programs in February, June and October.
				</font></p>
			</div>
			</section>
		</div>	
		
		<section class="program">
		<h1 class="footdes">All available programs</h1>
		
		<!-- --------item-01-------->
		<figure class="pro_item">
				<img src="p1.jpg" alt="portfolio item" width=752,height=371>
				<figcaption class="pro_desc">
				<p><font size="4">Faculty of Engineering</font></p>
				<a href="" class="button button-home button-small"><font size="2">Programme details</font></a>
				</figcaption>
		</figure>
		
		<!-- --------item-02-------->
		<figure class="pro_item">
				<img src="p2.jpg" alt="portfolio item" width=752,height=371>
				<figcaption class="pro_desc">
				<p><font size="4">Faculty of Information Technology</font></p>
				<a href="" class="button button-home button-small"><font size="2">Programme details</font></a>
				</figcaption>
		</figure>
		
		<!-- --------item-03-------->
		<figure class="pro_item">
				<img src="p3.jpg" alt="portfolio item" width=752,height=371>
				<figcaption class="pro_desc">
				<p><font size="4">Faculty of Business and Management</font></p>
				<a href="" class="button button-home button-small"><font size="2">Programme details</font></a>
				</figcaption>
		</figure>
		
		<!-- --------item-04-------->
		<figure class="pro_item">
				<img src="p4.jpg" alt="portfolio item" width=752,height=371>
				<figcaption class="pro_desc">
				<p><font size="4">Faculty of Creative Multimedia</font></p>
				<a href="" class="button button-home button-small"><font size="2">Programme details</font></a>
				</figcaption>
		</figure>
		
		</section>
		
		
		<footer>
			<div class="container">
				<div class="col-3">
					<p><font size="3">&#169;Copyright-PMS 2017. All Rights Reserved</font></p>
					<h1 class="footdes">Prototype Team.</font></h1>
				</div>
			
				<div class="col-1">
					<ul class="unstyle-list">
						<li><font size="2">navigation</font></li>
						<li id="active"><a href="#"><font size="2">//home</font></a></li>
						<li><a href="program.php"><font size="2">//programme</font></a></li>
						<li><a href="requirement.php"><font size="2">//requirement</font></a></li>
						<li><a href="download.php"><font size="2">//downloads</font></a></li>
					</ul>
				</div>
				<div class="col-1">
					<ul class="unstyle-list">
						<li><font size="2">social</font></li>
						<li><a href="#"><font size="2">//blog</font></a></li>
						<li><a href="#"><font size="2">//facebook</font></a></li>
						<li><a href="#"><font size="2">//twitter</font></a></li>
					</ul>
				</div>
			</div>
		</footer>
	
	<!-- Register -->
		<div class="modal fade" id="Registration" role="dialog">
		<div class="modal-dialog">
		
			<div class="modal-content">
				
				<div class="modal-header">
				  <button type="button" class="close" data-dismiss="modal">&times;</button>
				  <h1><class="modal-title">Registration</h1>
				</div>
				 
				<div class="modal-body">
					<form action="home.php" method='POST' onsubmit="return submitFunc()">
					
					<div class="form-group">
						<h4 align="left"><label for="stud_name" ><span class="glyphicon glyphicon-user"></span> Name: </label></h4>
						<input type="text" class="form-control" id="stud_name" name="stud_name" placeholder="Name" onblur="InputValidation('stud_name',/^([^ ]+.{0,1000})$/,false)">
						<h5 style="color:red;" id="error_stud_name" hidden>You can't leave this blank</h5>
						<br id="br_stud_name">
					</div>
					
					<div class="form-group">
						<h4 align="left"><label for="stud_country"><span class="glyphicon glyphicon-globe"></span> Country Origin: </label></h4>
						<select class="form-control" id="stud_country" name="stud_country"  onblur="InputValidation('stud_country',/^(.{1,1000})$/,false)">
						</select>
						<h5 style="color:red;" id="error_stud_country" hidden>You can't leave this blank</h5>
						<br id="br_stud_country">
					</div>
					
					<div class="form-group">
						<h4 align="left"><label for="stud_ic"><span class="fa fa-address-card-o"></span> Identification Card Number: </label></h4>
						<input type="text" style="background-color:#cfcfd1;" class="form-control" id="stud_ic" name="stud_ic" placeholder="Identification Card Number (Please choose your country origin first)" disabled onblur="InputValidation('stud_ic',/^([0-9]{12,12})$/,true)">
						<h5 style="color:grey;" align="left">Format: 12 numeric digit without "-" sign</h5>
						<h5 style="color:red;" id="error_stud_ic" hidden>You can't leave this blank</h5>
						<br id="br_stud_ic">
					</div>
						
					<div class="form-group">
						<h4 align="left"><label for="stud_passport"><span class="fa fa-address-card"></span> Passport: </label></h4>
						<input type="text" style="background-color:#cfcfd1;"  class="form-control" id="stud_passport" name="stud_passport" placeholder="Passport (Please choose your country origin first)" disabled onblur="InputValidation('stud_passport',/^([a-zA-Z0-9]{1,100})$/,true)">
						<h5 style="color:grey;" align="left">Format: Only alphabet and numeric input</h5>
						<h5 style="color:red;" id="error_stud_passport" hidden>You can't leave this blank</h5>	
						<br id="br_stud_passport">
					</div>
						
					<div class="form-group">
						<h4 align="left"><label for="stud_email"><span class="fa fa-envelope-o"></span> Email: </label></h4>
						<input type="text" class="form-control"  id="stud_email" name="stud_email" placeholder="Email" onblur="InputValidation('stud_email',/^([A-Za-z0-9_\-\.])+\@([A-Za-z0-9_\-\.])+\.([A-Za-z]{2,4})$/,true)">
						<h5 style="color:grey;" align="left">Format: Make sure to include an "@" sign and domain (someone@domain.com)<h5>
						<h5 style="color:red;" id="error_stud_email" hidden>You can't leave this blank</h5>											
						<br id="br_stud_email">
					</div>
						
					<div class="form-group">
						<h4 align="left"><label for="stud_contact"><span class="fa fa-volume-control-phone"></span> Contact: </label></h4>
						<input type="text" class="form-control"  id="stud_contact" name="stud_contact" placeholder="Contact" onblur="InputValidation('stud_contact',/^([0-9]{9,11})$/,false)">
						<h5 style="color:grey;" align="left">Format: 9 to 11 numeric digit without "-" sign<h5>
						<h5 style="color:red;" id="error_stud_contact" hidden>You can't leave this blank</h5>	
						<br id="br_stud_contact">	
					</div>
						
					<div class="form-group">
						<h4 align="left"><label for="stud_gender"><span class="fa fa-venus-mars"></span> Gender: </label></h4>
						<select id="stud_gender" name="stud_gender" class="form-control" onblur="InputValidation('stud_gender',/^([A-Za-z ]{1,1000})$/,false)">
							<option value="" selected disabled>Gender</option>
							<option value="Male">Male</option>
							<option value="Female">Female</option>
						</select>
						<h5 style="color:red;" id="error_stud_gender" hidden>You can't leave this blank</h5>
						<br id="br_stud_gender">
					</div>
						
					<div class="form-group">
						<h4 align="left"><label for="stud_address"><span class="glyphicon glyphicon-home"></span> Address: </label></h4>
						<input type="text" class="form-control"  id="stud_address" name="stud_address" placeholder="Address" onblur="InputValidation('stud_address',/^([^ ]+.{0,1000})$/,false)">
						<h5 style="color:red;" id="error_stud_address" hidden>You can't leave this blank</h5>						
						<br id="br_stud_address">
					</div>
						
					<div class="form-group">
						<h4 align="left"><label for="stud_state"><span class="glyphicon glyphicon-map-marker"></span> State:</label></h4>
						<select class="form-control"  id="stud_state" name="stud_state" onblur="InputValidation('stud_state',/^(.{1,1000})$/,false)">
							<option value="" selected disabled>Select State (Please choose your country origin first)</option>
						</select>
						<h5 style="color:red;" id="error_stud_state" hidden>You can't leave this blank</h5>
						<br id="br_stud_state">
					</div>	
						
					<div class="form-group">
						<h4 align="left"><label for="stud_postcode"><span class="glyphicon glyphicon-road"></span> Postcode:</label></h4>
						<input type="text" class="form-control"  id="stud_postcode" name="stud_postcode" placeholder="Postcode" onblur="InputValidation('stud_postcode',/^([^ ]+.{0,1000})$/,false)">
						<h5 style="color:red;" id="error_stud_postcode" hidden>You can't leave this blank</h5>						
						<br id="br_stud_postcode">
					</div>
					
					<div class="form-group">
						<h4 align="left"><label for="und_grad"><span class="fa fa-university"></span> Undergraduate University: </label></h4>
						<input type="text" class="form-control"  id="und_grad" name="und_grad" placeholder="Undergraduate University" onblur="InputValidation('und_grad',/^([^ ]+.{0,1000})$/,false)">
						<h5 style="color:red;" id="error_und_grad" hidden>You can't leave this blank</h5>						
						<br id="br_und_grad">
					</div>
						
					<div class="form-group">
						<h4 align="left"><label for="und_cgpa"><span class="fa fa-university"></span> Undergraduate CGPA: </label></h4>
						<input type="text" class="form-control" id="und_cgpa" name="und_cgpa" placeholder="CGPA" onblur="InputValidation('und_cgpa',/^((([0-3])+\.([0-9]{0,2}))|(([4])+\.([0]{0,2})))$/,false)">
						<h5 style="color:grey;" align="left">Format: Min 0, Max 4, make sure input is in 1 or 2 decimal places<h5>
						<h5 style="color:red;" id="error_und_cgpa" hidden>You can't leave this blank</h5>	
						<br id="br_und_cgpa">
					</div>
						
					<div class="form-group">
						<h4 align="left"><label for="en_test"><span class="glyphicon glyphicon-education"></span> English Language Proficiency Test: </label></h4>
						<select id="en_test" class="form-control" name="en_test" onchange="TestFunc()" onblur="InputValidation('en_test',/^(.{1,1000})$/,false)">
							<option value="" selected disabled>English Language Proficiency Test</option>
							<option value="MUET">MUET (Malaysian University English Test)</option>
							<option value="IELTS">IELTS (International English Language Testing System)</option>
							<option value="TOEFL">TOEFL (Test of English as a Foreign Language)</option>
						</select>
						<h5 style="color:red;" id="error_en_test" hidden>You can't leave this blank</h5>
						<br id="br_en_test">
					</div>
						
					<div class="form-group">
						<h4 align="left"><label for="en_mark"><span class="glyphicon glyphicon-education"></span> English Language Proficiency Result: </label></h4>
						<select id="en_mark" class="form-control" name="en_mark" onblur="InputValidation('en_mark',/^(.{1,1000})$/,false)">
							<option value="" selected disabled>English Language Proficiency Result (Please choose the English test first)</option>
						</select>
						<h5 style="color:red;" id="error_en_mark" hidden>You can't leave this blank</h5>
						<br id="br_en_mark">
					</div>
					
					<div class="form-group">
						<h4 align="left"><label for="stud_type"><span class="glyphicon glyphicon-book"></span> Stucture:</label></h4>
						<select id="stud_type" class="form-control" name="stud_type" onchange="StructureFunc()" onblur="InputValidation('stud_type',/^(.{1,1000})$/,false)">
							<option value="" selected disabled>Structure</option>
							<option value="Research">Research</option>
							<option value="Coursework">Coursework</option>
						</select>
						<h5 style="color:red;" id="error_stud_type" hidden>You can't leave this blank</h5>
						<br id="br_stud_type">	
					</div>
					
					<div class="form-group">
						<h4 align="left"><label for="programme"><span class="glyphicon glyphicon-book"></span> Programme:</label></h4>
						<select  class="form-control" id="programme" name="programme" onblur="InputValidation('programme',/^(.{1,1000})$/,false)">
							<option value="" selected disabled>Programme (Please choose your selected structure first)</option>
						</select>
						<h5 style="color:red;" id="error_programme" hidden>You can't leave this blank</h5>
						<br id="br_programme">
					</div>
					
					<button type="submit" class="btn btn-default" id="submit_button" name="submit_button" >Submit</button>
					<script>
						populateCountries("stud_country", "stud_state");
					</script>
					</form>
				</div>
			</div>
		</div>
	</div>
	
</body>

	<?php
	if((isset($_POST["submit_button"]))&&(isset($_POST["stud_ic"])))
	{
		$stud_name=$_POST['stud_name'];
		$stud_ic=$_POST['stud_ic'];
		$stud_email=$_POST['stud_email'];
		$stud_contact=$_POST['stud_contact'];
		$stud_gender=$_POST['stud_gender'];
		$stud_address=$_POST['stud_address'];
		$stud_state=$_POST['stud_state'];
		$stud_postcode=$_POST['stud_postcode'];
		$stud_nation=$_POST['stud_country'];
		$stud_type=$_POST['stud_type'];
		$und_grad=$_POST['und_grad'];
		$und_cgpa=$_POST['und_cgpa'];
		$en_test=$_POST['en_test'];
		$en_mark=$_POST['en_mark'];
		$prog_id=$_POST['programme'];
		$reg_status="Pending";
		
		
		$test = mysqli_query($con,"INSERT INTO registration(`prog_id`,stud_name, stud_ic, stud_email, stud_contact, stud_gender, stud_address, stud_state, stud_postcode, stud_nation, stud_type, und_grad, und_cgpa, en_test, en_mark, reg_status) 
		VALUE ('$prog_id','$stud_name', '$stud_ic', '$stud_email', '$stud_contact', '$stud_gender', '$stud_address', '$stud_state', '$stud_postcode', '$stud_nation', '$stud_type', '$und_grad', '$und_cgpa', '$en_test', '$en_mark','$reg_status')");
		if($test)
		{	
			echo "<script>console.log('register done');</script>";
		}
		else
		{
			echo "<script>console.log('error on register');</script>";
		}
		?>
		<script>
		swal('Registered!','You have successfully register!','success');
		</script><?php
		mysqli_query($con,"UPDATE registration set reg_code=concat('RC',reg_id) where stud_email='$stud_email';");
	}
	else if((isset($_POST["submit_button"]))&&(isset($_POST["stud_passport"]))){
		$stud_name=$_POST['stud_name'];
		$stud_passport=$_POST['stud_passport'];
		$stud_email=$_POST['stud_email'];
		$stud_contact=$_POST['stud_contact'];
		$stud_gender=$_POST['stud_gender'];
		$stud_address=$_POST['stud_address'];
		$stud_state=$_POST['stud_state'];
		$stud_postcode=$_POST['stud_postcode'];
		$stud_nation=$_POST['stud_country'];
		$stud_type=$_POST['stud_type'];
		$und_grad=$_POST['und_grad'];
		$und_cgpa=$_POST['und_cgpa'];
		$en_test=$_POST['en_test'];
		$en_mark=$_POST['en_mark'];
		$prog_id=$_POST['programme'];
		$reg_status="Pending";

		
		mysqli_query($con,"INSERT INTO registration(prog_id,stud_name, stud_passport, stud_email, stud_contact, stud_gender, stud_address, stud_state, stud_postcode, stud_nation, stud_type, und_grad, und_cgpa, en_test, en_mark, reg_status) 
		VALUE ('$prog_id','$stud_name', '$stud_passport', '$stud_email', '$stud_contact', '$stud_gender', '$stud_address', '$stud_state', '$stud_postcode', '$stud_nation', '$stud_type', '$und_grad', '$und_cgpa', '$en_test', '$en_mark','$reg_status')");
		?>
		<script>
		swal('Registered!','You have successfully register!','success');
		</script><?php
		mysqli_query($con,"UPDATE registration set reg_code=concat('RC',reg_id) where stud_email='$stud_email';");
	}
	
?>