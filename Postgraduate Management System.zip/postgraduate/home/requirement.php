<!DOCTYPE html>
<html lang="en">
	<head>
		<meta charset="utf-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<title>Home</title>
		
		
		<link rel="stylesheet" href="home2.css"/>
	</head>
	
	<body>
		<header class="header">
		<img src="PMSblack.png" alt="PMS logo" class="logo">
			<nav class="nav">
			<ul>
				<li><a href="home.php">Home</a></li>
				<li ><a href="program.php">Programme</a></li>
				</li>
				<li id="active"><a href="#">Requirements</a></li>
				<li><a href="download.php">Download</a></li>
				<li><a href="../login.php">Login</a></li>	
			</ul>
			</nav>
		</header>
		
		
		<body>
			<div class="container">
			<section class="table">
			<h1 class="footdes1">1. Structure A</h1>
			<table border="5">
				<tr>
				<th>programme</th>
				<th>entry requirement</th>
				<th>candidature period</th>
				</tr>
				
				<tr>
					<td>Master of Engineering Science</td>
					<td>--</td>
					<td>Full Time: 1 year - 3 years
						Part Time: 2 years - 5 years
					</td>
				</tr>
				
				<tr>
					<td>Master of Information technology</td>
					<td>--</td>
					<td>Full Time: 1 year - 3 years
						Part Time: 2 years - 5 years
					</td>
				</tr>
				
				<tr>
					<td>Master of Creative Multimedia</td>
					<td>--</td>
					<td>Full Time: 1 year - 3 years
						Part Time: 2 years - 5 years
					</td>
				</tr>
				
				<tr>
					<td>Master of Management</td>
					<td>--</td>
					<td>Full Time: 1 year - 3 years
						Part Time: 2 years - 5 years
					</td>
				</tr>
				
				<tr>
					<td>Doctor of Engineering</td>
					<td>--</td>
					<td>Full Time: 1 year - 3 years
						Part Time: 2 years - 5 years
					</td>
				</tr>
				
				<tr>
					<td>Doctor of Information Technology</td>
					<td>--</td>
					<td>Full Time: 1 year - 3 years
						Part Time: 2 years - 5 years
					</td>
				</tr>
				
				<tr>
					<td>Doctor of Creative</td>
					<td>--</td>
					<td>Full Time: 1 year - 3 years
						Part Time: 2 years - 5 years
					</td>
				</tr>
				
				<tr>
					<td>Doctor of Management</td>
					<td>--</td>
					<td>Full Time: 1 year - 3 years
						Part Time: 2 years - 5 years
					</td>
				</tr>
				
			</table>
			</section>
			</div>
			
<!-----------------------    structure B     -------------------->			
			<div class="container">
			<section class="table">
			<h1 class="footdes">2. Structure B</h1>
			<table border="5">
				<tr>
				<th>programme</th>
				<th>entry requirement</th>
				<th>candidature period</th>
				</tr>
				
				<tr>
					<td>Doctor of Business Administration</td>
					<td>--</td>
					<td>Full Time: 1 year - 3 years
						Part Time: 2 years - 5 years
					</td>
				</tr>

			</table>
			</section>
			</div>
			
<!-----------------------    structure C     -------------------->	
			<div class="container">
			<section class="table">
			<h1 class="footdes">3. Structure C</h1>
			<table border="5">
				<tr>
				<th>programme</th>
				<th>entry requirement</th>
				<th>candidature period</th>
				</tr>
				
				<tr>
					<td>Master of Engineering (telecommnunication)</td>
					<td>--</td>
					<td>Full Time: 1 year - 3 years
						Part Time: 2 years - 5 years
					</td>
				</tr>
				
				<tr>
					<td>Master of Electrical and Electronic Engineering</td>
					<td>--</td>
					<td>Full Time: 1 year - 3 years
						Part Time: 2 years - 5 years
					</td>
				</tr>
				
				<tr>
					<td>Master of Science in Suitainable System Management</td>
					<td>--</td>
					<td>Full Time: 1 year - 3 years
						Part Time: 2 years - 5 years
					</td>
				</tr>
				
				<tr>
					<td>Master of Engineering in Embedded System</td>
					<td>--</td>
					<td>Full Time: 1 year - 3 years
						Part Time: 2 years - 5 years
					</td>
				</tr>
				
				<tr>
					<td>Master of Engineering in Advanced Manufacturing Managemnet</td>
					<td>--</td>
					<td>Full Time: 1 year - 3 years
						Part Time: 2 years - 5 years
					</td>
				</tr>
				
				<tr>
					<td>Master of Computer Science in Software Engineering and Software Architecture</td>
					<td>--</td>
					<td>Full Time: 1 year - 3 years
						Part Time: 2 years - 5 years
					</td>
				</tr>
				
				<tr>
					<td>Master of Knowledge Management with multimedia</td>
					<td>--</td>
					<td>Full Time: 1 year - 3 years
						Part Time: 2 years - 5 years
					</td>
				</tr>
				
				<tr>
					<td>Master of Multimedia (E-learning Technologies)</td>
					<td>--</td>
					<td>Full Time: 1 year - 3 years
						Part Time: 2 years - 5 years
					</td>
				</tr>
				
				<tr>
					<td>Master of Business Administration</td>
					<td>--</td>
					<td>Full Time: 1 year - 3 years
						Part Time: 2 years - 5 years
					</td>
				</tr>
				
				<tr>
					<td>Executive Master of Business Administration</td>
					<td>--</td>
					<td>Full Time: 1 year - 3 years
						Part Time: 2 years - 5 years
					</td>
				</tr>
				
			</table>
			</section>
			
			</div>
			
			<footer>
			<div class="container2">
				<div class="col-3">
					<p>&#169;Copyright-PMS 2017. All Rights Reserved</p>
					<h1 class="footdes">Prototype Team.</h1>
				</div>
			
				<div class="col-1">
					<ul class="unstyle-list">
						<li>navigation</li>
						<li><a href="home.php">//home</a></li>
						<li><a href="program.php">//programme</a></li>
						<li id="active"><a href="#">//requirement</a></li>
						<li><a href="download.php">//downloads</a></li>
					</ul>
				</div>
				<div class="col-1">
					<ul class="unstyle-list">
						<li>social</li>
						<li><a href="#">//blog</a></li>
						<li><a href="#">//facebook</a></li>
						<li><a href="#">//twitter</a></li>
					</ul>
				</div>
			</div>
		</footer>
		
	</body>
			
			</body>
		
<!--                    menu scrolling  -->
	<script src="js/jquery.js"></script>
	<script src="scroll.js"></script>
		