<!DOCTYPE html>
<html lang="en">
	<head>
		<meta charset="utf-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<title>Home</title>
		
		
		<link rel="stylesheet" href="home2.css"/>
	</head>
	
	<body>
		<header class="header">
		<img src="PMSblack.png" alt="PMS logo" class="logo">
			<nav class="nav">
			<ul>
				<li><a href="home.php">Home</a></li>
				<li><a href="program.php">Programme</a></li>
				</li>
				<li><a href="requirement.php">Requirements</a></li>
				<li id="active"><a href="#">Download</a></li>
				<li><a href="../login.php">Login</a></li>	
			</ul>
			</nav>
	</header>
		
		<div class="container2">
			<section class="home-about">
			<div class="home-about-textbox">
				<h1 class="footdes">FAQ</h1>
				<p>
					<strong>1. What type of postgraduate programmes do we offer?</strong><br>
					a. Masters and Phd Programmes by Research (Structure A)<br>
					b. Masters and Doctoral Programmes by Coursework and Dissertation (Structure B)<br>
					c. Masters Programme by Coursework (Structure C)
				</p>
				
				<p>
					
					<strong>2. What are the programmes offered by MMU in Cyberjaya, Melaka and Penang Skills Development Centre (PSDC)?</strong><br><br>
					<strong>*CYBERJAYA CAMPUS*</strong><br>
					a.   Master of Engineering (Telecommunications)<br>
					b.  Master of Business Administration<br>
					c. Master of Knowledge Management<br>
					d.  Master of Multimedia (e-Learning Technology)<br>
					e.   Master of Information Technology (Multimedia Computing)<br>
					f.  Master of Computer Science in Software Engineering & Software Architecture<br>
					g. Doctor of Business Administration<br>
					h. Master by Research and Phd<br><br>
					
					
					<strong>*MELAKA CAMPUS*</strong><br>
					a. Master of Engineering in Embedded System<br>
					b. Master of Engineering in Advance Manufacturing Manager<br>
					c. Master by Research and Phd
				</p>
					
				<p>
					<strong>3. What is the difference between taught programme and research programme?</strong><br>
					A research candidate (Structure A) must conduct research (investigations in a particular subject area, study and experiment, culminating the findings of the research undertaken) 
					under the supervision of the academic staff and submit a thesis for the fulfilment of the graduation requirements. Research candidates may also be required register for and pass subject(s) as required by the respective Faculty.<br><br>

					For Structure B and C, a candidate must register and pass a prescribed number of taught subjects (involve the attendance of formal classes, seminars, laboratories and written examinations). In addition,
					the candidate must conduct research (for Structure B) or project (for Structure C) under the supervision of the academic staff and submit a dissertation/project for the fulfillment of the graduation requirements.
				</p>
				<a href="FAQ.pdf " class="button button-home2 button-small">download FAQ</a>
				
		</div>
			</section>
		</div>	
		
			
			<footer>
			<div class="container2">
				<div class="col-3">
					<p>&#169;Copyright-PMS 2017. All Rights Reserved</p>
					<h1 class="footdes">Prototype Team.</h1>
				</div>
			
				<div class="col-1">
					<ul class="unstyle-list">
						<li>navigation</li>
						<li><a href="home.php">//home</a></li>
						<li><a href="program.php">//programme</a></li>
						<li><a href="requirement.php">//requirement</a></li>
						<li id="active"><a href="#">//downloads</a></li>
					</ul>
				</div>
				<div class="col-1">
					<ul class="unstyle-list">
						<li>social</li>
						<li><a href="#">//blog</a></li>
						<li><a href="#">//facebook</a></li>
						<li><a href="#">//twitter</a></li>
					</ul>
				</div>
			</div>
		</footer>
		
	</body>
			
			</body>
		
<!--                    menu scrolling  -->
	<script src="js/jquery.js"></script>
	<script src="scroll.js"></script>
		
	</body>