(function(){
	var windowH =$(window).height(),
		documElem=$(document),
		slidedownpage=$('.slide-down-page'),
		content=$('.content'),
		btns=$('.btn'),
		animspeed=300;
		
	slidedownpage.css({
		height:windowH +'px',
		top: -windowH + 'px'
		
	});
	
	btns.on('click',function(e){
		if ($(this).hasClass('open')){
			slidedownpage.animate({'top':0},animspeed);
			content.animate({'margin-top':windowH + 'px'},animspeed);
		}
		else {
			slidedownpage.animate({'top':-windowH + 'px'},animspeed);
			content.animate({'margin-top':0},animspeed);
		}
		e.preventDefault();
	});
	
	documElem.on('scroll',function(){
		if($(this).scrollTop()>slidedownpage.height() && slidedownpage.css('top')==='0px'){
			slidedownpage.css('top',-windowH+'px');
			content.css('margin-top',0);
			documElem.scrollTop(0);
		}
	});
	
})();