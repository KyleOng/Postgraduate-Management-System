$(window).scroll(function(){
	if($(document).scrollTop()>50){
		$('nav').addClass('scrolled');
	}
	else{
		$('nav').removeClass('scrolled');
	}
});

$(window).scroll(function(){
	if($(document).scrollTop()>50){
		$('.slidebutton').addClass('scrolled2');
	}
	else{
		$('.slidebutton').removeClass('scrolled2');
	}
});